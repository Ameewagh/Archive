/****** Object:  StoredProcedure [dbo].[Suncor_TagState_OnAttributeChanged]    Script Date: 11/02/2015 11:33:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Suncor_TagState_OnAttributeChanged]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Suncor_TagState_OnAttributeChanged]
GO

/****** Object:  StoredProcedure [dbo].[Suncor_TagState_OnAttributeChanged]    Script Date: 11/02/2015 11:33:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[Suncor_TagState_OnAttributeChanged]
(
    @ps_sender            NVARCHAR(255), 
    @pi_called_by         INT,
    @pi_object_id         INT, 
    @pi_object_type       INT, 
    @pi_attrib_id         INT
)
AS
DECLARE
    @li_error       INT,
    @old		NVARCHAR(255),
    @new		NVARCHAR(255),
	@reserved		nvarchar(50) = 'Reserved',
	@cancelled		nvarchar(50) = 'Cancelled',
	@operational	nvarchar(50) = 'Operational',
	@abandoned		nvarchar(50) = 'Abandoned in Place',
	@removed		nvarchar(50) = 'Removed',
	@unclassified	nvarchar(50) = 'Unclassified'

BEGIN	
    SET NOCOUNT ON
    IF ( @pi_object_type = 212/*Tags*/ )
    BEGIN
		-- Tag State only
		IF @pi_attrib_id = (select top 1 char_id from characteristics 
				where object_type = 212 and char_name = 'Tag State'/*?namespace?*/ )
		BEGIN
			set @old = (
				select top 1 old_value from object_audit_info o
				join audit_properties a on o.audit_entry_id = a.audit_entry_id
				join audit_property_defs d on d.property_id = a.property_id
				and d.attrib_id = @pi_attrib_id
				and o.action_type = 3/* change */
				where object_id = @pi_object_id
				order by o.audit_entry_id desc, seq_id desc
			)			
			set @new = (
				select top 1 char_value from char_data 
				where object_id = @pi_object_id and char_id = @pi_attrib_id
			)
			-- Prohibited transitions:
			if (	(@old = @reserved and @new in (@abandoned, @removed))
				or	(@old = @cancelled and @new in (@operational, @abandoned, @removed))
				or	(@old = @operational and @new in (@reserved, @cancelled))
				or	(@old = @abandoned and @new in (@reserved, @cancelled))
				or	(@old = @removed)			-- can never changed once Removed
				or	(@new = @unclassified)		-- can never be changed to Unclassified
				or	(@old = @unclassified and @new in (@reserved))
				)
			begin
				declare @msg nvarchar(255) = 'Tag State transition not allowed: '+ @old + ' > ' + @new
				exec ebp_raise_error @msg , @pi_called_by
			end	

			-- rules to cancelling tag
			if (@new = @cancelled) 
			begin
				-- named relationships
				if exists (
					select 1 from relationships 
					where right_object_type = 212
					and (  
						/*tag-tag*/  (left_object_type = 212 and (left_object_id = @pi_object_id or right_object_id = @pi_object_id))
					 or /*doc-tag*/	 (left_object_type = 3 and right_object_id = @pi_object_id)
					 or /*floc-tag*/ (left_object_type = 123 and right_object_id = @pi_object_id)
					 or /*eqpt-tag*/ (left_object_type = 1 and right_object_id = @pi_object_id)
					) 
				) 
				BEGIN
					exec ebp_raise_error 'Tag cannot be cancelled when relations exist (tag-tag, doc-tag, floc-tag, eqpt-tag).' , @pi_called_by
				END
			END
		END	

		-- TODO: eB sort field attribute?

	END
    RETURN 0 -- Success
END

/*
select * from char_data where char_id = 34 
and object_id = (select tag_id from tags where code = '99A-40003')

update char_data set char_value = 'Reserved' where char_id = 34 
and object_id = (select tag_id from tags where code = '99A-40003')
*/

