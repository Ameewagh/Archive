/****** Object:  StoredProcedure [dbo].[Suncor_AutoTagState_OnRelationshipAdded]    Script Date: 11/02/2015 13:11:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Suncor_AutoTagState_OnRelationshipAdded]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Suncor_AutoTagState_OnRelationshipAdded]
GO

/****** Object:  StoredProcedure [dbo].[Suncor_AutoTagState_OnRelationshipAdded]    Script Date: 11/02/2015 13:11:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
Automate Tag state transition Reserved --> Operational 
on receipt of As-Built or Final document
Triggers: 
(1) When a document's Approval Status is Approved, 
and the Revision Purpose is either As-Built or Final
OR 
(2) When a Doc-Tag relationship is created, 
and the Document's Approval Status is Approved,
and the Revision Purpose is either As-Built or Final:
(For both these scenarios: ignore the Tag Registry Traveller document; 
note not all document classes may have these attributes - do nothing if not found)
For each Tag related to the document,
If the Tag state = Reserved, change it to Operational.
*/
CREATE PROCEDURE [dbo].[Suncor_AutoTagState_OnRelationshipAdded]
(
	@ps_sender				NVARCHAR(255),
	@pi_called_by			INT,
	@pi_rel_type_id			INT,
	@pi_left_object_id		INT,
	@pi_left_object_type	INT,
	@pi_right_object_id		INT,
	@pi_right_object_type	INT
)
AS
DECLARE
    @li_error			INT,
    @li_doc_id			INT,
    @li_tag_id			INT,
    @li_state_char_id	INT,	-- Tag State
    @li_purpose_char_id INT		-- Revision Purpose
BEGIN	
    SET NOCOUNT ON
    IF ((@pi_left_object_type = 212/*Tags*/ and @pi_right_object_type = 3/*Document*/ 
		or @pi_left_object_type = 3/*Document*/ and @pi_right_object_type = 212/*Tag*/) 
		and (@pi_rel_type_id <> (select top 1 rel_type_id 
				from relationship_types where class_id = (
					select top 1 class_id 
					from class_objects where code = 'ARE009'/*registry traveller*/))))
    BEGIN
		select 
			@li_tag_id = case when (@pi_left_object_type = 3) then @pi_right_object_id else @pi_left_object_id end,
			@li_doc_id = case when (@pi_left_object_type = 3) then @pi_left_object_id else @pi_right_object_id end
    
		set @li_state_char_id = (select top 1 char_id from characteristics where char_name = 'Tag State') /*namespace?*/
		set @li_purpose_char_id = (select top 1 char_id from characteristics where char_name = 'Revision Purpose') /*namespace?*/
			
		IF 'Reserved' = (select top 1 char_value from char_data where char_id = @li_state_char_id and object_id = @li_tag_id)
			and 'A' = (select top 1 status from documents where document_id = @li_doc_id)
			and 0 < (select count(1) from char_data where char_id = @li_purpose_char_id and object_id = @li_doc_id
					and (char_value like '%As-Built%' or char_value like '%Final%'))
		BEGIN
			exec @li_error = ebp_set_char_data @li_tag_id, @li_state_char_id, 'Operational', null, null, null, @pi_called_by
			if @@ERROR <> 0 or @li_error <> 0 RETURN 1 -- Failure
		END
	END
    RETURN 0 -- Success
END

/*
	select * from char_data where char_id = (select char_id from characteristics where object_type = 212 and char_name = 'Tag State')
	 and object_id = (select top 1 tag_id from tags where code = '99A-40004')

*/
/*
update char_data set char_value = 'Reserved' where char_id = 34 and object_id = 164460

update documents set status = 'N' where prefix = 'AAA01'
select * from documents where prefix = 'AAA01'
*/
GO

