/****** Object:  StoredProcedure [dbo].[Suncor_AutoTagState_OnApprovalStatusChanged]    Script Date: 11/02/2015 13:11:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Suncor_AutoTagState_OnApprovalStatusChanged]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Suncor_AutoTagState_OnApprovalStatusChanged]
GO

/****** Object:  StoredProcedure [dbo].[Suncor_AutoTagState_OnApprovalStatusChanged]    Script Date: 11/02/2015 13:11:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
Automate Tag state transition Reserved --> Operational 
on receipt of As-Built or Final document
Triggers: 
(1) When a document's Approval Status is Approved, 
and the Revision Purpose is either As-Built or Final
OR 
(2) When a Doc-Tag relationship is created, 
and the Document's Approval Status is Approved,
and the Revision Purpose is either As-Built or Final:
(For both these scenarios: ignore the Tag Registry Traveller document; 
note not all document classes may have these attributes - do nothing if not found)
For each Tag related to the document,
If the Tag state = Reserved, change it to Operational.
*/
CREATE PROCEDURE [dbo].[Suncor_AutoTagState_OnApprovalStatusChanged]
(
	@ps_sender NVARCHAR(255),
	@pi_called_by INT,
	@pi_object_id INT,
	@pi_object_type INT,
	@ps_old_status CHAR(1),
	@ps_new_status CHAR(1)
)
AS
DECLARE
    @li_error			INT,
    @li_tag_id			INT,
    @li_state_char_id	INT,	-- Tag State
    @li_purpose_char_id INT		-- Revision Purpose
BEGIN	
    IF ( @pi_object_type = 3/*Documents*/ and @ps_new_status = 'A' )
    BEGIN
		set @li_state_char_id = (select top 1 char_id from characteristics where char_name = 'Tag State') /*namespace?*/
		set @li_purpose_char_id = (select top 1 char_id from characteristics where char_name = 'Revision Purpose') /*namespace?*/
    
		-- TODO extract to function to eliminate duplication?
		IF (0 < (select count(1) from char_data where char_id = @li_purpose_char_id and object_id = @pi_object_id
					and (char_value like '%As-Built%' or char_value like '%Final%')))
		BEGIN
			-- my related reserved tags
			declare tags_cursor cursor for
				select distinct tag_id from (
					select right_object_id as tag_id 
					from relationships where left_object_id = @pi_object_id and left_object_type = 3
					and rel_type_id not in (select top 1 rel_type_id from relationship_types
						where class_id = (select top 1 class_id from class_objects where code = 'ARE009'))  /*namespace?*/
					union
					select left_object_id as tag_id
					from relationships where right_object_id = @pi_object_id and right_object_type = 3
					and rel_type_id not in (select top 1 rel_type_id from relationship_types
						where class_id = (select top 1 class_id from class_objects where code = 'ARE009'))  /*namespace?*/
				) x 
				join char_data c on c.char_id = @li_state_char_id and c.object_id = x.tag_id
				where c.char_value = 'Reserved'
			
			open tags_cursor
			fetch next from tags_cursor into @li_tag_id
			
			while @@FETCH_STATUS = 0
			begin
				exec @li_error = ebp_set_char_data @li_tag_id, @li_state_char_id, 'Operational', null, null, null, @pi_called_by
				if @@ERROR <> 0 or @li_error <> 0 RETURN 1 -- Failure
				fetch next from tags_cursor into @li_tag_id
			end
			
			close tags_cursor
			deallocate tags_cursor

		END
	END
    RETURN 0 -- Success
END

/*
	select * from char_data where char_id = (select char_id from characteristics where object_type = 212 and char_name = 'Tag State')
	 and object_id = (select top 1 tag_id from tags where code = '99A-40004')

*/
/*
update char_data set char_value = 'Reserved' where char_id = 34 and object_id = 164460

update documents set status = 'N' where prefix = 'AAA01'
select * from documents where prefix = 'AAA01'
*/


GO

