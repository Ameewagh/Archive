---------------------------------------------------------
-- 1. Deploy Tag Management Event Handlers v1.0.sql
---------------------------------------------------------

---------------------------------------------------------
PRINT 'Create Stored Procedure Suncor_TagState_OnAttributeChanged'
---------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[Suncor_TagState_OnAttributeChanged]    Script Date: 11/02/2015 11:33:04 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Suncor_TagState_OnAttributeChanged]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Suncor_TagState_OnAttributeChanged]
GO

/****** Object:  StoredProcedure [dbo].[Suncor_TagState_OnAttributeChanged]    Script Date: 11/02/2015 11:33:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[Suncor_TagState_OnAttributeChanged]
(
    @ps_sender            NVARCHAR(255), 
    @pi_called_by         INT,
    @pi_object_id         INT, 
    @pi_object_type       INT, 
    @pi_attrib_id         INT
)
AS
DECLARE
    @li_error       INT,
    @old		NVARCHAR(255),
    @new		NVARCHAR(255),
	@reserved		nvarchar(50) = 'Reserved',
	@cancelled		nvarchar(50) = 'Cancelled',
	@operational	nvarchar(50) = 'Operational',
	@abandoned		nvarchar(50) = 'Abandoned in Place',
	@removed		nvarchar(50) = 'Removed',
	@unclassified	nvarchar(50) = 'Unclassified'

BEGIN	
    SET NOCOUNT ON
    IF ( @pi_object_type = 212/*Tags*/ )
    BEGIN
		-- Tag State only
		IF @pi_attrib_id = (select top 1 char_id from characteristics 
				where object_type = 212 and char_name = 'Tag State'/*?namespace?*/ )
		BEGIN
			set @old = (
				select top 1 old_value from object_audit_info o
				join audit_properties a on o.audit_entry_id = a.audit_entry_id
				join audit_property_defs d on d.property_id = a.property_id
				and d.attrib_id = @pi_attrib_id
				and o.action_type = 3/* change */
				where object_id = @pi_object_id
				order by o.audit_entry_id desc, seq_id desc
			)			
			set @new = (
				select top 1 char_value from char_data 
				where object_id = @pi_object_id and char_id = @pi_attrib_id
			)
			-- Prohibited transitions:
			if (	(@old = @reserved and @new in (@abandoned, @removed))
				or	(@old = @cancelled and @new in (@operational, @abandoned, @removed))
				or	(@old = @operational and @new in (@reserved, @cancelled))
				or	(@old = @abandoned and @new in (@reserved, @cancelled))
				or	(@old = @removed)			-- can never changed once Removed
				or	(@new = @unclassified)		-- can never be changed to Unclassified
				or	(@old = @unclassified and @new in (@reserved))
				)
			begin
				declare @msg nvarchar(255) = 'Tag State transition not allowed: '+ @old + ' > ' + @new
				exec ebp_raise_error @msg , @pi_called_by
			end	

			-- rules to cancelling tag
			if (@new = @cancelled) 
			begin
				-- named relationships
				if exists (
					select 1 from relationships 
					where right_object_type = 212
					and (  
						/*tag-tag*/  (left_object_type = 212 and (left_object_id = @pi_object_id or right_object_id = @pi_object_id))
					 or /*doc-tag*/	 (left_object_type = 3 and right_object_id = @pi_object_id)
					 or /*floc-tag*/ (left_object_type = 123 and right_object_id = @pi_object_id)
					 or /*eqpt-tag*/ (left_object_type = 1 and right_object_id = @pi_object_id)
					) 
				) 
				BEGIN
					exec ebp_raise_error 'Tag cannot be cancelled when relations exist (tag-tag, doc-tag, floc-tag, eqpt-tag).' , @pi_called_by
				END
			END
		END	

		-- TODO: eB sort field attribute?

	END
    RETURN 0 -- Success
END

/*
select * from char_data where char_id = 34 
and object_id = (select tag_id from tags where code = '99A-40003')

update char_data set char_value = 'Reserved' where char_id = 34 
and object_id = (select tag_id from tags where code = '99A-40003')
*/

GO


---------------------------------------------------------
PRINT 'Create Stored Procedure Suncor_AutoTagState_OnApprovalStatusChanged'
---------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[Suncor_AutoTagState_OnApprovalStatusChanged]    Script Date: 11/02/2015 13:11:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Suncor_AutoTagState_OnApprovalStatusChanged]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Suncor_AutoTagState_OnApprovalStatusChanged]
GO

/****** Object:  StoredProcedure [dbo].[Suncor_AutoTagState_OnApprovalStatusChanged]    Script Date: 11/02/2015 13:11:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
Automate Tag state transition Reserved --> Operational 
on receipt of As-Built or Final document
Triggers: 
(1) When a document's Approval Status is Approved, 
and the Revision Purpose is either As-Built or Final
OR 
(2) When a Doc-Tag relationship is created, 
and the Document's Approval Status is Approved,
and the Revision Purpose is either As-Built or Final:
(For both these scenarios: ignore the Tag Registry Traveller document; 
note not all document classes may have these attributes - do nothing if not found)
For each Tag related to the document,
If the Tag state = Reserved, change it to Operational.
*/
CREATE PROCEDURE [dbo].[Suncor_AutoTagState_OnApprovalStatusChanged]
(
	@ps_sender NVARCHAR(255),
	@pi_called_by INT,
	@pi_object_id INT,
	@pi_object_type INT,
	@ps_old_status CHAR(1),
	@ps_new_status CHAR(1)
)
AS
DECLARE
    @li_error			INT,
    @li_tag_id			INT,
    @li_state_char_id	INT,	-- Tag State
    @li_purpose_char_id INT		-- Revision Purpose
BEGIN	
    IF ( @pi_object_type = 3/*Documents*/ and @ps_new_status = 'A' )
    BEGIN
		set @li_state_char_id = (select top 1 char_id from characteristics where char_name = 'Tag State') /*namespace?*/
		set @li_purpose_char_id = (select top 1 char_id from characteristics where char_name = 'Revision Purpose') /*namespace?*/
    
		-- TODO extract to function to eliminate duplication?
		IF (0 < (select count(1) from char_data where char_id = @li_purpose_char_id and object_id = @pi_object_id
					and (char_value like '%As-Built%' or char_value like '%Final%')))
		BEGIN
			-- my related reserved tags
			declare tags_cursor cursor for
				select distinct tag_id from (
					select right_object_id as tag_id 
					from relationships where left_object_id = @pi_object_id and left_object_type = 3
					and rel_type_id not in (select top 1 rel_type_id from relationship_types
						where class_id = (select top 1 class_id from class_objects where code = 'ARE009'))  /*namespace?*/
					union
					select left_object_id as tag_id
					from relationships where right_object_id = @pi_object_id and right_object_type = 3
					and rel_type_id not in (select top 1 rel_type_id from relationship_types
						where class_id = (select top 1 class_id from class_objects where code = 'ARE009'))  /*namespace?*/
				) x 
				join char_data c on c.char_id = @li_state_char_id and c.object_id = x.tag_id
				where c.char_value = 'Reserved'
			
			open tags_cursor
			fetch next from tags_cursor into @li_tag_id
			
			while @@FETCH_STATUS = 0
			begin
				exec @li_error = ebp_set_char_data @li_tag_id, @li_state_char_id, 'Operational', null, null, null, @pi_called_by
				if @@ERROR <> 0 or @li_error <> 0 RETURN 1 -- Failure
				fetch next from tags_cursor into @li_tag_id
			end
			
			close tags_cursor
			deallocate tags_cursor

		END
	END
    RETURN 0 -- Success
END

/*
	select * from char_data where char_id = (select char_id from characteristics where object_type = 212 and char_name = 'Tag State')
	 and object_id = (select top 1 tag_id from tags where code = '99A-40004')

*/
/*
update char_data set char_value = 'Reserved' where char_id = 34 and object_id = 164460

update documents set status = 'N' where prefix = 'AAA01'
select * from documents where prefix = 'AAA01'
*/


GO


---------------------------------------------------------
PRINT 'Create Stored Procedure Suncor_AutoTagState_OnRelationshipAdded'
---------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[Suncor_AutoTagState_OnRelationshipAdded]    Script Date: 11/02/2015 13:11:58 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Suncor_AutoTagState_OnRelationshipAdded]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Suncor_AutoTagState_OnRelationshipAdded]
GO

/****** Object:  StoredProcedure [dbo].[Suncor_AutoTagState_OnRelationshipAdded]    Script Date: 11/02/2015 13:11:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
Automate Tag state transition Reserved --> Operational 
on receipt of As-Built or Final document
Triggers: 
(1) When a document's Approval Status is Approved, 
and the Revision Purpose is either As-Built or Final
OR 
(2) When a Doc-Tag relationship is created, 
and the Document's Approval Status is Approved,
and the Revision Purpose is either As-Built or Final:
(For both these scenarios: ignore the Tag Registry Traveller document; 
note not all document classes may have these attributes - do nothing if not found)
For each Tag related to the document,
If the Tag state = Reserved, change it to Operational.
*/
CREATE PROCEDURE [dbo].[Suncor_AutoTagState_OnRelationshipAdded]
(
	@ps_sender				NVARCHAR(255),
	@pi_called_by			INT,
	@pi_rel_type_id			INT,
	@pi_left_object_id		INT,
	@pi_left_object_type	INT,
	@pi_right_object_id		INT,
	@pi_right_object_type	INT
)
AS
DECLARE
    @li_error			INT,
    @li_doc_id			INT,
    @li_tag_id			INT,
    @li_state_char_id	INT,	-- Tag State
    @li_purpose_char_id INT		-- Revision Purpose
BEGIN	
    SET NOCOUNT ON
    IF ((@pi_left_object_type = 212/*Tags*/ and @pi_right_object_type = 3/*Document*/ 
		or @pi_left_object_type = 3/*Document*/ and @pi_right_object_type = 212/*Tag*/) 
		and (@pi_rel_type_id <> (select top 1 rel_type_id 
				from relationship_types where class_id = (
					select top 1 class_id 
					from class_objects where code = 'ARE009'/*registry traveller*/))))
    BEGIN
		select 
			@li_tag_id = case when (@pi_left_object_type = 3) then @pi_right_object_id else @pi_left_object_id end,
			@li_doc_id = case when (@pi_left_object_type = 3) then @pi_left_object_id else @pi_right_object_id end
    
		set @li_state_char_id = (select top 1 char_id from characteristics where char_name = 'Tag State') /*namespace?*/
		set @li_purpose_char_id = (select top 1 char_id from characteristics where char_name = 'Revision Purpose') /*namespace?*/
			
		IF 'Reserved' = (select top 1 char_value from char_data where char_id = @li_state_char_id and object_id = @li_tag_id)
			and 'A' = (select top 1 status from documents where document_id = @li_doc_id)
			and 0 < (select count(1) from char_data where char_id = @li_purpose_char_id and object_id = @li_doc_id
					and (char_value like '%As-Built%' or char_value like '%Final%'))
		BEGIN
			exec @li_error = ebp_set_char_data @li_tag_id, @li_state_char_id, 'Operational', null, null, null, @pi_called_by
			if @@ERROR <> 0 or @li_error <> 0 RETURN 1 -- Failure
		END
	END
    RETURN 0 -- Success
END

/*
	select * from char_data where char_id = (select char_id from characteristics where object_type = 212 and char_name = 'Tag State')
	 and object_id = (select top 1 tag_id from tags where code = '99A-40004')

*/
/*
update char_data set char_value = 'Reserved' where char_id = 34 and object_id = 164460

update documents set status = 'N' where prefix = 'AAA01'
select * from documents where prefix = 'AAA01'
*/
GO




---------------------------------------------------------
PRINT 'Create Stored Procedure Suncor_TagSuffixA_OnObjectAddedOrChanged'
---------------------------------------------------------

/****** Object:  StoredProcedure [dbo].[Suncor_TagSuffixA_OnObjectAddedOrChanged]    Script Date: 11/02/2015 13:12:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Suncor_TagSuffixA_OnObjectAddedOrChanged]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Suncor_TagSuffixA_OnObjectAddedOrChanged]
GO

/****** Object:  StoredProcedure [dbo].[Suncor_TagSuffixA_OnObjectAddedOrChanged]    Script Date: 11/02/2015 13:12:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
1. Block creation of a tag with a "multiple component" designator of "A" 
(meaning tag number ends in "A") if the base tag exists. 
Example: Do not create 96GM-5001A if 96GM-5001 exists.
Here we mean literally �A� only. Values of �B�, �C� etc. are not subject to this check. 
2. Block creation of a tag with NO multiple component designator 
(meaning tag number does NOT end in any letter) if the base tag PLUS "A" exists. 
Example: Do not create 96GM-5001 if 96GM-5001A exists.
*/
CREATE PROCEDURE [dbo].[Suncor_TagSuffixA_OnObjectAddedOrChanged]
(
    @ps_sender NVARCHAR(255),
	@pi_called_by INT,
	@pi_object_id INT,
	@pi_object_type INT
)
AS
DECLARE
    @li_error       INT,
    @li_scope_id	INT,
    @li_item_id		INT,
    @ls_code		NVARCHAR(100),
    @ls_last_char	NVARCHAR(1)
BEGIN	
    SET NOCOUNT ON
    IF ( @pi_object_type = 212/*Tags*/ )
    BEGIN
		-- Get scope_id, item_id, tag code and last char of tag code
		select 
			@li_scope_id = scope_id, 
			@li_item_id = item_id, 
			@ls_code = code, 
			@ls_last_char = RIGHT(code, 1)
		from tags t join objects o on t.tag_id = o.object_id and o.object_type = 212
		where tag_id = @pi_object_id
		
		IF (
			-- Current has Suffix A and exists non-suffixed
			(@ls_last_char = 'A' 
				and 0 < (
					select COUNT(1) 
					from tags t join objects o on t.tag_id = o.object_id and o.object_type = 212
					where o.scope_id = @li_scope_id and item_id = @li_item_id
					and (code + 'A') = @ls_code
				)
			) 
			or -- Current is non-suffixed and Suffix A exists
			(@ls_last_char <> 'A'
				and 0 < (
					select COUNT(1) 
					from tags t join objects o on t.tag_id = o.object_id and o.object_type = 212
					where o.scope_id = @li_scope_id and item_id = @li_item_id 
					and code = (@ls_code + 'A')
				)
			)
		)
		BEGIN
			declare @msg nvarchar(255) = 'Multiple component designators of suffix A not allowed: '+ @ls_code
			exec ebp_raise_error @msg , @pi_called_by
			RETURN 1 -- Failure
		END

	END
    RETURN 0 -- Success
END

/*
select * from tags where code like '99A-40003%'
begin transaction
	declare 
		@pi_item_id			int,
		@ps_code			nvarchar(100),
		@pi_gvitem_id		int,
		@pi_class_id		int,
		@pi_tag_id			int
	
	select @pi_item_id = item_id, @ps_code = '99A-40004A', @pi_gvitem_id = gvitem_id, @pi_class_id = class_id	
	-- select @pi_item_id = item_id, @ps_code = '99A-40004B', @pi_gvitem_id = gvitem_id, @pi_class_id = class_id	
	-- select @pi_item_id = item_id, @ps_code = code + 'A', @pi_gvitem_id = gvitem_id, @pi_class_id = class_id
	from tags where code = '99A-40003'
	
	begin try
		exec dbo.ebp_add_tag @pi_item_id, @ps_code, null, @pi_class_id, 'name', null, 'N', 'P', @pi_gvitem_id, 1, '', 1, @pi_tag_id OUT
		commit
	end try
	begin catch
		rollback
	end catch
select * from tags where tag_id = @pi_tag_id
select * from tags where code like '99A-40003%'
*/

/*
select * from tags where code like '99A-40003%'

begin transaction
declare @tag_id int = (select tag_id from tags where code = '99A-40003A')
if @tag_id is not null
	exec dbo.ebp_del_tag @tag_id, 1
commit

select * from tags where code like '99A-40003%'
*/
GO





---------------------------------------------------------
PRINT 'Register Event Handlers'
---------------------------------------------------------

DECLARE @event_name varchar(255)
DECLARE @sp_name varchar(255)
DECLARE @li_event_id int;

SET @event_name = N'OnAttributeChanged'
SET @sp_name = N'Suncor_TagState_OnAttributeChanged'

BEGIN

    SELECT @li_event_id = event_id from db_events(NOLOCK) WHERE name = @event_name

    IF NOT EXISTS ( SELECT 1 FROM db_event_handlers(NOLOCK) 
              WHERE event_id = @li_event_id AND code_ref = @sp_name )
    BEGIN
       EXEC ebp_add_db_event_handler @li_event_id, @sp_name, 0, N'N',1
    END
END   

SET @event_name = N'OnApprovalStatusChanged'
SET @sp_name = N'Suncor_AutoTagState_OnApprovalStatusChanged'

BEGIN

    SELECT @li_event_id = event_id from db_events(NOLOCK) WHERE name = @event_name

    IF NOT EXISTS ( SELECT 1 FROM db_event_handlers(NOLOCK) 
              WHERE event_id = @li_event_id AND code_ref = @sp_name )
    BEGIN
       EXEC ebp_add_db_event_handler @li_event_id, @sp_name, 0, N'N',1
    END
END   

SET @event_name = N'OnRelationshipAdded'
SET @sp_name = N'Suncor_AutoTagState_OnRelationshipAdded'

BEGIN

    SELECT @li_event_id = event_id from db_events(NOLOCK) WHERE name = @event_name

    IF NOT EXISTS ( SELECT 1 FROM db_event_handlers(NOLOCK) 
              WHERE event_id = @li_event_id AND code_ref = @sp_name )
    BEGIN
       EXEC ebp_add_db_event_handler @li_event_id, @sp_name, 0, N'N',1
    END
END   

SET @event_name = N'OnObjectAdded'
SET @sp_name = N'Suncor_TagSuffixA_OnObjectAddedOrChanged'

BEGIN

    SELECT @li_event_id = event_id from db_events(NOLOCK) WHERE name = @event_name

    IF NOT EXISTS ( SELECT 1 FROM db_event_handlers(NOLOCK) 
              WHERE event_id = @li_event_id AND code_ref = @sp_name )
    BEGIN
       EXEC ebp_add_db_event_handler @li_event_id, @sp_name, 0, N'N',1
    END
END   

SET @event_name = N'OnObjectChanged'
SET @sp_name = N'Suncor_TagSuffixA_OnObjectAddedOrChanged'

BEGIN

    SELECT @li_event_id = event_id from db_events(NOLOCK) WHERE name = @event_name

    IF NOT EXISTS ( SELECT 1 FROM db_event_handlers(NOLOCK) 
              WHERE event_id = @li_event_id AND code_ref = @sp_name )
    BEGIN
       EXEC ebp_add_db_event_handler @li_event_id, @sp_name, 0, N'N',1
    END
END   

