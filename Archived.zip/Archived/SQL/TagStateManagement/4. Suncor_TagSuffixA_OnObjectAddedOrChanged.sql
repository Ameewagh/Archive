/****** Object:  StoredProcedure [dbo].[Suncor_TagSuffixA_OnObjectAddedOrChanged]    Script Date: 11/02/2015 13:12:24 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Suncor_TagSuffixA_OnObjectAddedOrChanged]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Suncor_TagSuffixA_OnObjectAddedOrChanged]
GO

/****** Object:  StoredProcedure [dbo].[Suncor_TagSuffixA_OnObjectAddedOrChanged]    Script Date: 11/02/2015 13:12:24 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
1. Block creation of a tag with a "multiple component" designator of "A" 
(meaning tag number ends in "A") if the base tag exists. 
Example: Do not create 96GM-5001A if 96GM-5001 exists.
Here we mean literally “A” only. Values of “B”, “C” etc. are not subject to this check. 
2. Block creation of a tag with NO multiple component designator 
(meaning tag number does NOT end in any letter) if the base tag PLUS "A" exists. 
Example: Do not create 96GM-5001 if 96GM-5001A exists.
*/
CREATE PROCEDURE [dbo].[Suncor_TagSuffixA_OnObjectAddedOrChanged]
(
    @ps_sender NVARCHAR(255),
	@pi_called_by INT,
	@pi_object_id INT,
	@pi_object_type INT
)
AS
DECLARE
    @li_error       INT,
    @li_scope_id	INT,
    @li_item_id		INT,
    @ls_code		NVARCHAR(100),
    @ls_last_char	NVARCHAR(1)
BEGIN	
    SET NOCOUNT ON
    IF ( @pi_object_type = 212/*Tags*/ )
    BEGIN
		-- Get scope_id, item_id, tag code and last char of tag code
		select 
			@li_scope_id = scope_id, 
			@li_item_id = item_id, 
			@ls_code = code, 
			@ls_last_char = RIGHT(code, 1)
		from tags t join objects o on t.tag_id = o.object_id and o.object_type = 212
		where tag_id = @pi_object_id
		
		IF (
			-- Current has Suffix A and exists non-suffixed
			(@ls_last_char = 'A' 
				and 0 < (
					select COUNT(1) 
					from tags t join objects o on t.tag_id = o.object_id and o.object_type = 212
					where o.scope_id = @li_scope_id and item_id = @li_item_id
					and (code + 'A') = @ls_code
				)
			) 
			or -- Current is non-suffixed and Suffix A exists
			(@ls_last_char <> 'A'
				and 0 < (
					select COUNT(1) 
					from tags t join objects o on t.tag_id = o.object_id and o.object_type = 212
					where o.scope_id = @li_scope_id and item_id = @li_item_id 
					and code = (@ls_code + 'A')
				)
			)
		)
		BEGIN
			declare @msg nvarchar(255) = 'Multiple component designators of suffix A not allowed: '+ @ls_code
			exec ebp_raise_error @msg , @pi_called_by
			RETURN 1 -- Failure
		END

	END
    RETURN 0 -- Success
END

/*
select * from tags where code like '99A-40003%'
begin transaction
	declare 
		@pi_item_id			int,
		@ps_code			nvarchar(100),
		@pi_gvitem_id		int,
		@pi_class_id		int,
		@pi_tag_id			int
	
	select @pi_item_id = item_id, @ps_code = '99A-40004A', @pi_gvitem_id = gvitem_id, @pi_class_id = class_id	
	-- select @pi_item_id = item_id, @ps_code = '99A-40004B', @pi_gvitem_id = gvitem_id, @pi_class_id = class_id	
	-- select @pi_item_id = item_id, @ps_code = code + 'A', @pi_gvitem_id = gvitem_id, @pi_class_id = class_id
	from tags where code = '99A-40003'
	
	begin try
		exec dbo.ebp_add_tag @pi_item_id, @ps_code, null, @pi_class_id, 'name', null, 'N', 'P', @pi_gvitem_id, 1, '', 1, @pi_tag_id OUT
		commit
	end try
	begin catch
		rollback
	end catch
select * from tags where tag_id = @pi_tag_id
select * from tags where code like '99A-40003%'
*/

/*
select * from tags where code like '99A-40003%'

begin transaction
declare @tag_id int = (select tag_id from tags where code = '99A-40003A')
if @tag_id is not null
	exec dbo.ebp_del_tag @tag_id, 1
commit

select * from tags where code like '99A-40003%'
*/
GO

