IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SUN_FLOC_Validation_eB]'))
DROP VIEW [dbo].[SUN_FLOC_Validation_eB]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[SUN_FLOC_Validation_eB]
AS 

select 
-- Keys
  vi.vitem_id
, vgm.gvitem_id
, attribs.ObjectNumber

-- FLOC attributes
, vitem_code as Name
, vi.description as Description
, LTRIM(RTRIM(SUBSTRING(attribs.ABCIndicator,1, CHARINDEX(' - ', attribs.ABCIndicator)))) as ABCIndicator
, LTRIM(RTRIM(SUBSTRING(attribs.AuthorizationGroup,1, CHARINDEX(' - ', attribs.AuthorizationGroup)))) as AuthorizationGroup
, LTRIM(RTRIM(SUBSTRING(attribs.CatalogProfile,1, CHARINDEX(' - ', attribs.CatalogProfile)))) as CatalogProfile
, LTRIM(RTRIM(SUBSTRING(attribs.Category,1, CHARINDEX(' - ', attribs.Category)))) as Category
, attribs.ChangedOn
, LTRIM(RTRIM(SUBSTRING(attribs.Class,1, CHARINDEX(' - ', attribs.Class)))) as Class
, attribs.CostCenter
, attribs.Location
, attribs.MainWorkCenter
, attribs.MainWorkCenterPlant
, LTRIM(RTRIM(SUBSTRING(attribs.MaintenancePlant,1, CHARINDEX(' - ', attribs.MaintenancePlant)))) as MaintenancePlant
, LTRIM(RTRIM(SUBSTRING(attribs.ObjType,1, CHARINDEX(' - ', attribs.ObjType)))) as ObjType
, attribs.PlannerGroup
, LTRIM(RTRIM(SUBSTRING(attribs.PlanningPlant,1, CHARINDEX(' - ', attribs.PlanningPlant)))) as PlanningPlant
, attribs.PlantSection
, attribs.Room
, attribs.SortField
, sysstat.SystemStatuses
, attribs.SystemStatusMerged
, userstat.UserStatuses
, attribs.UserStatusMerged

-- Related Tag
, t.code as Related_Tag_Code

from vitems vi (nolock)
inner join vitem_grp_members vgm (nolock) on vi.vitem_id = vgm.vitem_id

-- Join to a super fast PIVOT of all (single-value) attributes in the char_data table.
left join (
		select 
			  object_id
			, MAX(case char_name when 'ABC Indicator' then char_value end) ABCIndicator
			, MAX(case char_name when 'Authorization Group' then char_value end) AuthorizationGroup
			, MAX(case char_name when 'Catalog Profile' then char_value end) CatalogProfile
			, MAX(case char_name when 'Category' then char_value end) Category
			, MAX(case char_name when 'Changed On' then date_value end) ChangedOn	-- date data type
			, MAX(case char_name when 'Class' then char_value end) Class
			, MAX(case char_name when 'Cost Center' then char_value end) CostCenter
			, MAX(case char_name when 'Location' then char_value end) Location
			, MAX(case char_name when 'Main Work Center' then char_value end) MainWorkCenter
			, MAX(case char_name when 'Main Work Center Plant' then char_value end) MainWorkCenterPlant
			, MAX(case char_name when 'Maintenance Plant' then char_value end) MaintenancePlant
			, MAX(case char_name when 'Obj Type' then char_value end) ObjType
			, MAX(case char_name when 'Object Number' then char_value end) ObjectNumber
			, MAX(case char_name when 'Planner Group' then char_value end) PlannerGroup
			, MAX(case char_name when 'Planning Plant' then char_value end) PlanningPlant
			, MAX(case char_name when 'Plant Section' then char_value end) PlantSection
			, MAX(case char_name when 'Room' then char_value end) Room
			, MAX(case char_name when 'Sort Field' then char_value end) SortField
			, MAX(case char_name when 'System Status Merged' then char_value end) SystemStatusMerged
			, MAX(case char_name when 'User Status Merged' then char_value end) UserStatusMerged
		from (
			select 
			  cd.object_id 
			 ,c.char_name
			 ,cd.char_value
			 ,cd.date_value	-- for ChangedOn date
			from char_data cd (nolock)
			inner join characteristics c (nolock) on cd.char_id = c.char_id
			where c.object_type = 123
			) raw_attribs
		group by object_id
	) attribs on vgm.gvitem_id = attribs.object_id

	-- Join System Statuses, concatenated
	left join (
			select ss.object_id, ss.SystemStatuses
			from (
				select distinct ss2.object_id,
					LTRIM(RTRIM((
						select LTRIM(RTRIM(SUBSTRING(ss1.char_value,1, CHARINDEX(' - ', ss1.char_value)))) + ' ' as [text()]
						from char_data_mv ss1 (nolock)
						inner join characteristics css (nolock) on ss1.char_id = css.char_id and css.char_name = 'System Status' and css.object_type = 123
						where ss1.object_id = ss2.object_id
						for XML PATH ('')
					))) SystemStatuses
				from char_data_mv ss2 (nolock)
			) ss
		) sysstat on vgm.gvitem_id = sysstat.object_id

	-- Join User Statuses, concatenated
	left join (
			select us.object_id, us.UserStatuses
			from (
				select distinct us2.object_id,
					LTRIM(RTRIM((
						select LTRIM(RTRIM(SUBSTRING(us1.char_value,1, CHARINDEX(' - ', us1.char_value)))) + ' ' as [text()]
						from char_data_mv us1 (nolock)
						inner join characteristics cus (nolock) on us1.char_id = cus.char_id and cus.char_name = 'User Status' and cus.object_type = 123
						where us1.object_id = us2.object_id
						for XML PATH ('')
					))) UserStatuses
				from char_data_mv us2 (nolock)
			) us
		) userstat on vgm.gvitem_id = userstat.object_id

	-- Join related Tag
	left join relationships r on 
		vgm.gvitem_id = r.right_object_id
		and r.rel_type_id = 54	-- FLOC to Tag relationships only. Can be only one Tag per FLOC so this join should not generate additonal rows.
		and r.template = 'N' -- not a template
	left join tags t on
		r.left_object_id = t.tag_id
		and t.template = 'N'

-- Get just Grouped Virtual Items in the FLOC group
where vgm.control_id = 40


GO
