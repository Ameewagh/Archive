select * from SUN_FLOC_Validation_SAP_Stage order by FunctLoc

select * from SUN_FLOC_Validation_eB order by ObjectNumber

select * from SUN_FLOC_Validation_Comparison where EB_Name = 'FB1-P091'
order by EB_ObjectNumber

select * from SUN_FLOC_Validation_Differences order by EB_ObjectNumber


-- nulll in ChangedOn means the brand new record
select * from SUN_SAP_Project_WBS