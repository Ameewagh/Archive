IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SUN_FLOC_Validation_Comparison]'))
DROP VIEW [dbo].[SUN_FLOC_Validation_Comparison]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[SUN_FLOC_Validation_Comparison]
AS 
-- SQL to compare SAP and eB FLOC data.
-- Requires table SUN_FLOC_Validation_SAP_Stage and view SUN_FLOC_Validation_eB

select 
	-- 1. COMPARISON FLAG COLUMNS

	-- identify if FLOC is found in one system and not the other
	case when (s.FunctLoc is not null) and (e.ObjectNumber is null) then 1 else 0 end as missing
	, case when (s.FunctLoc is null) and (e.ObjectNumber is not null) then 1 else 0 end as extra
	-- identify differences in attribute values
	-- handle NULLs using ISNULL() to substitute a reasonable value in place of any NULLs.
	--		using an empty string '' for NULL char values
	--		using a fixed date value of '1900-01-01 00:00:00.000' for NULL date values
	, case when s.FunctLocLabel <> ISNULL(e.Name,'') then 1 else 0 end as wrong_name
	-- Description:		A period '.' in eB represents a blank '' in SAP, since in eB the Description is a required field
	--					Ignore leading and trailing whitespace in the Description field. eB trims on import, so we ignore these differences
	, case when LTRIM(RTRIM(s.FunctLocDesc)) <> case e.Description when '.' then '' else LTRIM(RTRIM(ISNULL(e.Description,''))) end then 1 else 0 end as wrong_description
	, case when s.ABCInd <> ISNULL(e.ABCIndicator,'') then 1 else 0 end as wrong_abcindicator
	, case when s.FunctLocCat <> ISNULL(e.Category,'') then 1 else 0 end as wrong_category
	, case when s.ObjectType <> ISNULL(e.ObjType,'') then 1 else 0 end as wrong_objecttype
	, case when s.Class <> ISNULL(e.Class,'') then 1 else 0 end as wrong_class
	, case when dbo.SUN_split_sort_merge_string(s.SysStatus) <> dbo.SUN_split_sort_merge_string(ISNULL(e.SystemStatuses,'')) then 1 else 0 end as wrong_systemstatus
	, case when s.SysStatus <> ISNULL(e.SystemStatusMerged,'') then 1 else 0 end as wrong_systemstatusmerged	
	, case when dbo.SUN_split_sort_merge_string(s.UserStatus) <> dbo.SUN_split_sort_merge_string(ISNULL(e.UserStatuses,'')) then 1 else 0 end as wrong_userstatus
	, case when s.UserStatus <> ISNULL(e.UserStatusMerged,'') then 1 else 0 end as wrong_userstatusmerged
	, case when s.SortField <> ISNULL(e.SortField,'') then 1 else 0 end as wrong_sortfield
	, case when s.MaintPlant <> ISNULL(e.MaintenancePlant,'') then 1 else 0 end as wrong_maintplant
	, case when s.AuthGrp <> ISNULL(e.AuthorizationGroup,'') then 1 else 0 end as wrong_authgroup
	, dbo.sun_compare_compounds(s.Location, s.LocDesc, e.Location) as wrong_location
	, case when s.Room <> ISNULL(e.Room,'') then 1 else 0 end as wrong_room
	, dbo.sun_compare_compounds(s.PlSectn, s.PersResp, e.PlantSection) as wrong_plantsection
	, dbo.sun_compare_compounds(s.WorkCtr, s.WorkCtrDesc, e.MainWorkCenter) as wrong_workcenter
	, case when s.WorkCtrPlant <> ISNULL(e.MainWorkCenterPlant,'') then 1 else 0 end as wrong_workcenterplant
	, dbo.sun_compare_compounds(s.CostCtr, s.CostCtrDesc, e.CostCenter) as wrong_costcenter
	, case when s.PlngPlant <> ISNULL(e.PlanningPlant,'') then 1 else 0 end as wrong_planningplant
	, dbo.sun_compare_compounds(s.PlannerGrp, s.PlannerGrpName, e.PlannerGroup) as wrong_plannergroup
	, case when s.CatProf <> ISNULL(e.CatalogProfile,'') then 1 else 0 end as wrong_catalogprofile
	, case when ISNULL(Cast(s.ChangedDte as datetime),'1900-01-01 00:00:00.000') <> ISNULL(e.ChangedOn,'1900-01-01 00:00:00.000') then 1 else 0 end as wrong_changedon
	-- Only flag an error if there is a related Tag. If Tag was not in eB then no error.
	, case when (e.Related_Tag_Code is not NULL) and (s.SortField <> ISNULL(e.Related_Tag_Code,'')) then 1 else 0 end as wrong_related_tag
	
	-- 2. SAP STAGING TABLE COLUMNS
	
	, s.LoadDateTime as SAP_LoadDateTime
	, s.FunctLoc as SAP_FunctLoc
	, s.FunctLocLabel as SAP_FunctLocLabel
	, s.FunctLocDesc as SAP_FunctLocDesc
	, s.ABCInd as SAP_ABCInd
	, s.FunctLocCat as SAP_FunctLocCat
	, s.ObjectType as SAP_ObjectType
	, s.Class as SAP_Class
	, s.SysStatus as SAP_SysStatus
	, s.UserStatus as SAP_UserStatus
	, s.SortField as SAP_SortField
	, s.MaintPlant as SAP_MaintPlant
	, s.SupFunctLoc as SAP_SupFunctLoc
	, s.SupFunctLocLabel as SAP_SupFunctLocLabel
	, s.AuthGrp as SAP_AuthGrp
	, s.Location as SAP_Location
	, s.LocDesc as SAP_LocDesc
	, s.Room as SAP_Room
	, s.PlSectn as SAP_PlSectn
	, s.PersResp as SAP_PersResp
	, s.WorkCtr as SAP_WorkCtr
	, s.WorkCtrDesc as SAP_WorkCtrDesc
	, s.WorkCtrPlant as SAP_WorkCtrPlant
	, s.CostCtr as SAP_CostCtr
	, s.CostCtrDesc as SAP_CostCtrDesc
	, s.PlngPlant as SAP_PlngPlant
	, s.PlannerGrp as SAP_PlannerGrp
	, s.PlannerGrpName as SAP_PlannerGrpName
	, s.CatProf as SAP_CatProf
	, s.ChangedDte as SAP_ChangedDte
	
	-- 3. EB FLATTENED VIEW COLUMNS
	
	, e.vitem_id as EB_vitem_id
	, e.gvitem_id as EB_gvitem_id
	, e.ObjectNumber as EB_ObjectNumber
	, e.Name as EB_Name
	, e.Description as EB_Description
	, e.ABCIndicator as EB_ABCIndicator
	, e.AuthorizationGroup as EB_AuthorizationGroup
	, e.CatalogProfile as EB_CatalogProfile
	, e.Category as EB_Category
	, e.ChangedOn as EB_ChangedOn
	, e.Class as EB_Class
	, e.CostCenter as EB_CostCenter
	, e.Location as EB_Location
	, e.MainWorkCenter as EB_MainWorkCenter
	, e.MainWorkCenterPlant as EB_MainWorkCenterPlant
	, e.MaintenancePlant as EB_MaintenancePlant
	, e.ObjType as EB_ObjType
	, e.PlannerGroup as EB_PlannerGroup
	, e.PlanningPlant as EB_PlanningPlant
	, e.PlantSection as EB_PlantSection
	, e.Room as EB_Room
	, e.SortField as EB_SortField
	, e.SystemStatuses as EB_SystemStatuses
	, e.SystemStatusMerged as EB_SystemStatusMerged
	, e.UserStatuses as EB_UserStatuses
	, e.UserStatusMerged as EB_UserStatusMerged
	, e.Related_Tag_Code as EB_Related_Tag_Code
	
from SUN_FLOC_Validation_SAP_Stage s
-- Outer join the two sides so we find SAP rows with no eB row, and vice versa:
full join SUN_FLOC_Validation_eB e on s.FunctLoc = e.ObjectNumber

GO
