IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SUN_FLOC_Validation_SAP_Stage]') AND type in (N'U'))
DROP TABLE [dbo].[SUN_FLOC_Validation_SAP_Stage]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SUN_FLOC_Validation_SAP_Stage](
	[LoadDateTime] [datetime] NULL,
	rownum int NULL,
	[FunctLoc] [nvarchar](255) NULL,
	[FunctLocLabel] [nvarchar](255) NULL,
	[FunctLocDesc] [nvarchar](255) NULL,
	[ABCInd] [nvarchar](255) NULL,
	[FunctLocCat] [nvarchar](255) NULL,
	[ObjectType] [nvarchar](255) NULL,
	[Class] [nvarchar](255) NULL,
	[SysStatus] [nvarchar](255) NULL,
	[UserStatus] [nvarchar](255) NULL,
	[SortField] [nvarchar](255) NULL,
	[MaintPlant] [nvarchar](255) NULL,
	[SupFunctLoc] [nvarchar](255) NULL,
	[SupFunctLocLabel] [nvarchar](255) NULL,
	[AuthGrp] [nvarchar](255) NULL,
	[Location] [nvarchar](255) NULL,
	[LocDesc] [nvarchar](255) NULL,
	[Room] [nvarchar](255) NULL,
	[PlSectn] [nvarchar](255) NULL,
	[PersResp] [nvarchar](255) NULL,
	[WorkCtr] [nvarchar](255) NULL,
	[WorkCtrDesc] [nvarchar](255) NULL,
	[WorkCtrPlant] [nvarchar](255) NULL,
	[CostCtr] [nvarchar](255) NULL,
	[CostCtrDesc] [nvarchar](255) NULL,
	[PlngPlant] [nvarchar](255) NULL,
	[PlannerGrp] [nvarchar](255) NULL,
	[PlannerGrpName] [nvarchar](255) NULL,
	[CatProf] [nvarchar](255) NULL,
	[ChangedDte] [nvarchar](255) NULL
) ON [PRIMARY]

GO


