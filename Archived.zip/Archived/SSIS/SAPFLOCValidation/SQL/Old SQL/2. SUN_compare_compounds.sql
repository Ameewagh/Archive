IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SUN_compare_compounds]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[SUN_compare_compounds]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create function [dbo].[SUN_compare_compounds](
	@first nvarchar(max), 
	@second nvarchar(max), 
	-- @delim nvarchar(max), 
	@compound nvarchar(max)
) returns int
-- This function takes three parameters: Code, Description, and Merged
-- it returns 0 if the first two parameters concatenated e.g. "Code - Description"
-- are equivalent to the third (Merged) parameter, which is already in the format "Code - Description".
-- It returns a 1 if they are NOT equivalent.
begin
	set @first = isnull(@first, '')
	set @second = isnull(@second, '')
	set @compound = isnull(@compound, '')
	if @first = '' and @second = '' and @compound = '' return 0
	if (@first + ' - ' + @second) = @compound return 0
	return 1 -- different
end
/* -- testing 
select dbo.SUN_compare_compounds('', '', '')		--0
select dbo.SUN_compare_compounds('', '', null)		--0
select dbo.SUN_compare_compounds(null, null, null)	--0	we treat null and empty string as same thing
select dbo.SUN_compare_compounds('a', 'b', 'a - b')	--0
select dbo.SUN_compare_compounds('a', 'b', 'x - y')	--1
select dbo.SUN_compare_compounds('', 'b', ' - b')	--0
select dbo.SUN_compare_compounds('', '', '    ')	--0	sql compare ignores trailing spaces
select dbo.SUN_compare_compounds('', 'b', ' - b  ')	--0	sql compare ignores trailing spaces
*/

