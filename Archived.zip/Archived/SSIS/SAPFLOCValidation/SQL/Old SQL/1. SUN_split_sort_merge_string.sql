/****** Object:  UserDefinedFunction [dbo].[SUN_split_sort_merge_string]    Script Date: 10/16/2015 12:26:42 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SUN_split_sort_merge_string]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[SUN_split_sort_merge_string]
GO

/****** Object:  UserDefinedFunction [dbo].[SUN_split_sort_merge_string]    Script Date: 10/16/2015 12:26:42 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE FUNCTION [dbo].[SUN_split_sort_merge_string] ( @stringToSplit NVARCHAR(MAX) )
RETURNS
 NVARCHAR(MAX)
AS
BEGIN

-- This function takes an input string like 'XXX AAA YYYY BBB' and sorts the values between the spaces,
-- returning a string like 'AAA BBB XXX YYYY'.
-- It strips off extra whitespace.

 DECLARE @tempList TABLE ([Name] [nvarchar] (500))
 DECLARE @returnValue NVARCHAR(MAX)
 DECLARE @name NVARCHAR(255)
 DECLARE @pos INT
 
 -- remove extra whitepspace to prevent FOR XML from generating XML entity codes
 set @stringToSplit = LTRIM(RTRIM(replace(replace(replace(@stringToSplit,' ','<>'),'><',''),'<>',' ')))
 
 WHILE CHARINDEX(' ', @stringToSplit) > 0
 BEGIN
  SELECT @pos  = CHARINDEX(' ', @stringToSplit)  
  SELECT @name = SUBSTRING(@stringToSplit, 1, @pos-1)

  INSERT INTO @tempList
  SELECT @name

  SELECT @stringToSplit = SUBSTRING(@stringToSplit, @pos+1, LEN(@stringToSplit)-@pos)
 END

 INSERT INTO @tempList
 SELECT @stringToSplit

 set @returnValue = (	
	Select t.Name + ' ' AS [text()]
	From @tempList t
	ORDER BY t.Name
	For XML PATH (''))

 RETURN @returnValue
END

GO


