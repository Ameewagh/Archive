--
-- SAP FLOC Validation - Deployment Script v1.sql
--

/****** Object:  Table [dbo].[SUN_FLOC_Validation_SAP_Stage]    Script Date: 11/17/2015 12:20:32 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SUN_FLOC_Validation_SAP_Stage]') AND type in (N'U'))
DROP TABLE [dbo].[SUN_FLOC_Validation_SAP_Stage]
GO

/****** Object:  Table [dbo].[SUN_FLOC_Validation_SAP_Stage]    Script Date: 11/17/2015 12:20:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SUN_FLOC_Validation_SAP_Stage](
	[LoadDateTime] [datetime] NULL,
	[rownum] [int] NULL,
	[FunctLoc] [nvarchar](255) NULL,
	[FunctLocLabel] [nvarchar](255) NULL,
	[FunctLocDesc] [nvarchar](255) NULL,
	[ABCInd] [nvarchar](255) NULL,
	[FunctLocCat] [nvarchar](255) NULL,
	[ObjectType] [nvarchar](255) NULL,
	[Class] [nvarchar](255) NULL,
	[SysStatus] [nvarchar](255) NULL,
	[UserStatus] [nvarchar](255) NULL,
	[SortField] [nvarchar](255) NULL,
	[MaintPlant] [nvarchar](255) NULL,
	[SupFunctLoc] [nvarchar](255) NULL,
	[SupFunctLocLabel] [nvarchar](255) NULL,
	[AuthGrp] [nvarchar](255) NULL,
	[Location] [nvarchar](255) NULL,
	[LocDesc] [nvarchar](255) NULL,
	[Room] [nvarchar](255) NULL,
	[PlSectn] [nvarchar](255) NULL,
	[PersResp] [nvarchar](255) NULL,
	[WorkCtr] [nvarchar](255) NULL,
	[WorkCtrDesc] [nvarchar](255) NULL,
	[WorkCtrPlant] [nvarchar](255) NULL,
	[CostCtr] [nvarchar](255) NULL,
	[CostCtrDesc] [nvarchar](255) NULL,
	[PlngPlant] [nvarchar](255) NULL,
	[PlannerGrp] [nvarchar](255) NULL,
	[PlannerGrpName] [nvarchar](255) NULL,
	[CatProf] [nvarchar](255) NULL,
	[ChangedDte] [nvarchar](255) NULL
) ON [PRIMARY]

GO


/****** Object:  View [dbo].[SUN_FLOC_Validation_eB]    Script Date: 11/17/2015 12:20:53 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SUN_FLOC_Validation_eB]'))
DROP VIEW [dbo].[SUN_FLOC_Validation_eB]
GO

/****** Object:  View [dbo].[SUN_FLOC_Validation_eB]    Script Date: 11/17/2015 12:20:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[SUN_FLOC_Validation_eB]
AS 

select 
-- Keys
  vi.vitem_id
, vgm.gvitem_id
, attribs.ObjectNumber

-- FLOC attributes
, vitem_code as Name
, vi.description as Description
, LTRIM(RTRIM(SUBSTRING(attribs.ABCIndicator,1, CHARINDEX(' - ', attribs.ABCIndicator)))) as ABCIndicator
, LTRIM(RTRIM(SUBSTRING(attribs.AuthorizationGroup,1, CHARINDEX(' - ', attribs.AuthorizationGroup)))) as AuthorizationGroup
, LTRIM(RTRIM(SUBSTRING(attribs.CatalogProfile,1, CHARINDEX(' - ', attribs.CatalogProfile)))) as CatalogProfile
, LTRIM(RTRIM(SUBSTRING(attribs.Category,1, CHARINDEX(' - ', attribs.Category)))) as Category
, attribs.ChangedOn
, LTRIM(RTRIM(SUBSTRING(attribs.Class,1, CHARINDEX(' - ', attribs.Class)))) as Class
, attribs.CostCenter
, attribs.Location
, attribs.MainWorkCenter
, attribs.MainWorkCenterPlant
, LTRIM(RTRIM(SUBSTRING(attribs.MaintenancePlant,1, CHARINDEX(' - ', attribs.MaintenancePlant)))) as MaintenancePlant
, LTRIM(RTRIM(SUBSTRING(attribs.ObjType,1, CHARINDEX(' - ', attribs.ObjType)))) as ObjType
, attribs.PlannerGroup
, LTRIM(RTRIM(SUBSTRING(attribs.PlanningPlant,1, CHARINDEX(' - ', attribs.PlanningPlant)))) as PlanningPlant
, attribs.PlantSection
, attribs.Room
, attribs.SortField
, sysstat.SystemStatuses
, attribs.SystemStatusMerged
, userstat.UserStatuses
, attribs.UserStatusMerged

-- Related Tag
, t.code as Related_Tag_Code

from vitems vi (nolock)
inner join vitem_grp_members vgm (nolock) on vi.vitem_id = vgm.vitem_id

-- Join to a super fast PIVOT of all (single-value) attributes in the char_data table.
left join (
		select 
			  object_id
			, MAX(case char_name when 'ABC Indicator' then char_value end) ABCIndicator
			, MAX(case char_name when 'Authorization Group' then char_value end) AuthorizationGroup
			, MAX(case char_name when 'Catalog Profile' then char_value end) CatalogProfile
			, MAX(case char_name when 'Category' then char_value end) Category
			, MAX(case char_name when 'Changed On' then date_value end) ChangedOn	-- date data type
			, MAX(case char_name when 'Class' then char_value end) Class
			, MAX(case char_name when 'Cost Center' then char_value end) CostCenter
			, MAX(case char_name when 'Location' then char_value end) Location
			, MAX(case char_name when 'Main Work Center' then char_value end) MainWorkCenter
			, MAX(case char_name when 'Main Work Center Plant' then char_value end) MainWorkCenterPlant
			, MAX(case char_name when 'Maintenance Plant' then char_value end) MaintenancePlant
			, MAX(case char_name when 'Obj Type' then char_value end) ObjType
			, MAX(case char_name when 'Object Number' then char_value end) ObjectNumber
			, MAX(case char_name when 'Planner Group' then char_value end) PlannerGroup
			, MAX(case char_name when 'Planning Plant' then char_value end) PlanningPlant
			, MAX(case char_name when 'Plant Section' then char_value end) PlantSection
			, MAX(case char_name when 'Room' then char_value end) Room
			, MAX(case char_name when 'Sort Field' then char_value end) SortField
			, MAX(case char_name when 'System Status Merged' then char_value end) SystemStatusMerged
			, MAX(case char_name when 'User Status Merged' then char_value end) UserStatusMerged
		from (
			select 
			  cd.object_id 
			 ,c.char_name
			 ,cd.char_value
			 ,cd.date_value	-- for ChangedOn date
			from char_data cd (nolock)
			inner join characteristics c (nolock) on cd.char_id = c.char_id
			where c.object_type = 123
			) raw_attribs
		group by object_id
	) attribs on vgm.gvitem_id = attribs.object_id

	-- Join System Statuses, concatenated
	left join (
			select ss.object_id, ss.SystemStatuses
			from (
				select distinct ss2.object_id,
					LTRIM(RTRIM((
						select LTRIM(RTRIM(SUBSTRING(ss1.char_value,1, CHARINDEX(' - ', ss1.char_value)))) + ' ' as [text()]
						from char_data_mv ss1 (nolock)
						inner join characteristics css (nolock) on ss1.char_id = css.char_id and css.char_name = 'System Status' and css.object_type = 123
						where ss1.object_id = ss2.object_id
						for XML PATH ('')
					))) SystemStatuses
				from char_data_mv ss2 (nolock)
			) ss
		) sysstat on vgm.gvitem_id = sysstat.object_id

	-- Join User Statuses, concatenated
	left join (
			select us.object_id, us.UserStatuses
			from (
				select distinct us2.object_id,
					LTRIM(RTRIM((
						select LTRIM(RTRIM(SUBSTRING(us1.char_value,1, CHARINDEX(' - ', us1.char_value)))) + ' ' as [text()]
						from char_data_mv us1 (nolock)
						inner join characteristics cus (nolock) on us1.char_id = cus.char_id and cus.char_name = 'User Status' and cus.object_type = 123
						where us1.object_id = us2.object_id
						for XML PATH ('')
					))) UserStatuses
				from char_data_mv us2 (nolock)
			) us
		) userstat on vgm.gvitem_id = userstat.object_id

	-- Join related Tag
	left join relationships r on 
		vgm.gvitem_id = r.right_object_id
		and r.rel_type_id = 54	-- FLOC to Tag relationships only. Can be only one Tag per FLOC so this join should not generate additonal rows.
		and r.template = 'N' -- not a template
	left join tags t on
		r.left_object_id = t.tag_id
		and t.template = 'N'

-- Get just Grouped Virtual Items in the FLOC group
where vgm.control_id = 40



GO


/****** Object:  View [dbo].[SUN_FLOC_Validation_Comparison]    Script Date: 11/17/2015 12:21:08 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SUN_FLOC_Validation_Comparison]'))
DROP VIEW [dbo].[SUN_FLOC_Validation_Comparison]
GO

/****** Object:  View [dbo].[SUN_FLOC_Validation_Comparison]    Script Date: 11/17/2015 12:21:08 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[SUN_FLOC_Validation_Comparison]
AS 
-- SQL to compare SAP and eB FLOC data.
-- Requires table SUN_FLOC_Validation_SAP_Stage and view SUN_FLOC_Validation_eB

select 
	-- 1. COMPARISON FLAG COLUMNS

	-- identify if FLOC is found in one system and not the other
	case when (s.FunctLoc is not null) and (e.ObjectNumber is null) then 1 else 0 end as missing
	, case when (s.FunctLoc is null) and (e.ObjectNumber is not null) then 1 else 0 end as extra
	-- identify differences in attribute values
	-- handle NULLs using ISNULL() to substitute a reasonable value in place of any NULLs.
	--		using an empty string '' for NULL char values
	--		using a fixed date value of '1900-01-01 00:00:00.000' for NULL date values
	, case when s.FunctLocLabel <> ISNULL(e.Name,'') then 1 else 0 end as wrong_name
	-- Description:		A period '.' in eB represents a blank '' in SAP, since in eB the Description is a required field
	--					Ignore leading and trailing whitespace in the Description field. eB trims on import, so we ignore these differences
	, case when LTRIM(RTRIM(s.FunctLocDesc)) <> case e.Description when '.' then '' else LTRIM(RTRIM(ISNULL(e.Description,''))) end then 1 else 0 end as wrong_description
	, case when s.ABCInd <> ISNULL(e.ABCIndicator,'') then 1 else 0 end as wrong_abcindicator
	, case when s.FunctLocCat <> ISNULL(e.Category,'') then 1 else 0 end as wrong_category
	, case when s.ObjectType <> ISNULL(e.ObjType,'') then 1 else 0 end as wrong_objecttype
	, case when s.Class <> ISNULL(e.Class,'') then 1 else 0 end as wrong_class
	, case when dbo.SUN_split_sort_merge_string(s.SysStatus) <> dbo.SUN_split_sort_merge_string(ISNULL(e.SystemStatuses,'')) then 1 else 0 end as wrong_systemstatus
	, case when s.SysStatus <> ISNULL(e.SystemStatusMerged,'') then 1 else 0 end as wrong_systemstatusmerged	
	, case when dbo.SUN_split_sort_merge_string(s.UserStatus) <> dbo.SUN_split_sort_merge_string(ISNULL(e.UserStatuses,'')) then 1 else 0 end as wrong_userstatus
	, case when s.UserStatus <> ISNULL(e.UserStatusMerged,'') then 1 else 0 end as wrong_userstatusmerged
	, case when s.SortField <> ISNULL(e.SortField,'') then 1 else 0 end as wrong_sortfield
	, case when s.MaintPlant <> ISNULL(e.MaintenancePlant,'') then 1 else 0 end as wrong_maintplant
	, case when s.AuthGrp <> ISNULL(e.AuthorizationGroup,'') then 1 else 0 end as wrong_authgroup
	, dbo.sun_compare_compounds(s.Location, s.LocDesc, e.Location) as wrong_location
	, case when s.Room <> ISNULL(e.Room,'') then 1 else 0 end as wrong_room
	, dbo.sun_compare_compounds(s.PlSectn, s.PersResp, e.PlantSection) as wrong_plantsection
	, dbo.sun_compare_compounds(s.WorkCtr, s.WorkCtrDesc, e.MainWorkCenter) as wrong_workcenter
	, case when s.WorkCtrPlant <> ISNULL(e.MainWorkCenterPlant,'') then 1 else 0 end as wrong_workcenterplant
	, dbo.sun_compare_compounds(s.CostCtr, s.CostCtrDesc, e.CostCenter) as wrong_costcenter
	, case when s.PlngPlant <> ISNULL(e.PlanningPlant,'') then 1 else 0 end as wrong_planningplant
	, dbo.sun_compare_compounds(s.PlannerGrp, s.PlannerGrpName, e.PlannerGroup) as wrong_plannergroup
	, case when s.CatProf <> ISNULL(e.CatalogProfile,'') then 1 else 0 end as wrong_catalogprofile
	, case when ISNULL(Cast(s.ChangedDte as datetime),'1900-01-01 00:00:00.000') <> ISNULL(e.ChangedOn,'1900-01-01 00:00:00.000') then 1 else 0 end as wrong_changedon
	-- Only flag an error if there is a related Tag. If Tag was not in eB then no error.
	, case when (e.Related_Tag_Code is not NULL) and (s.SortField <> ISNULL(e.Related_Tag_Code,'')) then 1 else 0 end as wrong_related_tag
	
	-- 2. SAP STAGING TABLE COLUMNS
	
	, s.LoadDateTime as SAP_LoadDateTime
	, s.FunctLoc as SAP_FunctLoc
	, s.FunctLocLabel as SAP_FunctLocLabel
	, s.FunctLocDesc as SAP_FunctLocDesc
	, s.ABCInd as SAP_ABCInd
	, s.FunctLocCat as SAP_FunctLocCat
	, s.ObjectType as SAP_ObjectType
	, s.Class as SAP_Class
	, s.SysStatus as SAP_SysStatus
	, s.UserStatus as SAP_UserStatus
	, s.SortField as SAP_SortField
	, s.MaintPlant as SAP_MaintPlant
	, s.SupFunctLoc as SAP_SupFunctLoc
	, s.SupFunctLocLabel as SAP_SupFunctLocLabel
	, s.AuthGrp as SAP_AuthGrp
	, s.Location as SAP_Location
	, s.LocDesc as SAP_LocDesc
	, s.Room as SAP_Room
	, s.PlSectn as SAP_PlSectn
	, s.PersResp as SAP_PersResp
	, s.WorkCtr as SAP_WorkCtr
	, s.WorkCtrDesc as SAP_WorkCtrDesc
	, s.WorkCtrPlant as SAP_WorkCtrPlant
	, s.CostCtr as SAP_CostCtr
	, s.CostCtrDesc as SAP_CostCtrDesc
	, s.PlngPlant as SAP_PlngPlant
	, s.PlannerGrp as SAP_PlannerGrp
	, s.PlannerGrpName as SAP_PlannerGrpName
	, s.CatProf as SAP_CatProf
	, s.ChangedDte as SAP_ChangedDte
	
	-- 3. EB FLATTENED VIEW COLUMNS
	
	, e.vitem_id as EB_vitem_id
	, e.gvitem_id as EB_gvitem_id
	, e.ObjectNumber as EB_ObjectNumber
	, e.Name as EB_Name
	, e.Description as EB_Description
	, e.ABCIndicator as EB_ABCIndicator
	, e.AuthorizationGroup as EB_AuthorizationGroup
	, e.CatalogProfile as EB_CatalogProfile
	, e.Category as EB_Category
	, e.ChangedOn as EB_ChangedOn
	, e.Class as EB_Class
	, e.CostCenter as EB_CostCenter
	, e.Location as EB_Location
	, e.MainWorkCenter as EB_MainWorkCenter
	, e.MainWorkCenterPlant as EB_MainWorkCenterPlant
	, e.MaintenancePlant as EB_MaintenancePlant
	, e.ObjType as EB_ObjType
	, e.PlannerGroup as EB_PlannerGroup
	, e.PlanningPlant as EB_PlanningPlant
	, e.PlantSection as EB_PlantSection
	, e.Room as EB_Room
	, e.SortField as EB_SortField
	, e.SystemStatuses as EB_SystemStatuses
	, e.SystemStatusMerged as EB_SystemStatusMerged
	, e.UserStatuses as EB_UserStatuses
	, e.UserStatusMerged as EB_UserStatusMerged
	, e.Related_Tag_Code as EB_Related_Tag_Code
	
from SUN_FLOC_Validation_SAP_Stage s
-- Outer join the two sides so we find SAP rows with no eB row, and vice versa:
full join SUN_FLOC_Validation_eB e on s.FunctLoc = e.ObjectNumber


GO


/****** Object:  View [dbo].[SUN_FLOC_Validation_Differences]    Script Date: 11/17/2015 12:21:25 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SUN_FLOC_Validation_Differences]'))
DROP VIEW [dbo].[SUN_FLOC_Validation_Differences]
GO

/****** Object:  View [dbo].[SUN_FLOC_Validation_Differences]    Script Date: 11/17/2015 12:21:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[SUN_FLOC_Validation_Differences]
AS 

select *

from SUN_FLOC_Validation_Comparison c
where 
   c.missing = 1
or c.extra = 1
or c.wrong_name = 1
or c.wrong_description = 1
or c.wrong_abcindicator = 1
or c.wrong_category = 1
or c.wrong_objecttype = 1
or c.wrong_class = 1
or c.wrong_systemstatus = 1
or c.wrong_userstatus = 1
or c.wrong_userstatusmerged = 1
or c.wrong_systemstatusmerged = 1
or c.wrong_sortfield = 1
or c.wrong_maintplant = 1
or c.wrong_authgroup = 1
or c.wrong_location = 1
or c.wrong_room = 1
or c.wrong_plantsection = 1
or c.wrong_workcenter = 1
or c.wrong_workcenterplant = 1
or c.wrong_costcenter = 1
or c.wrong_planningplant = 1
or c.wrong_plannergroup = 1
or c.wrong_catalogprofile = 1
or c.wrong_changedon = 1
or c.wrong_related_tag = 1


GO

