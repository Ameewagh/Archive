truncate table stage_load_status_arc
truncate table stage_change_packages_arc
truncate table stage_projects_arc
truncate table stage_change_requests_arc
truncate table stage_documents_arc
truncate table stage_work_orders_arc
truncate table stage_char_data_arc

truncate table stage_load_status
truncate table stage_change_packages
truncate table stage_projects
truncate table stage_change_requests
truncate table stage_documents
truncate table stage_work_orders
truncate table stage_char_data

truncate table staged_import_job_options
truncate table staged_import_jobs

select * from stage_load_status_arc where context_id in (select top 1 context_id from staged_import_jobs order by created_date desc) order by idx
select * from stage_change_packages_arc where context_id in (select top 1 context_id from staged_import_jobs order by created_date desc) order by row_id
select * from stage_projects_arc where context_id in (select top 1 context_id from staged_import_jobs order by created_date desc) order by row_id
select * from stage_change_requests_arc where context_id in (select top 1 context_id from staged_import_jobs order by created_date desc) order by row_id
select * from stage_documents_arc where context_id in (select top 1 context_id from staged_import_jobs order by created_date desc) order by row_id
select * from stage_char_data_arc where context_id in (select top 1 context_id from staged_import_jobs order by created_date desc) order by row_id

select * from stage_load_status where context_id in (select top 1 context_id from staged_import_jobs order by created_date desc) order by idx
select * from stage_change_packages where context_id in (select top 1 context_id from staged_import_jobs order by created_date desc) order by row_id
select * from stage_change_requests where context_id in (select top 1 context_id from staged_import_jobs order by created_date desc) order by row_id
select * from stage_documents where context_id in (select top 1 context_id from staged_import_jobs order by created_date desc) order by row_id
select * from stage_projects where context_id in (select top 1 context_id from staged_import_jobs order by created_date desc) order by row_id
select * from stage_char_data where context_id in (select top 1 context_id from staged_import_jobs order by created_date desc) order by row_id

select * from copy_packages
select * from copy_package_instances
select * from scopes
select * from namespaces

select * from change_requests order by co_id desc
select * from projects order by project_id desc
select * from documents order by document_id desc
select * from work_orders order by wo_id desc




select * from server_engines
select * from engines
update server_engines set server_id = 6
delete from server_engines where server_id = 5

delete from queue_job_attributes
delete from queue_jobs
