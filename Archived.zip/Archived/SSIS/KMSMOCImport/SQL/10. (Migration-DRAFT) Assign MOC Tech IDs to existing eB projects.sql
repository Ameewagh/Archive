--
--	10. (Migration) Assign MOC Tech IDs to existing eB projects.sql
--
--	This script finds all eB projects that shoudl be linked to an MOC and links them up if it finds a match.
--	It can be run multiple times, e.g. after a data load batch.
--	It assigns the KMS MOC techncial IDs to the Project, which fires the event hander for each project object it updates to syncronize all KMS attributes 
--
--	FOR TESTING:	Add "TOP 1" clause to the SELECT below to update just one project and validate it.
--	FOR LIVE USE:	Remove "TOP 1" clause.
--
SET ANSI_WARNINGS OFF
GO

declare 
	@project_id int,
	@MOCNumber	nvarchar(50),
	@MOCNumber_char_id int
	
-- TBD - not sure if we need this: update sessions set scope_id = 2, namespace_id = 2 where session_id = 1

declare projects_cursor cursor for

----- Start query for cursor -----

	-- Find all eB projects that:
	--		Are of the new 'PROJ' class in Firebag namespace
	--		Have no MOC Technical IDs (MOC Unit ID, MOC Moc No)
	--		Have a Project Code that matches an MOC Number in the MOC table
	select 
		TOP 1			-- FOR TESTING. COMMENT THIS OUT FOR LIVE USE.
		 p.project_id
		,k.MOCNumber

	from projects p (nolock)

	-- Get only projects of PROJ class in Firebag namespace
	inner join class_objects co on p.class_id = co.class_id and co.code = 'PROJ' and co.namespace_id = 2

	-- Join to a super fast PIVOT of required attributes in the char_data table
	-- Used to get only projects not linked to an MOC yet (in the WHERE clause)
	left join (
			select 
				  object_id
				, MAX(case char_name when 'MOC Unit Id' then char_value end) MOCUnitId
				, MAX(case char_name when 'MOC MOC No' then char_value end) MOCMOCNo
			from (
				select 
				  cd.object_id 
				 ,c.char_name
				 ,cd.char_value
				from char_data cd (nolock)
				inner join characteristics c (nolock) on cd.char_id = c.char_id
				where c.object_type = 9
				) raw_attribs
			group by object_id
		) attribs on p.project_id = attribs.object_id

	-- Get only projects where the project code matches an MOC number
	inner join SUN_KMS_MOC k on p.project_code = k.MOCNumber

	where 
		p.template = 'N'
		-- Get only eB projects that are not linked to an MOC yet
		and	(attribs.MOCUnitId is null or attribs.MOCUnitId = '')
		and (attribs.MOCMOCNo is null or attribs.MOCMOCNo = '')

----- End query for cursor -----

set @MOCNumber_char_id = (select char_id from characteristics where char_name = 'MOC Number')

open projects_cursor 
fetch next from projects_cursor
into @project_id, @MOCNumber

while @@FETCH_STATUS = 0
begin
	begin transaction
		-- Assign MOC Number - fires event hander on change of MOC Number as if user changed it, syncs other attributes
		exec ebp_set_char_data  @project_id, @MOCNumber_char_id, @MOCNumber, NULL, NULL, NULL, 1
	commit
	
	fetch next from projects_cursor
	into @project_id, @MOCNumber
end

close projects_cursor
deallocate projects_cursor

