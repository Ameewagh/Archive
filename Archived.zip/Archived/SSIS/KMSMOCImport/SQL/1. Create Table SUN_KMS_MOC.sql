IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SUN_KMS_MOC]') AND type in (N'U'))
DROP TABLE [dbo].[SUN_KMS_MOC]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[SUN_KMS_MOC](
	[MOCUnitId] [nvarchar](10) NOT NULL,
	[MOCMocNo] [nvarchar](50) NOT NULL,
	[MOCNumber] [nvarchar](50) NULL,
	[MOCTitle] [nvarchar](120) NULL,
	[MOCFacility] [nvarchar](80) NULL,
	[MOCBusinessArea] [nvarchar](40) NULL,
	[MOCArea] [nvarchar](40) NULL,
	[MOCUnit] [nvarchar](80) NULL,
	[MOCStatus] [nvarchar](255) NULL,
	[MOCDescription] [nvarchar](3000) NULL,
	[MOCLeader] [nvarchar](255) NULL,
	[MOCLeaderWinLoginId] [nvarchar](200) NULL,
	[MOCRiskRanking] [nvarchar](255) NULL,
	[MOCDateInitiated] [datetime] NULL,
	[MOCTargetDate] [datetime] NULL,
	[MOCClosureDate] [datetime] NULL,
	[MOCExpirationDate] [datetime] NULL,
	[MOCTemporary] [nvarchar](255) NULL,
	[MOCDepartment] [nvarchar](120) NULL,
	[MOCUnitSupervisor] [nvarchar](255) NULL,
	[MOCUnitSupervisorWinLoginId] [nvarchar](200) NULL,
	[MOCActionFinancialPlanningComments] [nvarchar](3000) NULL,
	[New] [nvarchar] (1) NULL,
	[Updated] [nvarchar](1) NULL
 CONSTRAINT [PK_SUN_KMS_MOC] PRIMARY KEY CLUSTERED 
(
	[MOCUnitId] ASC,
	[MOCMocNo] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO


