delete from stage_change_requests_arc
delete from stage_change_requests
delete from staged_import_jobs
delete from stage_load_status
delete from stage_load_status_summary
delete from stage_char_data
delete from stage_relationships
delete from stage_documents
delete from stage_affected_changes
delete from stage_affected_changes_arc
delete from stage_load_status_arc
delete from stage_load_status_summary_arc
delete from stage_char_data_arc
delete from stage_relationships_arc
delete from stage_documents_arc
delete from stage_uprev_object
---1046 GD-00002
---stage2 - Create Change Package
insert into stage_change_requests(scope, priority, description, reason, classification, req_by_org_code,stage_object_id, context_id)
values ('Firebag (FB)','1','change CP desc','CP reason','1', 'SUNCOR', 'CR_stage_id', '7777');
insert into stage_change_packages(Scope, package_code, co_stage_object_id, context_id)
values ('Firebag (FB)', 'CP-2', 'CR_stage_id', '7777');

begin
declare @job_id uniqueidentifier;
set @job_id = newid();
insert into staged_import_jobs values (@job_id,'job name','7777',null,1,null,null,null,null,null);
insert into staged_import_job_options values (@job_id, null,N'default_scope', 'Global' );
insert into staged_import_job_options values (@job_id, null,N'archive_data_after_import' , 'Y' );
insert into staged_import_job_options values (@job_id, null,N'logging_mode', 'I' );
insert into staged_import_job_options values (@job_id, null,N'rollback_object_creation_on_error', 'N' );
exec ebpsi_import_staged_data @job_id
end;

select * from stage_load_status_arc where context_id = '7777' and status_code > 5000


---stage3 - Add Document Tag as an affected Object

insert into stage_documents(prefix, title, class_code, revision, subject_to_cc, status, stage_object_id, context_id)
values ('GD-000002', 'General Drawing    CP testing 12', 'GD', '0', 'Y', 'A', 'doc_stage_id', 7777);
insert into stage_tags(item_number, item_version, code, name, class_code, revn_name, change_controlled, approval, stage_object_id, context_id)
values ('P191', '1', '191BD5131', 'RELIEF AND BLOWDOWN FROM CATCH PAN ON 191BD5130-8 INCH-CS TO DRAIN 191BD5131+WATER', 'P-BD', '', 'Y', 'A', 'tag_stage_id', 7777);
-- CO_ID - change object
-- ECP - traveler docas. coumpound object
-- 

--- CO_ID  change request id
insert into stage_affected_changes( object_type, co_id, req_by_org_code, stage_object_id, context_id)
values( '3', '147', 'SUNCOR', 'doc_stage_id', 7777);
insert into stage_affected_changes( object_type, co_id, req_by_org_code, stage_object_id, context_id)
values( '212', '147', 'SUNCOR', 'tag_stage_id', 7777);


begin
declare @job_id uniqueidentifier;
set @job_id = newid();
insert into staged_import_jobs values (@job_id,'job name','7777',null,1,null,null,null,null,null);
insert into staged_import_job_options values (@job_id, null,N'default_scope', 'Global' );
insert into staged_import_job_options values (@job_id, null,N'archive_data_after_import' , 'Y' );
insert into staged_import_job_options values (@job_id, null,N'logging_mode', 'I' );
insert into staged_import_job_options values (@job_id, null,N'rollback_object_creation_on_error', 'N' );
exec ebpsi_import_staged_data @job_id
end;

select * from stage_load_status_arc where status_code > 5000


-- template_name yra eB System class "PROTO" -for prototypes
insert into stage_documents(base_object_id, co_id, req_by_org_code, prototype, prefix, title, class_name, template_name, revision, options, stage_object_id, context_id)
values ('1065', '146', 'SUNCOR', 'Y', 'MARKUP-001', 'MARKUP-001 title', 'Prototype Document', 'PROTO', '001', '0', 'markup_stage_id', 7777);
insert into stage_tags(base_object_id, co_id, req_by_org_code, prototype, code, name, class_name, template_name, revn_name, options, stage_object_id, context_id)
values ('6', '146', 'SUNCOR', 'Y', 'PROTO-001', 'PROTO-001 NAME', 'Prototype Tag', 'PROTO', '001', '0', 'proto_stage_id', 7777);



begin
declare @job_id uniqueidentifier;
set @job_id = newid();
insert into staged_import_jobs values (@job_id,'job name','7777',null,1,null,null,null,null,null);
insert into staged_import_job_options values (@job_id, null,N'default_scope', 'Global' );
insert into staged_import_job_options values (@job_id, null,N'archive_data_after_import' , 'Y' );
insert into staged_import_job_options values (@job_id, null,N'logging_mode', 'I' );
insert into staged_import_job_options values (@job_id, null,N'rollback_object_creation_on_error', 'N' );
exec ebpsi_import_staged_data @job_id
end;

select * from stage_load_status_arc where status_code > 5000



-- isimam options kuriam markup
insert into stage_documents(base_object_id, co_id, req_by_org_code, prototype, prefix, title, class_name, template_name, revision,  stage_object_id, context_id)
values ('1065', '146', 'SUNCOR', 'Y', 'MARKUP-001', 'MARKUP-001 title', 'Prototype Document', 'PROTO', '001',  'markup_stage_id', 7777);
insert into stage_tags(base_object_id, co_id, req_by_org_code, prototype, code, name, class_name, template_name, revn_name,  stage_object_id, context_id)
values ('6', '146', 'SUNCOR', 'Y', 'PROTO-001', 'PROTO-001 NAME', 'Prototype Tag', 'PROTO', '001',  'proto_stage_id', 7777);

insert into stage_char_data (char_name, char_value, stage_object_id, context_id) 
values ('Commodity', 'PAKEISTAS', 'markup_stage_id', 7777);
insert into stage_char_data (char_name, char_value, stage_object_id, context_id) 
values ('Alias Number', '111111', 'proto_stage_id', 7777);



begin
declare @job_id uniqueidentifier;
set @job_id = newid();
insert into staged_import_jobs values (@job_id,'job name','7777',null,1,null,null,null,null,null);
insert into staged_import_job_options values (@job_id, null,N'default_scope', 'Global' );
insert into staged_import_job_options values (@job_id, null,N'archive_data_after_import' , 'Y' );
insert into staged_import_job_options values (@job_id, null,N'logging_mode', 'I' );
insert into staged_import_job_options values (@job_id, null,N'rollback_object_creation_on_error', 'N' );
exec ebpsi_import_staged_data @job_id
end;

select * from stage_load_status_arc where status_code > 5000

--------------------------------
--status to expeditd
truncate table  stage_load_status
truncate table  stage_load_status_arc
truncate table stage_change_requests
truncate table stage_documents
truncate table stage_work_orders
truncate table stage_change_packages

insert into stage_change_requests(scope, priority, description, reason, classification, req_by_org_code,stage_object_id, context_id, co_id, work_status, appr_rej_by_person_code, appr_rej_reason, appr_rej_date)
values ('Global','1','change description','change reason','1', 'SUNCOR', 'CR_stage_id', '7777','146','E', 'Admin', 'exp reason', '03/23/2015');

begin
declare @job_id uniqueidentifier;
set @job_id = newid();
insert into staged_import_jobs values (@job_id,'job name','7777',null,1,null,null,null,null,null);
insert into staged_import_job_options values (@job_id, null,N'default_scope', 'Global' );
insert into staged_import_job_options values (@job_id, null,N'archive_data_after_import' , 'Y' );
insert into staged_import_job_options values (@job_id, null,N'logging_mode', 'I' );
insert into staged_import_job_options values (@job_id, null,N'rollback_object_creation_on_error', 'N' );
exec ebpsi_import_staged_data @job_id
end;

select * from stage_load_status_arc where status_code > 5000

---------------------
---- pakeliam revision

------- issimam status
insert into stage_documents(prefix, title, class_code, revision, subject_to_cc,  stage_object_id, context_id)
values ('GD-000004', 'pirmas-antraeilis', 'GD', '2', 'Y', 'doc_stage_id', 7777);

insert into stage_uprev_object( co_id, object_type, uprev_revn_name, stage_object_id, context_id)
values( '146', 3, '3', 'doc_stage_id', 7777);




insert into stage_tags(item_number, item_version, code, name, class_code, revn_name, change_controlled,  stage_object_id, context_id)
values ('P191', '1', '191AT-50018', 'HRSG STACK FLUE GAS CO 191AT-50018', 'I-AT', '1', 'Y',  'tag_stage_id', 7777);
insert into stage_uprev_object( co_id, object_type, uprev_revn_name, stage_object_id, context_id)
values( '146', 212, '3', 'tag_stage_id', 7777);

begin
declare @job_id uniqueidentifier;
set @job_id = newid();
insert into staged_import_jobs values (@job_id,'job name','7777',null,1,null,null,null,null,null);
insert into staged_import_job_options values (@job_id, null,N'default_scope', 'Global' );
insert into staged_import_job_options values (@job_id, null,N'archive_data_after_import' , 'Y' );
insert into staged_import_job_options values (@job_id, null,N'logging_mode', 'I' );
insert into staged_import_job_options values (@job_id, null,N'rollback_object_creation_on_error', 'N' );
exec ebpsi_import_staged_data @job_id
end;

select * from stage_load_status_arc where status_code > 5000
------------------------


delete from staged_import_jobs
delete from stage_load_status
delete from stage_load_status_summary
delete from stage_tags
delete from stage_load_status_arc
delete from stage_load_status_summary_arc
delete from stage_tags_arc
delete from stage_affected_changes
delete from stage_change_requests

--- ideti import_prototype
---  options
insert into stage_documents(base_object_id, co_id, req_by_org_code, prototype, prefix, title, class_name, template_name, revision,  stage_object_id, context_id, import_prototype, options)
values ('1065', '146', 'SUNCOR', 'Y', 'MARKUP-001', 'MARKUP-001 title', 'Prototype Document', 'PROTO', '001',  'markup_stage_id', 7777,'Y','0');
insert into stage_tags(base_object_id, co_id, req_by_org_code, prototype, code, name, class_name, template_name, revn_name,  stage_object_id, context_id, import_prototype,options)
values ('6', '146', 'SUNCOR', 'Y', 'PROTO-001', 'PROTO-001 NAME', 'Prototype Tag', 'PROTO', '001',  'proto_stage_id', 7777,'Y','0');
----------

begin
declare @job_id uniqueidentifier;
set @job_id = newid();
insert into staged_import_jobs values (@job_id,'job name','7777',null,1,null,null,null,null,null);
insert into staged_import_job_options values (@job_id, null,N'default_scope', 'Global' );
insert into staged_import_job_options values (@job_id, null,N'archive_data_after_import' , 'Y' );
insert into staged_import_job_options values (@job_id, null,N'logging_mode', 'I' );
insert into staged_import_job_options values (@job_id, null,N'rollback_object_creation_on_error', 'N' );
exec ebpsi_import_staged_data @job_id
end;

select * from stage_load_status_arc where status_code >= 5000


--------------------------------
--status to Completed/approcved-
--- pasitikrinti

truncate table  stage_load_status
truncate table  stage_load_status_arc
truncate table stage_change_requests
truncate table stage_documents
truncate table stage_work_orders
truncate table stage_change_packages

insert into stage_change_requests(scope, priority, description, reason, classification, req_by_org_code,stage_object_id, context_id, co_id, work_status, appr_rej_by_person_code, appr_rej_reason, appr_rej_date)
values ('Global','1','change description','change reason','1', 'SUNCOR', 'CR_stage_id', '7777','146','X', 'Admin', 'exp reason', '03/23/2015');

begin
declare @job_id uniqueidentifier;
set @job_id = newid();
insert into staged_import_jobs values (@job_id,'job name','7777',null,1,null,null,null,null,null);
insert into staged_import_job_options values (@job_id, null,N'default_scope', 'Global' );
insert into staged_import_job_options values (@job_id, null,N'archive_data_after_import' , 'Y' );
insert into staged_import_job_options values (@job_id, null,N'logging_mode', 'I' );
insert into staged_import_job_options values (@job_id, null,N'rollback_object_creation_on_error', 'N' );
exec ebpsi_import_staged_data @job_id
end;

select * from stage_load_status_arc where status_code > 5000
