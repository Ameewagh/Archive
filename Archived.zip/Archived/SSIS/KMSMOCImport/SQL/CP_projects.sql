delete from stage_change_requests_arc
delete from stage_change_requests
delete from staged_import_jobs
delete from stage_load_status
delete from stage_load_status_summary
delete from stage_char_data
delete from stage_relationships
delete from stage_documents
delete from stage_affected_changes
delete from stage_affected_changes_arc
delete from stage_load_status_arc
delete from stage_load_status_summary_arc
delete from stage_char_data_arc
delete from stage_relationships_arc
delete from stage_documents_arc
delete from stage_uprev_object
---1046 GD-00002
---stage2 - Create Change Package
insert into stage_change_requests(scope, priority, description, reason, classification, req_by_org_code,stage_object_id, context_id)
values ('Firebag (FB)','1','change CP desc','CP reason','1', 'SUNCOR', 'CR_stage_id', '7777');
insert into stage_projects(project_code, description, stage_object_id, context_id)
values ('PROJ-004','project description','PR_stage_id', '7777');
insert into stage_change_packages(Scope, package_code, project_options, project_stage_object_id, co_stage_object_id, context_id)
values ('Firebag (FB)', 'CP-2', 1 /* 4 is undocumented */, 'PR_stage_id', 'CR_stage_id', '7777');

begin
declare @job_id uniqueidentifier;
set @job_id = newid();
insert into staged_import_jobs values (@job_id,'job name','7777',null,1,null,null,null,null,null);
insert into staged_import_job_options values (@job_id, null,N'default_scope', 'Global' );
insert into staged_import_job_options values (@job_id, null,N'archive_data_after_import' , 'Y' );
insert into staged_import_job_options values (@job_id, null,N'logging_mode', 'I' );
insert into staged_import_job_options values (@job_id, null,N'rollback_object_creation_on_error', 'N' );
exec ebpsi_import_staged_data @job_id
end;



select * from stage_load_status_arc where context_id = '7777' and status_code > 5000