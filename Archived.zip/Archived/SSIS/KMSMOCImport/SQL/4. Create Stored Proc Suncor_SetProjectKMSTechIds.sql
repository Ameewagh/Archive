
EXEC ebps_drop
    'procedure', 'Suncor_SetProjectKMSTechIds'
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Suncor_SetProjectKMSTechIds]
(
    @pi_project_id      INT,
    @MOCUnitId			nvarchar(10),
	@MOCMocNo			nvarchar(50)
)
AS
DECLARE
	@MOCUnitId_char_id	int,
	@MOCMocNo_char_id	int,
	@RC					int

BEGIN	
    SET NOCOUNT ON

	select top 1 @MOCUnitId_char_id = char_id from characteristics where char_name = 'MOC Unit Id'
	select top 1 @MOCMocNo_char_id = char_id from characteristics where char_name = 'MOC Moc No'

	exec @RC = ebp_set_char_data @pi_project_id, @MOCUnitId_char_id, @MOCUnitId, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCMocNo_char_id, @MOCMocNo, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	
    RETURN 0 -- Success
END

/*
	begin transaction
	exec Suncor_SetProjectKMSTechIds 13244, 'F014', 25
	commit 
	
	(select top 1 project_id from projects where project_code = 'A03')
	
	select * from Attributes_View
	where object_id = (select top 1 project_id from projects where project_code = 'A03')
	and char_id in (select char_id from characteristics 
			where object_type = 9 and char_name like 'MOC%')
	order by char_id

	select * from SUN_KMS_MOC

	select * from char_data where char_id = (select char_id from characteristics 
			where object_type = 9 and char_name like 'MOC Moc No')

	select * from projects where project_id in (13192, 13193, 13194)

*/

