
begin
declare @job_id uniqueidentifier;
set @job_id = newid();
declare @context_id nvarchar(255) = (select top 1 context_id from stage_change_packages order by row_id desc) -- 'KMSMOCImport-STADF8465REML-D211015T113041;KMSDatabase'
insert into staged_import_jobs values (@job_id, @context_id,@context_id,null,1,null,null,null,null,null);
insert into staged_import_job_options values (@job_id, null,N'default_scope', 'Firebag (FB)' );
insert into staged_import_job_options values (@job_id, null,N'archive_data_after_import' , 'Y' );
insert into staged_import_job_options values (@job_id, null,N'logging_mode', 'I' );
insert into staged_import_job_options values (@job_id, null,N'rollback_object_creation_on_error', 'N' );
exec ebpsi_import_staged_data @job_id
end;

-- select * from staged_import_jobs

select * from relationship_types