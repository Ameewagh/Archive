-- KMS MOC to eB Project - Integration Query - v0.1
			-- Written 13 Oct 2015 by RBL

			-- Server:		SQLDEVCGY015V2
			-- Database:	CKMSDEV

			-- TODO:
			--		Change query to use '%GN%24%' as prefix for GN-24 planning item
			--		Change query to use '%AIM%01%' as prefix for AIM:01 planning item

			select
			CONVERT(nvarchar(10), m.UNIT_ID) as MOCUnitId
			,CONVERT(nvarchar(50), m.MOC_NO) as MOCMocNo		-- TODO: change eB table to be nvarchar(50) also
			,CONVERT(nvarchar(50), m.REF_NO) AS MOCNumber
			,CONVERT(nvarchar(120), s.SOURCE_NAME) as MOCTitle
			,CONVERT(nvarchar(80), f.FACILITY_NAME) as MOCFacility
			,CONVERT(nvarchar(40), ba.AREA_NAME) as MOCBusinessArea
			,CONVERT(nvarchar(40), a.AREA_NAME) as MOCArea
			,CONVERT(nvarchar(80), u.UNIT_NAME) as MOCUnit
			,CONVERT(nvarchar(255), ms.MOC_STATUS_NAME) as MOCStatus
			,CONVERT(nvarchar(3000), m.MOC_DESCRIBE) as MOCDescription
			,CONVERT(nvarchar(255), COALESCE(p_rp.LAST_NAME, '') + ', ' + COALESCE(p_rp.FIRST_NAME, '')) as MOCLeader
			,CONVERT(nvarchar(200), p_rp.WINLOGINID) as MOCLeaderWinLoginId
			-- Replicate behaviour of function GET_RISK_RANKING()
			,CONVERT(nvarchar(255), case
			when upper(m.RISK_RANKING) = 'OP' then (
			select top 1 ltrim(ResourceValue)
			from kms.LOC_STRINGRESOURCES (nolock)
			where ResourceKey = 'RiskRanking_Operability' and CultureCode = 'en-US'
			)
			when upper(m.RISK_RANKING) = 'SM' then (
			select top 1 ltrim(ResourceValue)
			from kms.LOC_STRINGRESOURCES (nolock)
			where ResourceKey = 'RiskRanking_SafetyMatrix' and CultureCode = 'en-US'
			)
			when upper(m.RISK_RANKING) = 'MI' then (
			select top 1 ltrim(ResourceValue)
			from kms.LOC_STRINGRESOURCES (nolock)
			where ResourceKey = 'RiskRanking_MechanicalIntegrity' and CultureCode = 'en-US'
			)
			when upper(m.RISK_RANKING) IN ('UNRANKED', 'UN') then (
			select top 1 ltrim(ResourceValue)
			from kms.LOC_STRINGRESOURCES (nolock)
			where ResourceKey = 'RiskRanking_Unranked' and CultureCode = 'en-US'
			)
			when upper(m.RISK_RANKING) IN ('3', 'RM', 'RISK MATRIX') then (
			select top 1 ltrim(ResourceValue)
			from kms.LOC_STRINGRESOURCES (nolock)
			where ResourceKey = 'RiskRanking_RiskMatrix' and CultureCode = 'en-US'
			)
			when upper(m.RISK_RANKING) IN ('COMP', 'COMPLIANCE') then (
			select top 1 ltrim(ResourceValue)
			from kms.LOC_STRINGRESOURCES (nolock)
			where ResourceKey = 'RiskRanking_Compliance' and CultureCode = 'en-US'
			)
			-- When RISK_RANKING has three / characters, remove the final / and the digits after it
			-- e.g. IV/L3/C1/5  becomes  IV/L3/C1
			when LEN(REPLACE(m.RISK_RANKING, '/', '**')) - LEN(m.RISK_RANKING) = 3 then
			LEFT(m.RISK_RANKING, LEN(m.RISK_RANKING) - CHARINDEX('/', REVERSE(m.RISK_RANKING)))
			-- If unclear how to translate it, then return it as-is:
			else
			m.RISK_RANKING
			end) as MOCRiskRanking
			,m.CREATION_DATE as MOCDateInitiated
			,m.DATE_TARGET as MOCTargetDate
			,m.CLOSURE_DATE as MOCClosureDate
			,m.EXPIRY_DATE as MOCExpirationDate
			-- Replicate behaviour of function GET_RESOURCEVALUE to convert Temporary flag to Yes or No:
			-- WHEN 1	THEN [dbo].[GET_RESOURCEVALUE]('Yes',CULTURE.CULTURE , 'KMSGeneralRes'  )
			--	WHEN 0	THEN [dbo].[GET_RESOURCEVALUE]('No',CULTURE.CULTURE , 'KMSGeneralRes' )
			,CONVERT(nvarchar(255), case m.IS_TEMPORARY
			when 1 then (
			select TOP 1 ltrim(ResourceValue)
			from kms.LOC_STRINGRESOURCES (nolock) where CultureCode = 'en-US'
			and ResourceKey = 'Yes' and ResourceType = 'KMSGeneralRes'
			)
			when 0 then (
			select TOP 1 ltrim(ResourceValue)
			from kms.LOC_STRINGRESOURCES (nolock) where CultureCode = 'en-US'
			and ResourceKey = 'No' and ResourceType = 'KMSGeneralRes'
			)
			else m.IS_TEMPORARY
			end) as MOCTemporary
			-- Replicate behaviour of this function to get Department (of the RESP_PARTY):
			-- dbo.LOC_KMS_DECODE_SELECTIONS('DEPT', ISNULL(dbo.PERSONS.DEPARTMENT, ''),CULTURE.CULTURE) AS [Department]
			,CONVERT(nvarchar(120), case
			when p_rp.DEPARTMENT IS NULL then
			''
			when p_rp.DEPARTMENT = '' then
			''
			when EXISTS (
			SELECT *
			from kms.SELECTION (nolock)
			WHERE SELECTIONS_ID = 'DEPT' AND SELECTION.DATAFIELD = p_rp.DEPARTMENT
			) then (
			SELECT TOP 1 DISPLAYFIELD
			from kms.SELECTION_LOCALE (nolock)
			WHERE SELECTIONS_ID = 'DEPT' AND SELECTION_LOCALE.DATAFIELD = p_rp.DEPARTMENT
			AND CULTURE = 'en-US'
			)
			end) as MOCDepartment
			,CONVERT(nvarchar(255), COALESCE(p_us.LAST_NAME, '') + ', ' + COALESCE(p_us.FIRST_NAME, '')) as MOCUnitSupervisor
			,CONVERT(nvarchar(200), p_us.WINLOGINID) as MOCUnitSupervisorWinLoginId
			,CONVERT(nvarchar(3000), ma_gn24.REMARKS) as MOCActionFinancialPlanningComments
			from kms.MOC m (nolock)
			-- join kms.to Business Area so we can filter on FIREBAG only
			left join kms.UNIT u (nolock) on m.UNIT_ID = u.UNIT_ID
			left join kms.AREA a (nolock) on u.AREA_ID = a.AREA_ID
			left join kms.AREA ba (nolock) on a.PARENT_AREA = ba.AREA_ID
			left join kms.KMS_FACILITY f (nolock) on ba.FACILITY_ID = f.FACILITY_ID
			-- join kms.to subquery to get MOC Statuses
			left join
			(
			select
			-- Logic deconstructed from kms.function LOC_GET_STATUS()
			case lsr.ResourceKey
			when 'ProposalNavigationBar_CompletionStatus_MOC_ProcessActivated' then '1'
			when 'ProposalNavigationBar_CompletionStatus_MOC_ReviewInProgress' then '2'
			when 'ProposalNavigationBar_CompletionStatus_MOC_ChangeRequestApproved' then '3'
			when 'ProposalNavigationBar_CompletionStatus_MOC_ChangeRequestDenied' then '4'
			when 'ProposalNavigationBar_CompletionStatus_MOC_ImplementationInProgress' then '5'
			when 'ProposalNavigationBar_CompletionStatus_MOC_ReadyToStartUp' then '6'
			when 'ProposalNavigationBar_CompletionStatus_MOC_Completed' then '7'
			when 'ProposalNavigationBar_CompletionStatus_MOC_Cancelled' then '9'
			when 'ProposalNavigationBar_CompletionStatus_MOC_Open' then 'a'
			when 'ProposalNavigationBar_CompletionStatus_MOC_Close' then 'b'
			when 'ProposalNavigationBar_CompletionStatus_MOC_PastDue' then 'c'
			end as MOC_STATUS,
			lsr.ResourceValue as MOC_STATUS_NAME
			from kms.LOC_STRINGRESOURCES lsr (nolock)
			-- Get just MOC statuses
			where lsr.ResourceKey like 'ProposalNavigationBar_CompletionStatus_MOC_%'
			-- Get just English for Firebag
			and lsr.CultureCode = 'en-US'
			) AS ms ON m.STATUS = ms.MOC_STATUS
			-- join kms.SOURCE to get MOC title
			left join kms.SOURCE s (nolock) on m.SOURCE_ID = s.SOURCE_ID
			-- join kms.PERSONS to get MOC Leader
			left join kms.PERSONS p_rp (nolock) on m.RESP_PARTY = p_rp.PERSON
			-- join kms.PERSONS again to get Unit Supervisor
			left join kms.PERSONS p_us (nolock) on u.UNIT_SVR = p_us.PERSON
			-- join kms.MOC_ACTIONS to get just the Planning Items of type GN:24 (TODO - confirm this number)
			outer apply (
			-- ensure we get only one planning item row for each MOC - using outer apply and top 1 to accomplish this
			select top 1 *
			from kms.MOC_ACTION ma
			where m.UNIT_ID = ma.UNIT_ID and m.MOC_NO = ma.MOC_NO
			and SUBSTRING(ma.ACTION_TEXT, 0, 12) LIKE '%AIM%06%'		-- TODO: change this to the GN-24 financial AIM planning item prefix ('%GN%24%')
			) ma_gn24
			-- join kms.MOC_ACTIONS to get just the Planning Items of type AIM:01
			-- we don't actually SELECT any columns from kms.this join, we just use it in the WHERE clause
			outer apply (
			-- ensure we get only one planning item row for each MOC - using outer apply and top 1 to accomplish this
			select top 1 *
			from kms.MOC_ACTION ma
			where m.UNIT_ID = ma.UNIT_ID and m.MOC_NO = ma.MOC_NO
			and SUBSTRING(ma.ACTION_TEXT, 0, 12) LIKE '%AIM%06%'		-- TODO: change this to the AIM:01 planning item ('%AIM%01%')
			) ma_aim01

			where
			f.FACILITY_NAME = 'In-Situ'and ba.AREA_NAME = 'FIREBAG'
			and ma_aim01.ACTION_NO IS NOT NULL	-- could use any column that is never NULL when the row exists
