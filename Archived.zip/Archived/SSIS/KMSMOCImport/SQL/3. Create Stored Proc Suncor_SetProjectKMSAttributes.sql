EXEC ebps_drop
    'procedure', 'Suncor_SetProjectKMSAttributes'
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* 
Set all KMS MOC slave attributes and relationships 
from KMS MOC cache table using MOCUnitId and MOCMocNo (technical identifers).
This procedure does not update MOCMocNumber (business identifier).
*/
CREATE PROCEDURE [dbo].[Suncor_SetProjectKMSAttributes]
(
    @pi_project_id         INT
)
AS
DECLARE
    @li_error			INT,
    @msg				nvarchar(255),
    @RC					int,
    
	@MOCUnitId			nvarchar(10),
	@MOCMocNo			nvarchar(50),
	@MOCNumber			nvarchar(50),
	@MOCTitle			nvarchar(120),
	@MOCFacility		nvarchar(80),
	@MOCBusinessArea	nvarchar(40),
	@MOCArea			nvarchar(40),
	@MOCUnit			nvarchar(80),
	@MOCStatus			nvarchar(255),
	@MOCDescription		nvarchar(3000),
	@MOCLeader			nvarchar(255),
	@MOCLeaderWinLoginId nvarchar(200),
	@MOCRiskRanking		nvarchar(255),
	@MOCDateInitiated	datetime,
	@MOCTargetDate		datetime,
	@MOCClosureDate		datetime,
	@MOCExpirationDate	datetime,
	@MOCTemporary		nvarchar(255),
	@MOCDepartment		nvarchar(120),
	@MOCUnitSupervisor	nvarchar(255),
	@MOCUnitSupervisorWinLoginId nvarchar(200),
	@MOCActionFinancialPlanningComments nvarchar(3000),
	
	@MOCUnitId_char_id int,
	@MOCMocNo_char_id int,
	@MOCNumber_char_id int,
	@MOCTitle_char_id int,
	@MOCFacility_char_id int,
	@MOCBusinessArea_char_id int,
	@MOCArea_char_id int,
	@MOCUnit_char_id int,
	@MOCStatus_char_id int,
	@MOCDescription_char_id int,
	@MOCLeader_char_id int,
	@MOCLeaderWinLoginId_char_id int,
	@MOCRiskRanking_char_id int,
	@MOCDateInitiated_char_id int,
	@MOCTargetDate_char_id int,
	@MOCClosureDate_char_id int,
	@MOCExpirationDate_char_id int,
	@MOCTemporary_char_id int,
	@MOCDepartment_char_id int,
	@MOCUnitSupervisor_char_id int,
	@MOCUnitSupervisorWinLoginId_char_id int,
	@MOCActionFinancialPlanningComments_char_id int

	
BEGIN	
    SET NOCOUNT ON

	-- select attributes
	select 
		@MOCUnitId = d1.char_value, 
		@MOCMocNo = d2.char_value 
	from projects p
	left outer join char_data d1 on d1.object_id = @pi_project_id 
		and d1.char_id = (select top 1 char_id from characteristics 
		where object_type = 9 and char_name = 'MOC Unit Id')
	left outer join char_data d2 on d2.object_id = @pi_project_id 
		and d2.char_id = (select top 1 char_id from characteristics 
		where object_type = 9 and char_name = 'MOC Moc No')
	where p.project_id = @pi_project_id
	
	select top 1
		@MOCUnitId = m.MOCUnitId,
		@MOCMocNo = m.MOCMocNo,
		@MOCNumber = m.MOCNumber,
		@MOCTitle = m.MOCTitle,
		@MOCFacility = m.MOCFacility,
		@MOCBusinessArea = m.MOCBusinessArea,
		@MOCArea = m.MOCArea,
		@MOCUnit = m.MOCUnit,
		@MOCStatus = m.MOCStatus,
		@MOCDescription = m.MOCDescription,
		@MOCLeader = m.MOCLeader,
		@MOCLeaderWinLoginId = m.MOCLeaderWinLoginId,
		@MOCRiskRanking = m.MOCRiskRanking,
		@MOCDateInitiated = m.MOCDateInitiated,
		@MOCTargetDate = m.MOCTargetDate,
		@MOCClosureDate = m.MOCClosureDate,
		@MOCExpirationDate = m.MOCExpirationDate,
		@MOCTemporary = m.MOCTemporary,
		@MOCDepartment = m.MOCDepartment,
		@MOCUnitSupervisor = m.MOCUnitSupervisor,
		@MOCUnitSupervisorWinLoginId = m.MOCUnitSupervisorWinLoginId,
		@MOCActionFinancialPlanningComments = m.MOCActionFinancialPlanningComments
	from SUN_KMS_MOC m
	where MOCUnitId = @MOCUnitId 
	and MOCMocNo = @MOCMocNo
	
	-- find char_ids
	set @MOCUnitId_char_id = (select char_id from characteristics where char_name = 'MOC Unit Id')
	set @MOCMocNo_char_id = (select char_id from characteristics where char_name = 'MOC Moc No')
	set @MOCNumber_char_id = (select char_id from characteristics where char_name = 'MOC Number')
	set @MOCTitle_char_id = (select char_id from characteristics where char_name = 'MOC Title')
	set @MOCFacility_char_id = (select char_id from characteristics where char_name = 'MOC Facility')
	set @MOCBusinessArea_char_id = (select char_id from characteristics where char_name = 'MOC Business Area')
	set @MOCArea_char_id = (select char_id from characteristics where char_name = 'MOC Area')
	set @MOCUnit_char_id = (select char_id from characteristics where char_name = 'MOC Unit')
	set @MOCStatus_char_id = (select char_id from characteristics where char_name = 'MOC Status')
	set @MOCDescription_char_id = (select char_id from characteristics where char_name = 'MOC Description')
	set @MOCLeader_char_id = (select char_id from characteristics where char_name = 'MOC Leader')
	set @MOCLeaderWinLoginId_char_id = (select char_id from characteristics where char_name = 'MOC Leader Win Login Id')
	set @MOCRiskRanking_char_id = (select char_id from characteristics where char_name = 'MOC Risk Ranking')
	set @MOCDateInitiated_char_id = (select char_id from characteristics where char_name = 'MOC Date Initiated')
	set @MOCTargetDate_char_id = (select char_id from characteristics where char_name = 'MOC Target Date')
	set @MOCClosureDate_char_id = (select char_id from characteristics where char_name = 'MOC Closure Date')
	set @MOCExpirationDate_char_id = (select char_id from characteristics where char_name = 'MOC Expiration Date')
	set @MOCTemporary_char_id = (select char_id from characteristics where char_name = 'MOC Temporary')
	set @MOCDepartment_char_id = (select char_id from characteristics where char_name = 'MOC Department')
	set @MOCUnitSupervisor_char_id = (select char_id from characteristics where char_name = 'MOC Unit Supervisor')
	set @MOCUnitSupervisorWinLoginId_char_id = (select char_id from characteristics where char_name = 'MOC Unit Supervisor Win Login Id')
	set @MOCActionFinancialPlanningComments_char_id = (select char_id from characteristics where char_name = 'MOC Action Financial Planning Comments')

	-- set all attributes except tech ids
	/* 
	exec @RC = ebp_set_char_data @pi_project_id, @MOCUnitId_char_id, @MOCUnitId, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCMocNo_char_id, @MOCMocNo, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	*/
	
	-- mocnumber acts as slave (phase 1)
	exec @RC = ebp_set_char_data @pi_project_id, @MOCNumber_char_id, @MOCNumber, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	
	exec @RC = ebp_set_char_data @pi_project_id, @MOCTitle_char_id, @MOCTitle, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCFacility_char_id, @MOCFacility, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCBusinessArea_char_id, @MOCBusinessArea, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCArea_char_id, @MOCArea, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCUnit_char_id, @MOCUnit, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCStatus_char_id, @MOCStatus, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCDescription_char_id, NULL, NULL, NULL, @MOCDescription, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCLeader_char_id, @MOCLeader, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCLeaderWinLoginId_char_id, @MOCLeaderWinLoginId, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCRiskRanking_char_id, @MOCRiskRanking, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCDateInitiated_char_id, NULL, NULL, @MOCDateInitiated, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCTargetDate_char_id, NULL, NULL, @MOCTargetDate, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCClosureDate_char_id, NULL, NULL, @MOCClosureDate, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCExpirationDate_char_id, NULL, NULL, @MOCExpirationDate, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCTemporary_char_id, @MOCTemporary, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCDepartment_char_id, @MOCDepartment, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCUnitSupervisor_char_id, @MOCUnitSupervisor, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCUnitSupervisorWinLoginId_char_id, @MOCUnitSupervisorWinLoginId, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @MOCActionFinancialPlanningComments_char_id, NULL, NULL, NULL, @MOCActionFinancialPlanningComments, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1

	-- Update Relationships 
	declare @leader_rel_template_id int = (select template_id from templates where name = 'ARE061A')
	declare @sup_rel_template_id int = (select template_id from templates where name = 'ARE060A')
	
    declare @leader_rel_type int = (select top 1 rel_type_id from relationship_types r join class_objects c on r.class_id = c.class_id
		where left_object_type = 9 and right_object_type = 4 and right_name = 'MOC Leader' and (c.superceded_by is null and c.date_obsolete is null))
		
	declare @sup_rel_type int = (select top 1 rel_type_id from relationship_types r join class_objects c on r.class_id = c.class_id
		where left_object_type = 9 and right_object_type = 4 and right_name = 'MOC Unit Supervisor' and (c.superceded_by is null and c.date_obsolete is null))
		
	declare @rel_id int
	
	-- delete existing
	declare deletions_cursor cursor for
		select rel_id from relationships 
		where rel_type_id in (@leader_rel_type, @sup_rel_type)
		and left_object_id = @pi_project_id
	open deletions_cursor 
	fetch next from deletions_cursor into @rel_id
	while @@FETCH_STATUS = 0
	begin
		begin try
			exec ebp_del_relationship @rel_id, 1
		end try
		begin catch
			-- silent skip
		end catch
		fetch next from deletions_cursor into @rel_id
	end
	close deletions_cursor
	deallocate deletions_cursor
	
	-- create new relationships
	declare @leader_person_id int = (select top 1 person_id from users where upper(user_id) = UPPER(@MOCLeaderWinLoginId))
	declare @sup_person_id int = (select top 1 person_id from users where upper(user_id) = UPPER(@MOCUnitSupervisorWinLoginId))
	
	-- we need to set correct default scope for ebp_create_rel_from_template
	DECLARE @ps_old_activated_scopes NVARCHAR(255);
	DECLARE @pi_old_default_scope_id int;
	
	-- get template scope
	declare @template_scope_id int = (select scope_id from objects o 
	join templates t on t.object_type = o.object_type and t.object_id = o.object_id
	and t.name = 'ARE061A')
	
	-- set temporarily the default scope to be the relationship templates scope (firebag)
	exec ebp_set_session_scopes '', @template_scope_id, @ps_old_activated_scopes out, @pi_old_default_scope_id out, 1
	
	begin try
		exec ebp_create_rel_from_template  @leader_rel_template_id, @pi_project_id, 9, @leader_person_id, 4, 1, null
	end try
	begin catch
		-- silent
	end catch
    
    begin try
		exec ebp_create_rel_from_template @sup_rel_template_id, @pi_project_id, 9, @sup_person_id, 4, 1, null
	end try
	begin catch
		-- silent
	end catch
    
    -- revert session to original scopes
    exec ebp_set_session_scopes @ps_old_activated_scopes, @pi_old_default_scope_id, null, null, 1
    
    RETURN 0 -- Success
END

/*
	declare @project_id int = (select top 1 project_id from projects where project_code = 'A03')
	begin transaction
	exec dbo.Suncor_SetProjectKMSAttributes @project_id
	commit

	select * from projects where project_code = 'A03'

	select * from Attributes_View
	where object_id = (select top 1 project_id from projects where project_code = 'A03')
	and char_id in (select char_id from characteristics 
									where object_type = 9 and char_name like 'MOC%')
	order by char_id

	select * from SUN_KMS_MOC

	select * from users
	select * from users where user_id = 'NETWORK\JINGLI'
	select * from persons where person_id = 432
*/
