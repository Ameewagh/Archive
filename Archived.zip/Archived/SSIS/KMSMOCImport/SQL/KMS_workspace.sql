truncate table sun_kms_MOC

select * from SUN_KMS_MOC
select * from SUN_KMS_MOC_Stage_Updates

select count(1) as NewProjectsCount from SUN_KMS_MOC where New is not null 

select MOCUnitId, MOCMocNo, MOCNumber, New, Updated from SUN_KMS_MOC
update SUN_KMS_MOC set Updated = 'Y' where MOCNumber = 'M20151184-001'



select e.project_code, e.project_id, e.MOCUnitId, e.MOCMocNo, 
case when (e.MOCMocNo IS NULL or e.MOCUnitId IS NULL) then 'Y' else 'N' end as is_orphan
from (
	select s.name as project_scope_name, p.project_code, s.scope_id, p.project_id, c1.char_value as MOCUnitId, c2.char_value as MOCMocNo
	from projects p 
	join objects o on p.project_id = o.object_id and o.object_type = 9
	join scopes s on s.scope_id = o.scope_id
	left outer join char_data c1 on p.project_id = c1.object_id and c1.char_id = (select char_id from characteristics where char_name = 'MOC Unit Id')
	left outer join char_data c2 on p.project_id = c2.object_id and c2.char_id = (select char_id from characteristics where char_name = 'MOC Moc No')
	where c2.char_value is not null and c1.char_value is not null
	and s.name = 'Firebag (FB)'
) e
left join SUN_KMS_MOC k
on k.MOCUnitId = e.MOCUnitId and k.MOCMocNo = e.MOCMocNo
order by project_id