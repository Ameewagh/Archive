
M2015798-001

select * from SUN_KMS_MOC

exec Suncor_MOCNumber_OnAttributeChanged

select * from projects where project_code like