Official design documentation:
IDD3166 Projects (MOCs) from KMS to eB Data Interface.doc
http://ecm/ecmlivelinkprd/llisapi.dll/open/360799945

WARNING: SQL script files in this folder may not be current. Extract current SQL from the Production database to be sure your changes start from the latest deployed changes.