select * from SUN_SAP_Project_WBS

select * from projects 

select * from SUN_SAP_Project_WBS
select * from SUN_SAP_Project_WBS_Stage_Updates


update s set s.Reload = 'Y' 
from SUN_SAP_Project_WBS p inner join SUN_SAP_Project_WBS_Stage_Updates s on s.WBSID = p.WBSID
and isnull(s.ChangedOn, '1900-01-01') >= isnull(p.ChangedOn, '1900-01-01')

select * from SUN_SAP_Project_WBS_Stage_Updates where Reload is null

-- and s.changedOn is null

select * from SUN_SAP_Project_WBS where ChangedOn > '2015-01-01'
update SUN_SAP_Project_WBS set ChangedOn = '2001-01-01' where WBSID = '00063432'

select case when CONVERT(datetime, '2013-01-31') < '1900-01-01' then 't' else 'f' end

select * from SUN_SAP_Project_WBS where WBSID = '02-00004'

select * from characteristics where char_data_type = 'PD' and object_type = 3
and edit_query not like '%char_user_defined%'

select replace(v.vitem_code, 'PSI ','') + ' ' + v.description value from vitems v inner join class_objects co on co.class_id = v.class_id and co.code = 'PSI'  order by v.vitem_code

SELECT s.WBS + ' - ' + ISNULL(s.WBSDesc, '') value  FROM SUN_SAP_Project_WBS s  ORDER BY s.WBS 

SELECT char_value value,obsolete is_obsolete FROM char_user_defined WHERE obsolete = 'N' AND char_id = 1

select c.char_name, u.char_value from characteristics c 
join char_user_defined u on u.char_id = c.char_id
where object_type = 9 and c.char_name in ('WBS Project Type', 'WBS Plant', 'SAP Project Plant')
and u.obsolete = 'N'

select * from base_types

select * from SUN_SAP_Project_WBS_Stage_Updates 
where Reload is null

update SUN_SAP_Project_WBS_Stage_Updates set Reload = null where wbsid = '00006541'

select * from stage_load_status where context_id = 'SAPProjectImport-STADF8465REML-D021015T092232;WBSElementSAPeB-20150921-112702.csv'

delete from stage_load_status_arc
select * from stage_load_status_arc where context_id like '%D081015T0333%'

declare @filename nvarchar(255)
set @filename = 'WBSElementSAPeB-20150921-112702.csv'
select stage_object_id objectId, status_code, status_msg ErrorMsg 
from stage_load_status_arc 
where context_id like '%' + @FileName + '%'
and status_code not in (5151,5109) and status_code > 5096
and status_msg is not null
group by stage_object_id, status_code, status_msg
order by status_msg


select c.char_name, u.char_value, 
SUBSTRING(u.char_value,1, CHARINDEX(' - ', u.char_value)) as code
from characteristics c 
join char_user_defined u on u.char_id = c.char_id
where object_type = 9 and c.char_name in ('WBS Project Type', 'WBS Plant', 'SAP Project Plant', 'WBS System Status', 'WBS User Status', 'SAP Project System Status', 'SAP Project User Status')
and u.obsolete = 'N'

