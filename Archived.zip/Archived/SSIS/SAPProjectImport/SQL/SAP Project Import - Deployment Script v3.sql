--
-- SAP Project - Deployment Script v3.sql
--

PRINT 'Creating Table SUN_SAP_Project_WBS...'

/****** Object:  Table [dbo].[SUN_SAP_Project_WBS]    Script Date: 10/05/2015 12:55:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SUN_SAP_Project_WBS]') AND type in (N'U'))
DROP TABLE [dbo].[SUN_SAP_Project_WBS]
GO

/****** Object:  Table [dbo].[SUN_SAP_Project_WBS]    Script Date: 10/05/2015 12:55:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SUN_SAP_Project_WBS](
	[WBSID] [nvarchar](50) NOT NULL,
	[WBS] [nvarchar](50) NULL,
	[WBSDesc] [nvarchar](50) NULL,
	[ProjID] [nvarchar](50) NULL,
	[WBSPMNum] [nvarchar](50) NULL,
	[WBSPMName] [nvarchar](50) NULL,
	[WBSApplNum] [nvarchar](50) NULL,
	[WBSApplName] [nvarchar](50) NULL,
	[WBSBasicStartDate] [date] NULL,
	[WBSBasicEndDate] [date] NULL,
	[WBSSystemStatus] [nvarchar](50) NULL,
	[WBSUserStatus] [nvarchar](50) NULL,
	[WBSProfitCtr] [nvarchar](50) NULL,
	[WBSProfitCtrDesc] [nvarchar](50) NULL,
	[WBSProfitCtrDept] [nvarchar](50) NULL,
	[WBSCostCtr] [nvarchar](50) NULL,
	[WBSCostCtrDesc] [nvarchar](50) NULL,
	[WBSCostCtrDept] [nvarchar](50) NULL,
	[WBSProjType] [nvarchar](50) NULL,
	[WBSLevel] [smallint] NULL,
	[WBSPlant] [nvarchar](50) NULL,
	[WBSECMRelevant] [nvarchar](50) NULL,
	[ProjProject] [nvarchar](50) NULL,
	[ProjDesc] [nvarchar](50) NULL,
	[ProjPMNum] [nvarchar](50) NULL,
	[ProjPMName] [nvarchar](50) NULL,
	[ProjApplNum] [nvarchar](50) NULL,
	[ProjApplName] [nvarchar](50) NULL,
	[ProjPlanStartDate] [date] NULL,
	[ProjPlanEndDate] [date] NULL,
	[ProjSystemStatus] [nvarchar](50) NULL,
	[ProjUserStatus] [nvarchar](50) NULL,
	[ProjProfitCtr] [nvarchar](50) NULL,
	[ProjProfitCtrDesc] [nvarchar](50) NULL,
	[ProjProfitCtrDept] [nvarchar](50) NULL,
	[ProjPlant] [nvarchar](50) NULL,
	[ChangedOn] [date] NULL,
	[New] [nvarchar](1) NULL,
	[Updated] [nvarchar](1) NULL,
 CONSTRAINT [PK_SUN_SAP_Project_WBS] PRIMARY KEY CLUSTERED 
(
	[WBSID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO


PRINT 'Creating Table SUN_SAP_Project_WBS_Stage_Updates...'


/****** Object:  Table [dbo].[SUN_SAP_Project_WBS_Stage_Updates]    Script Date: 10/05/2015 12:56:29 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SUN_SAP_Project_WBS_Stage_Updates]') AND type in (N'U'))
DROP TABLE [dbo].[SUN_SAP_Project_WBS_Stage_Updates]
GO

/****** Object:  Table [dbo].[SUN_SAP_Project_WBS_Stage_Updates]    Script Date: 10/05/2015 12:56:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SUN_SAP_Project_WBS_Stage_Updates](
	[WBSID] [nvarchar](50) NOT NULL,
	[WBS] [nvarchar](50) NULL,
	[WBSDesc] [nvarchar](50) NULL,
	[ProjID] [nvarchar](50) NULL,
	[WBSPMNum] [nvarchar](50) NULL,
	[WBSPMName] [nvarchar](50) NULL,
	[WBSApplNum] [nvarchar](50) NULL,
	[WBSApplName] [nvarchar](50) NULL,
	[WBSBasicStartDate] [date] NULL,
	[WBSBasicEndDate] [date] NULL,
	[WBSSystemStatus] [nvarchar](50) NULL,
	[WBSUserStatus] [nvarchar](50) NULL,
	[WBSProfitCtr] [nvarchar](50) NULL,
	[WBSProfitCtrDesc] [nvarchar](50) NULL,
	[WBSProfitCtrDept] [nvarchar](50) NULL,
	[WBSCostCtr] [nvarchar](50) NULL,
	[WBSCostCtrDesc] [nvarchar](50) NULL,
	[WBSCostCtrDept] [nvarchar](50) NULL,
	[WBSProjType] [nvarchar](50) NULL,
	[WBSLevel] [smallint] NULL,
	[WBSPlant] [nvarchar](50) NULL,
	[WBSECMRelevant] [nvarchar](50) NULL,
	[ProjProject] [nvarchar](50) NULL,
	[ProjDesc] [nvarchar](50) NULL,
	[ProjPMNum] [nvarchar](50) NULL,
	[ProjPMName] [nvarchar](50) NULL,
	[ProjApplNum] [nvarchar](50) NULL,
	[ProjApplName] [nvarchar](50) NULL,
	[ProjPlanStartDate] [date] NULL,
	[ProjPlanEndDate] [date] NULL,
	[ProjSystemStatus] [nvarchar](50) NULL,
	[ProjUserStatus] [nvarchar](50) NULL,
	[ProjProfitCtr] [nvarchar](50) NULL,
	[ProjProfitCtrDesc] [nvarchar](50) NULL,
	[ProjProfitCtrDept] [nvarchar](50) NULL,
	[ProjPlant] [nvarchar](50) NULL,
	[ChangedOn] [date] NULL,
	[Reload] [nvarchar](1) NULL,
 CONSTRAINT [PK_SUN_SAP_Project_WBS_Stage_Updates] PRIMARY KEY CLUSTERED 
(
	[WBSID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 90) ON [PRIMARY]
) ON [PRIMARY]

GO



PRINT 'Creating Stored Procedure Suncor_SetProjectSAPAttributes...'


/****** Object:  StoredProcedure [dbo].[Suncor_SetProjectSAPAttributes]    Script Date: 11/16/2015 12:22:50 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Suncor_SetProjectSAPAttributes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Suncor_SetProjectSAPAttributes]
GO

/****** Object:  StoredProcedure [dbo].[Suncor_SetProjectSAPAttributes]    Script Date: 11/16/2015 12:22:50 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[Suncor_SetProjectSAPAttributes]
(
	@pi_called_by			INT,
    @pi_project_id			INT,
    @pi_update_wbs_element	INT
) 
AS

-- Parameter @pi_update_wbs_element allows skipping update of the 'WBS Element' attribute.
-- This is set to 1 when called from SSIS loading data from SAP
-- This is set to 0 when called form the event handler, since the event was triggered
-- on change of the WBS Element attribute, so we don't want to update it and end up in a loop.

BEGIN
    SET NOCOUNT ON
	
	DECLARE @RC INT

	-- Declare vars for each column to be retrieved from the WBS table
	DECLARE @WBS [nvarchar](50);
	DECLARE @WBSDesc [nvarchar](50);
	DECLARE @ProjID [nvarchar](50);
	DECLARE @WBSPMNum [nvarchar](50);
	DECLARE @WBSPMName [nvarchar](50);
	DECLARE @WBSApplNum [nvarchar](50);
	DECLARE @WBSApplName [nvarchar](50);
	DECLARE @WBSBasicStartDate [date]
	DECLARE @WBSBasicEndDate [date]
	DECLARE @WBSSystemStatus [nvarchar](50);
	DECLARE @WBSUserStatus [nvarchar](50);
	DECLARE @WBSProfitCtr [nvarchar](50);
	DECLARE @WBSProfitCtrDesc [nvarchar](50);
	DECLARE @WBSProfitCtrDept [nvarchar](50);
	DECLARE @WBSCostCtr [nvarchar](50);
	DECLARE @WBSCostCtrDesc [nvarchar](50);
	DECLARE @WBSCostCtrDept [nvarchar](50);
	DECLARE @WBSProjType [nvarchar](50);
	DECLARE @WBSLevel [smallint]
	DECLARE @WBSPlant [nvarchar](50);
	DECLARE @WBSECMRelevant [nvarchar](50);
	DECLARE @ProjProject [nvarchar](50);
	DECLARE @ProjDesc [nvarchar](50);
	DECLARE @ProjPMNum [nvarchar](50);
	DECLARE @ProjPMName [nvarchar](50);
	DECLARE @ProjApplNum [nvarchar](50);
	DECLARE @ProjApplName [nvarchar](50);
	DECLARE @ProjPlanStartDate [date]
	DECLARE @ProjPlanEndDate [date]
	DECLARE @ProjSystemStatus [nvarchar](50);
	DECLARE @ProjUserStatus [nvarchar](50);
	DECLARE @ProjProfitCtr [nvarchar](50);
	DECLARE @ProjProfitCtrDesc [nvarchar](50);
	DECLARE @ProjProfitCtrDept [nvarchar](50);
	DECLARE @ProjPlant [nvarchar](50);
	DECLARE @ChangedOn [date];
	
    -- Fetch all the "simple" values from the WBS table into the above variables.

    -- We match the given eB Project ID to the correct entry in the SAP WBS table using the WBS Technical ID.
    -- We include only those rows from the SAP table that are WBSECMRelevant = 'X'. This ensures if this flag
    -- is REMOVED in SAP, we blank out all the SAP values from this project in eB. This flag means we will no
    -- longer receive updates from SAP on that row, so the data will become obsolete over time. Hence we hide
    -- it from eB.
    select 
		 @WBS = w.WBS
		,@WBSDesc = w.WBSDesc
		,@ProjID = w.ProjID
		,@WBSPMNum = w.WBSPMNum
		,@WBSPMName = w.WBSPMName
		,@WBSApplNum = w.WBSApplNum
		,@WBSApplName = w.WBSApplName
		,@WBSBasicStartDate = w.WBSBasicStartDate
		,@WBSBasicEndDate = w.WBSBasicEndDate
		,@WBSSystemStatus = w.WBSSystemStatus
		,@WBSUserStatus = w.WBSUserStatus
		,@WBSProfitCtr = w.WBSProfitCtr
		,@WBSProfitCtrDesc = w.WBSProfitCtrDesc
		,@WBSProfitCtrDept = w.WBSProfitCtrDept
		,@WBSCostCtr = w.WBSCostCtr
		,@WBSCostCtrDesc = w.WBSCostCtrDesc
		,@WBSCostCtrDept = w.WBSCostCtrDept
		,@WBSProjType = w.WBSProjType
		,@WBSLevel = w.WBSLevel
		,@WBSPlant = w.WBSPlant
		,@WBSECMRelevant = w.WBSECMRelevant
		,@ProjProject = w.ProjProject
		,@ProjDesc = w.ProjDesc
		,@ProjPMNum = w.ProjPMNum
		,@ProjPMName = w.ProjPMName
		,@ProjApplNum = w.ProjApplNum
		,@ProjApplName = w.ProjApplName
		,@ProjPlanStartDate = w.ProjPlanStartDate
		,@ProjPlanEndDate = w.ProjPlanEndDate
		,@ProjSystemStatus = w.ProjSystemStatus
		,@ProjUserStatus = w.ProjUserStatus
		,@ProjProfitCtr = w.ProjProfitCtr
		,@ProjProfitCtrDesc = w.ProjProfitCtrDesc
		,@ProjProfitCtrDept = w.ProjProfitCtrDept
		,@ProjPlant = w.ProjPlant
		,@ChangedOn = w.ChangedOn
    from
		projects p (nolock)
		inner join char_data cd (nolock) on p.project_id = cd.object_id
		inner join characteristics c (nolock) on cd.char_id = c.char_id and c.object_type = 9 and c.char_name = 'WBS Technical Identifier'
		inner join SUN_SAP_Project_WBS w (nolock) on cd.char_value = w.WBSID
	where p.project_id = @pi_project_id
		and p.template = 'N'
		and w.WBSECMRelevant = 'X'
   
	-- Merge values that require concatenation e.g. "Code - Description" style merged fields
	-- Declare new merged vars (e.g. "...Num_Name" is the hint that it's a merged field)
	DECLARE @WBS_WBSDesc [nvarchar](100);
	DECLARE @WBSPMNum_Name [nvarchar](100);
	DECLARE @WBSApplNum_Name [nvarchar](100);
	DECLARE @WBSProfitCtr_Desc [nvarchar](100);
	DECLARE @WBSCostCtr_Desc [nvarchar](100);
	DECLARE @ProjProject_Desc [nvarchar](100);
	DECLARE @ProjPMNum_Name [nvarchar](100);
	DECLARE @ProjApplNum_Name [nvarchar](100);
	DECLARE @ProjProfitCtr_Desc [nvarchar](100);
	-- Assign merged values
	-- If the code is NULl or blank then the entire value is blank
	-- In case the description is NULL convert it to an empty string, so the entire expression does not become NULL.
	SET @WBS_WBSDesc = @WBS + ' - ' + ISNULL(@WBSDesc, '')
	SET @WBSPMNum_Name = CASE WHEN (@WBSPMNum IS NULL) OR (@WBSPMNum = '') THEN '' ELSE @WBSPMNum + ' - ' + ISNULL(@WBSPMName, '') END
	SET @WBSApplNum_Name = CASE WHEN (@WBSApplNum IS NULL) OR (@WBSApplNum = '') THEN '' ELSE @WBSApplNum + ' - ' + ISNULL(@WBSApplName, '') END
	SET @WBSProfitCtr_Desc = CASE WHEN (@WBSProfitCtr IS NULL) OR (@WBSProfitCtr = '') THEN '' ELSE @WBSProfitCtr + ' - ' + ISNULL(@WBSProfitCtrDesc, '') END
	SET @WBSCostCtr_Desc = CASE WHEN (@WBSCostCtr IS NULL) OR (@WBSCostCtr = '') THEN '' ELSE @WBSCostCtr + ' - ' + ISNULL(@WBSCostCtrDesc, '') END
	SET @ProjProject_Desc = CASE WHEN (@ProjProject IS NULL) OR (@ProjProject = '') THEN '' ELSE @ProjProject + ' - ' + ISNULL(@ProjDesc, '') END
	SET @ProjPMNum_Name = CASE WHEN (@ProjPMNum IS NULL) OR (@ProjPMNum = '') THEN '' ELSE @ProjPMNum + ' - ' + ISNULL(@ProjPMName, '') END
	SET @ProjApplNum_Name = CASE WHEN (@ProjApplNum IS NULL) OR (@ProjApplNum = '') THEN '' ELSE @ProjApplNum + ' - ' + ISNULL(@ProjApplName, '') END
	SET @ProjProfitCtr_Desc = CASE WHEN (@ProjProfitCtr IS NULL) OR (@ProjProfitCtr = '') THEN '' ELSE @ProjProfitCtr + ' - ' + ISNULL(@ProjProfitCtrDesc, '') END

	-- Find the char_id value of each eB Attribute to be updated.
	-- Declare vars
	declare @WBS_char_id int
	declare @ProjID_char_id int
	declare @WBSPMNum_char_id int
	declare @WBSApplNum_char_id int
	declare @WBSBasicStartDate_char_id int
	declare @WBSBasicEndDate_char_id int
	declare @WBSSystemStatus_char_id int
	declare @WBSUserStatus_char_id int
	declare @WBSProfitCtr_char_id int
	declare @WBSProfitCtrDept_char_id int
	declare @WBSCostCtr_char_id int
	declare @WBSCostCtrDept_char_id int
	declare @WBSProjType_char_id int
	declare @WBSLevel_char_id int
	declare @WBSPlant_char_id int
	declare @ProjProject_char_id int
	declare @ProjPMNum_char_id int
	declare @ProjApplNum_char_id int
	declare @ProjPlanStartDate_char_id int
	declare @ProjPlanEndDate_char_id int
	declare @ProjSystemStatus_char_id int
	declare @ProjUserStatus_char_id int
	declare @ProjProfitCtr_char_id int
	declare @ProjProfitCtrDept_char_id int
	declare @ProjPlant_char_id int
	declare @ChangedOn_char_id int
	
	-- merged versions of the multi-valued attributes
	declare @WBSSystemStatusMerged_char_id int
	declare @WBSUserStatusMerged_char_id int
	declare @ProjSystemStatusMerged_char_id int
	declare @ProjUserStatusMerged_char_id int

	
	-- Assign values
	select @WBS_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'WBS Element'
	select @ProjID_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'SAP Project Identifier'
	select @WBSPMNum_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'WBS Manager'
	select @WBSApplNum_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'WBS Applicant'
	select @WBSBasicStartDate_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'WBS Planned Start Date'
	select @WBSBasicEndDate_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'WBS Planned End Date'
	select @WBSSystemStatus_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'WBS System Status'
	select @WBSUserStatus_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'WBS User Status'
	select @WBSProfitCtr_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'WBS Profit Center'
	select @WBSProfitCtrDept_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'WBS Profit Center Department'
	select @WBSCostCtr_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'WBS Requesting Cost Center'
	select @WBSCostCtrDept_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'WBS Cost Center Department'
	select @WBSProjType_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'WBS Project Type'
	select @WBSLevel_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'WBS Level in Project Hierarchy'
	select @WBSPlant_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'WBS Plant'
	select @ProjProject_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'SAP Project Name'
	select @ProjPMNum_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'SAP Project Manager'
	select @ProjApplNum_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'SAP Project Applicant'
	select @ProjPlanStartDate_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'SAP Project Start Date'
	select @ProjPlanEndDate_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'SAP Project End Date'
	select @ProjSystemStatus_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'SAP Project System Status'
	select @ProjUserStatus_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'SAP Project User Status'
	select @ProjProfitCtr_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'SAP Project Profit Center'
	select @ProjProfitCtrDept_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'SAP Project Profit Center Department'
	select @ProjPlant_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'SAP Project Plant'
	select @ChangedOn_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'SAP Object Changed On'

	-- merged version of multi-valued attributes
	select @WBSSystemStatusMerged_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'WBS System Status Merged'
	select @WBSUserStatusMerged_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'WBS User Status Merged'
	select @ProjSystemStatusMerged_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'SAP Project System Status Merged'
	select @ProjUserStatusMerged_char_id = c.char_id from characteristics c (nolock) where c.object_type = 9 and c.char_name = 'SAP Project User Status Merged'

    -- Now update the values into the eB project.
    -- Update the "WBS Element" attribute ONLY if told to in the input parameter @pi_update_wbs_element.
	IF @pi_update_wbs_element = 1
	BEGIN
		exec @RC = ebp_set_char_data @pi_project_id, @WBS_char_id, @WBS_WBSDesc, NULL, NULL, NULL, 1
		if @@ERROR <> 0 or @RC <> 0 RETURN 1
	END

	-- simple text attributes
	exec @RC = ebp_set_char_data @pi_project_id, @ProjID_char_id, @ProjID, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @WBSPMNum_char_id, @WBSPMNum_Name, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @WBSApplNum_char_id, @WBSApplNum_Name, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @WBSBasicStartDate_char_id, NULL, NULL, @WBSBasicStartDate, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @WBSBasicEndDate_char_id, NULL, NULL, @WBSBasicEndDate, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @WBSProfitCtr_char_id, @WBSProfitCtr_Desc, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @WBSProfitCtrDept_char_id, @WBSProfitCtrDept, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @WBSCostCtr_char_id, @WBSCostCtr_Desc, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @WBSCostCtrDept_char_id, @WBSCostCtrDept, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @WBSLevel_char_id, NULL, @WBSLevel, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @ProjProject_char_id, @ProjProject_Desc, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @ProjPMNum_char_id, @ProjPMNum_Name, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @ProjApplNum_char_id, @ProjApplNum_Name, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @ProjPlanStartDate_char_id, NULL, NULL, @ProjPlanStartDate, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @ProjPlanEndDate_char_id, NULL, NULL, @ProjPlanEndDate, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @ProjProfitCtr_char_id, @ProjProfitCtr_Desc, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @ProjProfitCtrDept_char_id, @ProjProfitCtrDept, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @ChangedOn_char_id, NULL, NULL, @ChangedOn, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	
	-- merged versions of the multi-valued attributes
	exec @RC = ebp_set_char_data @pi_project_id, @WBSSystemStatusMerged_char_id, @WBSSystemStatus, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @WBSUserStatusMerged_char_id, @WBSUserStatus, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @ProjSystemStatusMerged_char_id, @ProjSystemStatus, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	exec @RC = ebp_set_char_data @pi_project_id, @ProjUserStatusMerged_char_id, @ProjUserStatus, NULL, NULL, NULL, 1
	if @@ERROR <> 0 or @RC <> 0 RETURN 1
	
	-- For the following fixed value fields, if we do not find match on the Code then we ignore that and continue.
	-- eB has no elegant way to notify the Admin of this data issue, other than blocking the user with an error.
	-- Instead we allow the user operation to continue, and trust the SSIS loader would already have pre-validated
	-- the Codes received from SAP against the eB fixed value list; and also that differences would be highlighted
	-- in the Validation Report.
	
	-- Update fixed value attributes. Look up the eB "Code - Description" based on just the "Code" value from SAP.
	-- single valued fixed list attributes - put in a table
	declare @fixed_attrs  table (char_id int, value nvarchar(50), match nvarchar(255))
	insert into @fixed_attrs (char_id, value) values (@WBSProjType_char_id, @WBSProjType);
	insert into @fixed_attrs (char_id, value) values (@WBSPlant_char_id, @WBSPlant);
	insert into @fixed_attrs (char_id, value) values (@ProjPlant_char_id, @ProjPlant);
	
	-- lookup "code - description" and update match field of the table
	update fa set match = d.char_value
	from @fixed_attrs fa 
	join char_user_defined d on d.char_id = fa.char_id 
	and fa.value = substring(d.char_value, 1, charindex(' - ', d.char_value))
	
	-- set value
	declare fixed_attrs_cursor cursor for
		select char_id, match from @fixed_attrs
	declare @char_id int
	declare @char_value nvarchar(255)
	open fixed_attrs_cursor 
	fetch next from fixed_attrs_cursor into @char_id, @char_value
	while @@FETCH_STATUS = 0
	begin
		begin try
			exec ebp_set_char_data @pi_project_id, @char_id, @char_value, NULL, NULL, NULL, 1
		end try
		begin catch
			-- silent skip
		end catch
		fetch next from fixed_attrs_cursor into @char_id, @char_value
	end
	close fixed_attrs_cursor
	deallocate fixed_attrs_cursor
   
    -- multi-valued fixed list attributes into a table
	declare @mv_attrs  table (char_id int, value nvarchar(50), match nvarchar(255))
	insert into @mv_attrs (char_id, value) select distinct @WBSSystemStatus_char_id, Data from Split(@WBSSystemStatus, ' ')
	insert into @mv_attrs (char_id, value) select distinct @WBSUserStatus_char_id, Data from Split(@WBSUserStatus, ' ')
	insert into @mv_attrs (char_id, value) select distinct @ProjSystemStatus_char_id, Data from Split(@ProjSystemStatus, ' ')
	insert into @mv_attrs (char_id, value) select distinct @ProjUserStatus_char_id, Data from Split(@ProjUserStatus, ' ')

	-- lookup "code - description" and update match field of the table
	update mv set match = d.char_value
	from @mv_attrs mv 
	join char_user_defined d on d.char_id = mv.char_id 
	and mv.value = substring(d.char_value, 1, charindex(' - ', d.char_value))

    -- delete obsolete existing multi-values
	declare deletions_cursor cursor for
		select char_id, row_id 
		from char_data_mv c
		where c.char_value is not null and c.object_id = @pi_project_id 
		and char_id in (select char_id from @mv_attrs)
		and not exists (
			select * from @mv_attrs m
			where c.char_id = m.char_id and c.object_id = @pi_project_id 
			and c.char_value = m.match	
		)
	declare @row_id int
	open deletions_cursor 
	fetch next from deletions_cursor into @char_id, @row_id
	while @@FETCH_STATUS = 0
	begin
		begin try
			exec ebp_del_char_data_mv @pi_project_id, @char_id, @row_id, 1
		end try
		begin catch
			-- silent skip
		end catch
		fetch next from deletions_cursor into @char_id, @row_id
	end
	close deletions_cursor
	deallocate deletions_cursor

	-- add new multi-values
	declare additions_cursor cursor for
		select char_id, m.match
		from @mv_attrs m
		where not exists (
			select * from char_data_mv c
			where c.char_id = m.char_id and c.object_id = @pi_project_id and c.char_value = m.match
		) and m.match is not null
	declare @pi_row_id int
	open additions_cursor 
	fetch next from additions_cursor into @char_id, @char_value
	while @@FETCH_STATUS = 0
	begin
		begin try
			exec ebp_add_char_data_mv @pi_project_id, @char_id, @char_value, 1, @pi_row_id OUTPUT
		end try
		begin catch
			-- silently ignore
			-- select ERROR_MESSAGE()
		end catch
		fetch next from additions_cursor into @char_id, @char_value
	end

	close additions_cursor
	deallocate additions_cursor
    
    RETURN 0
END





GO





PRINT 'Creating Stored Procedure Suncor_SetAllProjectsSAPAttributes...'


/****** Object:  StoredProcedure [dbo].[Suncor_SetAllProjectsSAPAttributes]    Script Date: 11/16/2015 16:41:34 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Suncor_SetAllProjectsSAPAttributes]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Suncor_SetAllProjectsSAPAttributes]
GO

/****** Object:  StoredProcedure [dbo].[Suncor_SetAllProjectsSAPAttributes]    Script Date: 11/16/2015 16:41:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE PROCEDURE [dbo].[Suncor_SetAllProjectsSAPAttributes]
AS

BEGIN
	SET NOCOUNT ON
	
	-- Match all eB Projects to their staged WBS entry based on their WBS ID (technical key)
	-- Loop through them with a cursor, calling Suncor_SetProjectSAPAttributes for each one.

	DECLARE @project_id INT
	
	DECLARE The_Cursor CURSOR FOR

		select p.project_id
		from projects p (nolock)
		inner join char_data cd (nolock) on p.project_id = cd.object_id
		inner join characteristics c (nolock) on cd.char_id = c.char_id and c.object_type = 9 and c.char_name = 'WBS Technical Identifier'
		left join SUN_SAP_Project_WBS w (nolock) on cd.char_value = w.WBSID --and w.WBSECMRelevant = 'X'
		where p.template = 'N'
		and (w.Updated = 'Y' or w.New = 'Y')

	OPEN The_Cursor
	
	FETCH NEXT FROM The_Cursor INTO @project_id
	
	WHILE @@FETCH_STATUS = 0
	BEGIN
		-- DO update the WBS Element attribute in case it changed from SAP
		BEGIN TRAN
			EXEC Suncor_SetProjectSAPAttributes 1, @project_id, 1
		COMMIT TRAN
		FETCH NEXT FROM The_Cursor INTO @project_id
	END
	
	CLOSE The_Cursor
	DEALLOCATE The_Cursor
	
    RETURN 0
END






GO





PRINT 'Creating Stored Procedure Suncor_SetProjectSAPWBSID...'


/****** Object:  StoredProcedure [dbo].[Suncor_SetProjectSAPWBSID]    Script Date: 10/05/2015 13:01:12 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Suncor_SetProjectSAPWBSID]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[Suncor_SetProjectSAPWBSID]
GO

/****** Object:  StoredProcedure [dbo].[Suncor_SetProjectSAPWBSID]    Script Date: 10/05/2015 13:01:12 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[Suncor_SetProjectSAPWBSID]
(
	@ps_sender NVARCHAR(255),
	@pi_called_by INT,
	@pi_object_id INT,
	@pi_object_type INT,
	@pi_attrib_id INT
)
AS

BEGIN
	SET NOCOUNT ON
	
	-- If the Project attribute named 'WBS Element' was changed
	-- then populate the attribute named 'WBS Technical Identifier'
	-- from the table SUN_SAP_Project_WBS
	-- Then refresh the other SAP attributes
	-- *** BUT: don't update the 'WBS Element' attribute to avoid an endless loop! ***
	IF (@pi_object_type = 9 and
		exists(select 1 from characteristics c (nolock) where c.char_name = 'WBS Element' and c.char_id = @pi_attrib_id) )
	BEGIN
		DECLARE @WBSElement_Desc nvarchar(100)
		DECLARE @NewWBSID nvarchar(50)
		DECLARE @WBSID_char_id int
		
		-- Get the current value of the WBS Element (number - description) from this project
		select @WBSElement_Desc = cd.char_value from char_data cd (nolock)
		where cd.char_id = @pi_attrib_id and cd.object_id = @pi_object_id
		
		-- Get the new ID from the WBS table using this value
		select @NewWBSID = w.WBSID from SUN_SAP_Project_WBS w (nolock)
		where w.WBS + ' - ' + ISNULL(w.WBSDesc, '') = @WBSElement_Desc
		
		-- Get the char_id of the WBS Technical Identifier attribute to be updated
		select @WBSID_char_id = c.char_id from characteristics c (nolock)
		where c.object_type = @pi_object_type
		and c.char_name = 'WBS Technical Identifier'
		
		-- Assign the new value to the WBS Technical Identifier
		exec ebp_set_char_data @pi_object_id, @WBSID_char_id, @NewWBSID, NULL, NULL, NULL, @pi_called_by
		-- Refresh this project's SAP attributes now that the WBS ID has changed.
		-- DO NOT update the WBS Element attribute or we will end up in an endless loop.
		exec Suncor_SetProjectSAPAttributes @pi_called_by, @pi_object_id, 0
	END
	
    RETURN 0
END



GO



PRINT 'Adding the Stored Procedure "Suncor_SetProjectSAPWBSID" as an event handler to the "OnAttributeChanged" event...'

-- Add the Stored Procedure "Suncor_SetProjectSAPWBSID" as an event handler to the "OnAttributeChanged" event.
BEGIN
	DECLARE @li_event_id int;

    SELECT @li_event_id = event_id from db_events(NOLOCK) WHERE name = 'OnAttributeChanged'

    IF NOT EXISTS ( SELECT 1 FROM db_event_handlers(NOLOCK) 
		WHERE event_id = @li_event_id AND code_ref = N'Suncor_SetProjectSAPWBSID' )
    BEGIN
		EXEC ebp_add_db_event_handler @li_event_id, N'Suncor_SetProjectSAPWBSID', 0, N'N',1
    END
END   

GO
