IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SUN_PROJ_Validation_Differences]'))
DROP VIEW [dbo].[SUN_PROJ_Validation_Differences]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[SUN_PROJ_Validation_Differences]
AS 

select *

from SUN_PROJ_Validation_Comparison c
where 
   c.missing = 1
or c.extra = 1
or c.wrong_projectcode = 1
or c.wrong_description = 1
or c.wrong_wbselement = 1
or c.wrong_wbsmanager = 1
or c.wrong_wbsapplicant = 1
or c.wrong_wbsplannedstartdate = 1
or c.wrong_wbsplannedenddate = 1
or c.wrong_wbssystemstatusmerged = 1
or c.wrong_wbsuserstatusmerged = 1
or c.wrong_wbsprofitcenter = 1
or c.wrong_wbsprofitcenterdepartment = 1
or c.wrong_wbsrequestingcostcenter = 1
or c.wrong_wbscostcenterdepartment = 1
or c.wrong_wbsprojecttype = 1
or c.wrong_wbslevelinprojecthierarchy = 1
or c.wrong_wbsplant = 1
or c.wrong_sapprojectidentifier = 1
or c.wrong_sapprojectname = 1
or c.wrong_sapprojectmanager = 1
or c.wrong_sapprojectapplicant = 1
or c.wrong_sapprojectstartdate = 1
or c.wrong_sapprojectenddate = 1
or c.wrong_sapprojectsystemstatusmerged = 1
or c.wrong_sapprojectuserstatusmerged = 1
or c.wrong_sapprojectprofitcenter = 1
or c.wrong_sapprojectprofitcenterdepartment = 1
or c.wrong_sapprojectplant = 1
or c.wrong_wbssystemstatus = 1
or c.wrong_wbsuserstatus = 1
or c.wrong_sapsystemstatus = 1
or c.wrong_sapuserstatus = 1
or c.wrong_changedon = 1

GO
