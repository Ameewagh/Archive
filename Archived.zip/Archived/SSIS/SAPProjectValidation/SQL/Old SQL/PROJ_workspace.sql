select * from SUN_PROJ_Validation_SAP_Stage  order by WBSElement

select * from SUN_PROJ_Validation_eB where WBSElement like '01-00132-01%'
order by WBSElement

select * from SUN_PROJ_Validation_Comparison where EB_WBSElement like '01-00132%'
order by SAP_WBSElement


select * from SUN_PROJ_Validation_Differences order by SAP_WBSElement




