IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SUN_PROJ_Validation_SAP_Stage]') AND type in (N'U'))
DROP TABLE [dbo].[SUN_PROJ_Validation_SAP_Stage]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[SUN_PROJ_Validation_SAP_Stage](
	[LoadDateTime] [datetime] NULL,
	[rownum] [int] NULL,
	[WBSElement] [nvarchar](255) NULL,
	[WBSElementStruc] [nvarchar](255) NULL,
	[WBSElementDesc] [nvarchar](255) NULL,
	[WBSProjManager] [nvarchar](255) NULL,
	[WBSProjManagerName] [nvarchar](255) NULL,
	[WBSApplicant] [nvarchar](255) NULL,
	[WBSApplicantName] [nvarchar](255) NULL,
	[WBSBasicStart] [nvarchar](255) NULL,
	[WBSBasicFinish] [nvarchar](255) NULL,
	[WBSSystStatus] [nvarchar](255) NULL,
	[WBSUserStatus] [nvarchar](255) NULL,
	[WBSProfitCent] [nvarchar](255) NULL,
	[WBSProfCenterDesc] [nvarchar](255) NULL,
	[WBSProfCenterDept] [nvarchar](255) NULL,
	[WBSCostCenter] [nvarchar](255) NULL,
	[WBSCostCenterDesc] [nvarchar](255) NULL,
	[WBSCostCenterDept] [nvarchar](255) NULL,
	[ProjectType] [nvarchar](255) NULL,
	[ProjHierLev] [nvarchar](255) NULL,
	[WBSPlant] [nvarchar](255) NULL,
	[ProjDefinition] [nvarchar](255) NULL,
	[ProjDefStruc] [nvarchar](255) NULL,
	[ProjDefDesc] [nvarchar](255) NULL,
	[PROJProjManager] [nvarchar](255) NULL,
	[PROJProjMgrName] [nvarchar](255) NULL,
	[PROJWBSApplicant] [nvarchar](255) NULL,
	[PROJWBSApplicantName] [nvarchar](255) NULL,
	[PROJStartDate] [nvarchar](255) NULL,
	[PROJFinishDate] [nvarchar](255) NULL,
	[PROJSystStatus] [nvarchar](255) NULL,
	[PROJUserStatus] [nvarchar](255) NULL,
	[PROJProfitCenter] [nvarchar](255) NULL,
	[PROJProfCtrDesc] [nvarchar](255) NULL,
	[PROJProfCtrDept] [nvarchar](255) NULL,
	[PROJPlant] [nvarchar](255) NULL,
	[LastChgedDte] [nvarchar](255) NULL,
	[ECMRel] [nvarchar](255) NULL
) ON [PRIMARY]

GO


