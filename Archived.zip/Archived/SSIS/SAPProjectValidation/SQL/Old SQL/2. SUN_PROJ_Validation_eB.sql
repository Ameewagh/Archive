IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SUN_PROJ_Validation_eB]'))
DROP VIEW [dbo].[SUN_PROJ_Validation_eB]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[SUN_PROJ_Validation_eB]
AS 

select 
-- Keys
  p.project_id

-- Project attributes
, p.project_code as ProjectCode
, p.description as Description
, attribs.WBSElement
, attribs.WBSManager
, attribs.WBSApplicant
, attribs.WBSPlannedStartDate
, attribs.WBSPlannedEndDate
, attribs.WBSSystemStatusMerged
, attribs.WBSUserStatusMerged
, attribs.WBSProfitCenter
, attribs.WBSProfitCenterDepartment
, attribs.WBSRequestingCostCenter
, attribs.WBSCostCenterDepartment
, LTRIM(RTRIM(SUBSTRING(attribs.WBSProjectType, 1, CHARINDEX(' - ', attribs.WBSProjectType)))) as WBSProjectType
, attribs.WBSLevelinProjectHierarchy
, LTRIM(RTRIM(SUBSTRING(attribs.WBSPlant, 1, CHARINDEX(' - ', attribs.WBSPlant)))) as WBSPlant
, attribs.SAPProjectIdentifier
, attribs.SAPProjectName
, attribs.SAPProjectManager
, attribs.SAPProjectApplicant
, attribs.SAPProjectStartDate
, attribs.SAPProjectEndDate
, attribs.SAPProjectSystemStatusMerged
, attribs.SAPProjectUserStatusMerged
, attribs.SAPProjectProfitCenter
, attribs.SAPProjectProfitCenterDepartment
, LTRIM(RTRIM(SUBSTRING(attribs.SAPProjectPlant, 1, CHARINDEX(' - ', attribs.SAPProjectPlant)))) as SAPProjectPlant
, wbssysstat.WBSSystemStatuses
, wbsuserstat.WBSUserStatuses
, sapsysstat.SAPSystemStatuses
, sapuserstat.SAPUserStatuses
, attribs.SAPObjectChangedOn

from projects p (nolock)

-- Join to a super fast PIVOT of all (single-value) attributes in the char_data table.
left join (
		select 
			  object_id
			, MAX(case char_name when 'WBS Element' then char_value end) WBSElement
			, MAX(case char_name when 'WBS Manager' then char_value end) WBSManager
			, MAX(case char_name when 'WBS Applicant' then char_value end) WBSApplicant
			, MAX(case char_name when 'WBS Planned Start Date' then date_value end) WBSPlannedStartDate
			, MAX(case char_name when 'WBS Planned End Date' then date_value end) WBSPlannedEndDate
			, MAX(case char_name when 'WBS System Status Merged' then char_value end) WBSSystemStatusMerged
			, MAX(case char_name when 'WBS User Status Merged' then char_value end) WBSUserStatusMerged
			, MAX(case char_name when 'WBS Profit Center' then char_value end) WBSProfitCenter
			, MAX(case char_name when 'WBS Profit Center Department' then char_value end) WBSProfitCenterDepartment
			, MAX(case char_name when 'WBS Requesting Cost Center' then char_value end) WBSRequestingCostCenter
			, MAX(case char_name when 'WBS Cost Center Department' then char_value end) WBSCostCenterDepartment
			, MAX(case char_name when 'WBS Project Type' then char_value end) WBSProjectType
			, MAX(case char_name when 'WBS Level in Project Hierarchy' then number_value end) WBSLevelinProjectHierarchy
			, MAX(case char_name when 'WBS Plant' then char_value end) WBSPlant
			, MAX(case char_name when 'SAP Project Identifier' then char_value end) SAPProjectIdentifier
			, MAX(case char_name when 'SAP Project Name' then char_value end) SAPProjectName
			, MAX(case char_name when 'SAP Project Manager' then char_value end) SAPProjectManager
			, MAX(case char_name when 'SAP Project Applicant' then char_value end) SAPProjectApplicant
			, MAX(case char_name when 'SAP Project Start Date' then date_value end) SAPProjectStartDate
			, MAX(case char_name when 'SAP Project End Date' then date_value end) SAPProjectEndDate
			, MAX(case char_name when 'SAP Project System Status Merged' then char_value end) SAPProjectSystemStatusMerged
			, MAX(case char_name when 'SAP Project User Status Merged' then char_value end) SAPProjectUserStatusMerged
			, MAX(case char_name when 'SAP Project Profit Center' then char_value end) SAPProjectProfitCenter
			, MAX(case char_name when 'SAP Project Profit Center Department' then char_value end) SAPProjectProfitCenterDepartment
			, MAX(case char_name when 'SAP Project Plant' then char_value end) SAPProjectPlant
			, MAX(case char_name when 'SAP Object Changed On' then date_value end) SAPObjectChangedOn
		from (
			select 
			  cd.object_id 
			 ,c.char_name
			 ,cd.char_value
			 ,cd.date_value	-- for dates
			 ,cd.number_value -- for numberic
			from char_data cd (nolock)
			inner join characteristics c (nolock) on cd.char_id = c.char_id
			where c.object_type = 9
			) raw_attribs
		group by object_id
	) attribs on p.project_id = attribs.object_id

	-- Join System Statuses, concatenated
	left join (
			select ss.object_id, ss.WBSSystemStatuses
			from (
				select distinct ss2.object_id,
					LTRIM(RTRIM((
						select LTRIM(RTRIM(SUBSTRING(ss1.char_value,1, CHARINDEX(' - ', ss1.char_value)))) + ' ' as [text()]
						from char_data_mv ss1 (nolock)
						inner join characteristics css (nolock) on ss1.char_id = css.char_id and css.char_name = 'System Status' and css.object_type = 9
						where ss1.object_id = ss2.object_id
						for XML PATH ('')
					))) WBSSystemStatuses
				from char_data_mv ss2 (nolock)
			) ss
		) wbssysstat on p.project_id = wbssysstat.object_id

	-- Join User Statuses, concatenated
	left join (
			select us.object_id, us.WBSUserStatuses
			from (
				select distinct us2.object_id,
					LTRIM(RTRIM((
						select LTRIM(RTRIM(SUBSTRING(us1.char_value,1, CHARINDEX(' - ', us1.char_value)))) + ' ' as [text()]
						from char_data_mv us1 (nolock)
						inner join characteristics cus (nolock) on us1.char_id = cus.char_id and cus.char_name = 'User Status' and cus.object_type = 9
						where us1.object_id = us2.object_id
						for XML PATH ('')
					))) WBSUserStatuses
				from char_data_mv us2 (nolock)
			) us
		) wbsuserstat on p.project_id = wbsuserstat.object_id

	-- Join System Statuses, concatenated
	left join (
			select ss.object_id, ss.SAPSystemStatuses
			from (
				select distinct ss2.object_id,
					LTRIM(RTRIM((
						select LTRIM(RTRIM(SUBSTRING(ss1.char_value,1, CHARINDEX(' - ', ss1.char_value)))) + ' ' as [text()]
						from char_data_mv ss1 (nolock)
						inner join characteristics css (nolock) on ss1.char_id = css.char_id and css.char_name = 'System Status' and css.object_type = 9
						where ss1.object_id = ss2.object_id
						for XML PATH ('')
					))) SAPSystemStatuses
				from char_data_mv ss2 (nolock)
			) ss
		) sapsysstat on p.project_id = sapsysstat.object_id

	-- Join User Statuses, concatenated
	left join (
			select us.object_id, us.SAPUserStatuses
			from (
				select distinct us2.object_id,
					LTRIM(RTRIM((
						select LTRIM(RTRIM(SUBSTRING(us1.char_value,1, CHARINDEX(' - ', us1.char_value)))) + ' ' as [text()]
						from char_data_mv us1 (nolock)
						inner join characteristics cus (nolock) on us1.char_id = cus.char_id and cus.char_name = 'User Status' and cus.object_type = 9
						where us1.object_id = us2.object_id
						for XML PATH ('')
					))) SAPUserStatuses
				from char_data_mv us2 (nolock)
			) us
		) sapuserstat on p.project_id = sapuserstat.object_id
GO