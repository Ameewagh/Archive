IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SUN_PROJ_Validation_Comparison]'))
DROP VIEW [dbo].[SUN_PROJ_Validation_Comparison]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[SUN_PROJ_Validation_Comparison]
AS 
-- SQL to compare SAP and eB Project data.
-- Requires table SUN_PROJ_Validation_SAP_Stage and view SUN_PROJ_Validation_eB

select 

	-- identify if Project is found in one system and not the other
	case when (s.ProjDefStruc is not null) and (e.ProjectCode is null) then 1 else 0 end as missing
	, case when (s.ProjDefStruc is null) and (e.ProjectCode is not null) then 1 else 0 end as extra

	-- key columns - do we compare these?
	, case when s.ProjDefStruc <> ISNULL(e.ProjectCode,'') then 1 else 0 end as wrong_projectcode
	, case when s.ProjDefDesc <> ISNULL(e.Description,'') then 1 else 0 end as wrong_description
	
	-- identify differences in attribute values
	, dbo.sun_compare_compounds(s.WBSElementStruc, s.WBSElementDesc, e.WBSElement) as wrong_wbselement
	, dbo.sun_compare_compounds(s.WBSProjManager, s.WBSProjManagerName, e.WBSManager) as wrong_wbsmanager
	, dbo.sun_compare_compounds(s.WBSApplicant, s.WBSApplicantName, e.WBSApplicant) as wrong_wbsapplicant
	, case when Cast(ISNULL(s.WBSBasicStart, '1900')as datetime) <> ISNULL(e.WBSPlannedStartDate,'1900') then 1 else 0 end as wrong_wbsplannedstartdate
	, case when Cast(ISNULL(s.WBSBasicFinish, '1900')as datetime) <> ISNULL(e.WBSPlannedEndDate,'1900') then 1 else 0 end as wrong_wbsplannedenddate
	, case when s.WBSSystStatus <> ISNULL(e.WBSSystemStatusMerged,'') then 1 else 0 end as wrong_wbssystemstatusmerged
	, case when s.WBSUserStatus <> ISNULL(e.WBSUserStatusMerged,'') then 1 else 0 end as wrong_wbsuserstatusmerged
	, dbo.sun_compare_compounds(s.WBSProfitCent, s.WBSProfCenterDesc, e.WBSProfitCenter) as wrong_wbsprofitcenter
	, case when s.WBSProfCenterDept <> ISNULL(e.WBSProfitCenterDepartment,'') then 1 else 0 end as wrong_wbsprofitcenterdepartment
	, dbo.sun_compare_compounds(s.WBSCostCenter, s.WBSCostCenterDesc, e.WBSRequestingCostCenter) as wrong_wbsrequestingcostcenter
	, case when s.WBSCostCenterDept <> ISNULL(e.WBSCostCenterDepartment,'') then 1 else 0 end as wrong_wbscostcenterdepartment
	, case when s.ProjectType <> ISNULL(e.WBSProjectType,'') then 1 else 0 end as wrong_wbsprojecttype
	, case when s.ProjHierLev <> ISNULL(e.WBSLevelinProjectHierarchy, 0 /* eb numeric */) then 1 else 0 end as wrong_wbslevelinprojecthierarchy
	, case when s.WBSPlant <> ISNULL(e.WBSPlant,'') then 1 else 0 end as wrong_wbsplant
	, case when s.ProjDefinition <> ISNULL(e.SAPProjectIdentifier,'') then 1 else 0 end as wrong_sapprojectidentifier
	, dbo.sun_compare_compounds(s.ProjDefStruc, s.ProjDefDesc, e.SAPProjectName) as wrong_sapprojectname
	, dbo.sun_compare_compounds(s.PROJProjManager, s.PROJProjMgrName, e.SAPProjectManager) as wrong_sapprojectmanager
	, dbo.sun_compare_compounds(s.PROJWBSApplicant, s.PROJWBSApplicantName, e.SAPProjectApplicant) as wrong_sapprojectapplicant
	, case when Cast(ISNULL(s.PROJStartDate, '1900')as datetime) <> ISNULL(e.SAPProjectStartDate,'1900') then 1 else 0 end as wrong_sapprojectstartdate
	, case when Cast(ISNULL(s.PROJFinishDate, '1900')as datetime) <> ISNULL(e.SAPProjectEndDate,'1900') then 1 else 0 end as wrong_sapprojectenddate
	, case when s.PROJSystStatus <> ISNULL(e.SAPProjectSystemStatusMerged,'') then 1 else 0 end as wrong_sapprojectsystemstatusmerged
	, case when s.PROJUserStatus <> ISNULL(e.SAPProjectUserStatusMerged,'') then 1 else 0 end as wrong_sapprojectuserstatusmerged
	, dbo.sun_compare_compounds(s.PROJProfitCenter, s.PROJProfCtrDesc, e.SAPProjectProfitCenter) as wrong_sapprojectprofitcenter
	, case when s.PROJProfCtrDept <> ISNULL(e.SAPProjectProfitCenterDepartment,'') then 1 else 0 end as wrong_sapprojectprofitcenterdepartment
	, case when s.PROJPlant <> ISNULL(e.SAPProjectPlant,'') then 1 else 0 end as wrong_sapprojectplant
	
	, case when dbo.split_sort_merge_string(s.WBSSystStatus) <> dbo.split_sort_merge_string(ISNULL(e.WBSSystemStatuses,'')) then 1 else 0 end as wrong_wbssystemstatus
	, case when dbo.split_sort_merge_string(s.WBSUserStatus) <> dbo.split_sort_merge_string(ISNULL(e.WBSUserStatuses,'')) then 1 else 0 end as wrong_wbsuserstatus
	, case when dbo.split_sort_merge_string(s.PROJSystStatus) <> dbo.split_sort_merge_string(ISNULL(e.SAPSystemStatuses,'')) then 1 else 0 end as wrong_sapsystemstatus
	, case when dbo.split_sort_merge_string(s.PROJUserStatus) <> dbo.split_sort_merge_string(ISNULL(e.SAPUserStatuses,'')) then 1 else 0 end as wrong_sapuserstatus
	
	, case when cast(ISNULL(s.LastChgedDte, '1900')as datetime) <> ISNULL(e.SAPObjectChangedOn,'1900') then 1 else 0 end as wrong_changedon


	-- SAP staging table columns
	, s.LoadDateTime as SAP_LoadDateTime
	, s.WBSElement as SAP_WBSElement
	, s.WBSElementStruc as SAP_WBSElementStruc
	, s.WBSElementDesc as SAP_WBSElementDesc
	, s.WBSProjManager as SAP_WBSProjManager
	, s.WBSProjManagerName as SAP_WBSProjManagerName
	, s.WBSApplicant as SAP_WBSApplicant
	, s.WBSApplicantName as SAP_WBSApplicantName
	, s.WBSBasicStart as SAP_WBSBasicStart
	, s.WBSBasicFinish as SAP_WBSBasicFinish
	, s.WBSSystStatus as SAP_WBSSystStatus
	, s.WBSUserStatus as SAP_WBSUserStatus
	, s.WBSProfitCent as SAP_WBSProfitCent
	, s.WBSProfCenterDesc as SAP_WBSProfCenterDesc
	, s.WBSProfCenterDept as SAP_WBSProfCenterDept
	, s.WBSCostCenter as SAP_WBSCostCenter
	, s.WBSCostCenterDesc as SAP_WBSCostCenterDesc
	, s.WBSCostCenterDept as SAP_WBSCostCenterDept
	, s.ProjectType as SAP_ProjectType
	, s.ProjHierLev as SAP_ProjHierLev
	, s.WBSPlant as SAP_WBSPlant
	, s.ProjDefinition as SAP_ProjDefinition
	, s.ProjDefStruc as SAP_ProjDefStruc
	, s.ProjDefDesc as SAP_ProjDefDesc
	, s.PROJProjManager as SAP_PROJProjManager
	, s.PROJProjMgrName as SAP_PROJProjMgrName
	, s.PROJWBSApplicant as SAP_PROJWBSApplicant
	, s.PROJWBSApplicantName as SAP_PROJWBSApplicantName
	, s.PROJStartDate as SAP_PROJStartDate
	, s.PROJFinishDate as SAP_PROJFinishDate
	, s.PROJSystStatus as SAP_PROJSystStatus
	, s.PROJUserStatus as SAP_PROJUserStatus
	, s.PROJProfitCenter as SAP_PROJProfitCenter
	, s.PROJProfCtrDesc as SAP_PROJProfCtrDesc
	, s.PROJProfCtrDept as SAP_PROJProfCtrDept
	, s.PROJPlant as SAP_PROJPlant
	, s.LastChgedDte as SAP_LastChgedDte
	-- eB view columns
	, e.project_id as EB_project_id
	, e.ProjectCode as EB_ProjectCode
	, e.Description as EB_Description
	, e.WBSElement as EB_WBSElement
	, e.WBSManager as EB_WBSManager
	, e.WBSApplicant as EB_WBSApplicant
	, e.WBSPlannedStartDate as EB_WBSPlannedStartDate
	, e.WBSPlannedEndDate as EB_WBSPlannedEndDate
	, e.WBSSystemStatusMerged as EB_WBSSystemStatusMerged
	, e.WBSUserStatusMerged as EB_WBSUserStatusMerged
	, e.WBSProfitCenter as EB_WBSProfitCenter
	, e.WBSProfitCenterDepartment as EB_WBSProfitCenterDepartment
	, e.WBSRequestingCostCenter as EB_WBSRequestingCostCenter
	, e.WBSCostCenterDepartment as EB_WBSCostCenterDepartment
	, e.WBSProjectType as EB_WBSProjectType
	, e.WBSLevelinProjectHierarchy as EB_WBSLevelinProjectHierarchy
	, e.WBSPlant as EB_WBSPlant
	, e.SAPProjectIdentifier as EB_SAPProjectIdentifier
	, e.SAPProjectName as EB_SAPProjectName
	, e.SAPProjectManager as EB_SAPProjectManager
	, e.SAPProjectApplicant as EB_SAPProjectApplicant
	, e.SAPProjectStartDate as EB_SAPProjectStartDate
	, e.SAPProjectEndDate as EB_SAPProjectEndDate
	, e.SAPProjectSystemStatusMerged as EB_SAPProjectSystemStatusMerged
	, e.SAPProjectUserStatusMerged as EB_SAPProjectUserStatusMerged
	, e.SAPProjectProfitCenter as EB_SAPProjectProfitCenter
	, e.SAPProjectProfitCenterDepartment as EB_SAPProjectProfitCenterDepartment
	, e.SAPProjectPlant as EB_SAPProjectPlant

	, e.WBSSystemStatuses as EB_WBSSystemStatuses
	, e.WBSUserStatuses as EB_WBSUserStatuses
	, e.SAPSystemStatuses as EB_SAPSystemStatuses
	, e.SAPUserStatuses as EB_SAPUserStatuses

	, e.SAPObjectChangedOn as EB_SAPObjectChangedOn
	
from SUN_PROJ_Validation_SAP_Stage s
full join SUN_PROJ_Validation_eB e on ((s.WBSElementStruc + ' - ' + s.WBSElementDesc) = e.WBSElement)


GO
