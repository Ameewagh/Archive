--
-- SAP FLOC Validation - Deployment Script v1.sql
--

/****** Object:  Table [dbo].[SUN_PROJ_Validation_SAP_Stage]    Script Date: 11/17/2015 12:25:53 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SUN_PROJ_Validation_SAP_Stage]') AND type in (N'U'))
DROP TABLE [dbo].[SUN_PROJ_Validation_SAP_Stage]
GO

/****** Object:  Table [dbo].[SUN_PROJ_Validation_SAP_Stage]    Script Date: 11/17/2015 12:25:53 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SUN_PROJ_Validation_SAP_Stage](
	[LoadDateTime] [datetime] NULL,
	[rownum] [int] NULL,
	[WBSElement] [nvarchar](255) NULL,
	[WBSElementStruc] [nvarchar](255) NULL,
	[WBSElementDesc] [nvarchar](255) NULL,
	[WBSProjManager] [nvarchar](255) NULL,
	[WBSProjManagerName] [nvarchar](255) NULL,
	[WBSApplicant] [nvarchar](255) NULL,
	[WBSApplicantName] [nvarchar](255) NULL,
	[WBSBasicStart] [nvarchar](255) NULL,
	[WBSBasicFinish] [nvarchar](255) NULL,
	[WBSSystStatus] [nvarchar](255) NULL,
	[WBSUserStatus] [nvarchar](255) NULL,
	[WBSProfitCent] [nvarchar](255) NULL,
	[WBSProfCenterDesc] [nvarchar](255) NULL,
	[WBSProfCenterDept] [nvarchar](255) NULL,
	[WBSCostCenter] [nvarchar](255) NULL,
	[WBSCostCenterDesc] [nvarchar](255) NULL,
	[WBSCostCenterDept] [nvarchar](255) NULL,
	[ProjectType] [nvarchar](255) NULL,
	[ProjHierLev] [nvarchar](255) NULL,
	[WBSPlant] [nvarchar](255) NULL,
	[ProjDefinition] [nvarchar](255) NULL,
	[ProjDefStruc] [nvarchar](255) NULL,
	[ProjDefDesc] [nvarchar](255) NULL,
	[PROJProjManager] [nvarchar](255) NULL,
	[PROJProjMgrName] [nvarchar](255) NULL,
	[PROJWBSApplicant] [nvarchar](255) NULL,
	[PROJWBSApplicantName] [nvarchar](255) NULL,
	[PROJStartDate] [nvarchar](255) NULL,
	[PROJFinishDate] [nvarchar](255) NULL,
	[PROJSystStatus] [nvarchar](255) NULL,
	[PROJUserStatus] [nvarchar](255) NULL,
	[PROJProfitCenter] [nvarchar](255) NULL,
	[PROJProfCtrDesc] [nvarchar](255) NULL,
	[PROJProfCtrDept] [nvarchar](255) NULL,
	[PROJPlant] [nvarchar](255) NULL,
	[LastChgedDte] [nvarchar](255) NULL,
	[ECMRel] [nvarchar](255) NULL
) ON [PRIMARY]

GO


/****** Object:  View [dbo].[SUN_PROJ_Validation_eB]    Script Date: 11/17/2015 12:26:08 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SUN_PROJ_Validation_eB]'))
DROP VIEW [dbo].[SUN_PROJ_Validation_eB]
GO

/****** Object:  View [dbo].[SUN_PROJ_Validation_eB]    Script Date: 11/17/2015 12:26:08 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [dbo].[SUN_PROJ_Validation_eB]
AS 

select 
-- Keys
  p.project_id

-- Project attributes
, p.project_code as ProjectCode
, p.description as Description
, attribs.WBSTechnicalIdentifier
, attribs.WBSElement
, attribs.WBSManager
, attribs.WBSApplicant
, attribs.WBSPlannedStartDate
, attribs.WBSPlannedEndDate
, attribs.WBSSystemStatusMerged
, attribs.WBSUserStatusMerged
, attribs.WBSProfitCenter
, attribs.WBSProfitCenterDepartment
, attribs.WBSRequestingCostCenter
, attribs.WBSCostCenterDepartment
, LTRIM(RTRIM(SUBSTRING(attribs.WBSProjectType, 1, CHARINDEX(' - ', attribs.WBSProjectType)))) as WBSProjectType
, attribs.WBSLevelinProjectHierarchy
, LTRIM(RTRIM(SUBSTRING(attribs.WBSPlant, 1, CHARINDEX(' - ', attribs.WBSPlant)))) as WBSPlant
, attribs.SAPProjectIdentifier
, attribs.SAPProjectName
, attribs.SAPProjectManager
, attribs.SAPProjectApplicant
, attribs.SAPProjectStartDate
, attribs.SAPProjectEndDate
, attribs.SAPProjectSystemStatusMerged
, attribs.SAPProjectUserStatusMerged
, attribs.SAPProjectProfitCenter
, attribs.SAPProjectProfitCenterDepartment
, LTRIM(RTRIM(SUBSTRING(attribs.SAPProjectPlant, 1, CHARINDEX(' - ', attribs.SAPProjectPlant)))) as SAPProjectPlant
, wbssysstat.WBSSystemStatuses
, wbsuserstat.WBSUserStatuses
, sapsysstat.SAPSystemStatuses
, sapuserstat.SAPUserStatuses
, attribs.SAPObjectChangedOn

from projects p (nolock)

-- Join to a super fast PIVOT of all (single-value) attributes in the char_data table.
left join (
		select 
			  object_id
			, MAX(case char_name when 'WBS Technical Identifier' then char_value end) WBSTechnicalIdentifier
			, MAX(case char_name when 'WBS Element' then char_value end) WBSElement
			, MAX(case char_name when 'WBS Manager' then char_value end) WBSManager
			, MAX(case char_name when 'WBS Applicant' then char_value end) WBSApplicant
			, MAX(case char_name when 'WBS Planned Start Date' then date_value end) WBSPlannedStartDate
			, MAX(case char_name when 'WBS Planned End Date' then date_value end) WBSPlannedEndDate
			, MAX(case char_name when 'WBS System Status Merged' then char_value end) WBSSystemStatusMerged
			, MAX(case char_name when 'WBS User Status Merged' then char_value end) WBSUserStatusMerged
			, MAX(case char_name when 'WBS Profit Center' then char_value end) WBSProfitCenter
			, MAX(case char_name when 'WBS Profit Center Department' then char_value end) WBSProfitCenterDepartment
			, MAX(case char_name when 'WBS Requesting Cost Center' then char_value end) WBSRequestingCostCenter
			, MAX(case char_name when 'WBS Cost Center Department' then char_value end) WBSCostCenterDepartment
			, MAX(case char_name when 'WBS Project Type' then char_value end) WBSProjectType
			, MAX(case char_name when 'WBS Level in Project Hierarchy' then number_value end) WBSLevelinProjectHierarchy
			, MAX(case char_name when 'WBS Plant' then char_value end) WBSPlant
			, MAX(case char_name when 'SAP Project Identifier' then char_value end) SAPProjectIdentifier
			, MAX(case char_name when 'SAP Project Name' then char_value end) SAPProjectName
			, MAX(case char_name when 'SAP Project Manager' then char_value end) SAPProjectManager
			, MAX(case char_name when 'SAP Project Applicant' then char_value end) SAPProjectApplicant
			, MAX(case char_name when 'SAP Project Start Date' then date_value end) SAPProjectStartDate
			, MAX(case char_name when 'SAP Project End Date' then date_value end) SAPProjectEndDate
			, MAX(case char_name when 'SAP Project System Status Merged' then char_value end) SAPProjectSystemStatusMerged
			, MAX(case char_name when 'SAP Project User Status Merged' then char_value end) SAPProjectUserStatusMerged
			, MAX(case char_name when 'SAP Project Profit Center' then char_value end) SAPProjectProfitCenter
			, MAX(case char_name when 'SAP Project Profit Center Department' then char_value end) SAPProjectProfitCenterDepartment
			, MAX(case char_name when 'SAP Project Plant' then char_value end) SAPProjectPlant
			, MAX(case char_name when 'SAP Object Changed On' then date_value end) SAPObjectChangedOn
		from (
			select 
			  cd.object_id 
			 ,c.char_name
			 ,cd.char_value
			 ,cd.date_value	-- for dates
			 ,cd.number_value -- for numberic
			from char_data cd (nolock)
			inner join characteristics c (nolock) on cd.char_id = c.char_id
			where c.object_type = 9
			) raw_attribs
		group by object_id
	) attribs on p.project_id = attribs.object_id

	-- Join System Statuses, concatenated
	left join (
			select ss.object_id, ss.WBSSystemStatuses
			from (
				select distinct ss2.object_id,
					LTRIM(RTRIM((
						select LTRIM(RTRIM(SUBSTRING(ss1.char_value,1, CHARINDEX(' - ', ss1.char_value)))) + ' ' as [text()]
						from char_data_mv ss1 (nolock)
						inner join characteristics css (nolock) on ss1.char_id = css.char_id and css.char_name = 'WBS System Status' and css.object_type = 9
						where ss1.object_id = ss2.object_id
						for XML PATH ('')
					))) WBSSystemStatuses
				from char_data_mv ss2 (nolock)
			) ss
		) wbssysstat on p.project_id = wbssysstat.object_id

	-- Join User Statuses, concatenated
	left join (
			select us.object_id, us.WBSUserStatuses
			from (
				select distinct us2.object_id,
					LTRIM(RTRIM((
						select LTRIM(RTRIM(SUBSTRING(us1.char_value,1, CHARINDEX(' - ', us1.char_value)))) + ' ' as [text()]
						from char_data_mv us1 (nolock)
						inner join characteristics cus (nolock) on us1.char_id = cus.char_id and cus.char_name = 'WBS User Status' and cus.object_type = 9
						where us1.object_id = us2.object_id
						for XML PATH ('')
					))) WBSUserStatuses
				from char_data_mv us2 (nolock)
			) us
		) wbsuserstat on p.project_id = wbsuserstat.object_id

	-- Join System Statuses, concatenated
	left join (
			select ss.object_id, ss.SAPSystemStatuses
			from (
				select distinct ss2.object_id,
					LTRIM(RTRIM((
						select LTRIM(RTRIM(SUBSTRING(ss1.char_value,1, CHARINDEX(' - ', ss1.char_value)))) + ' ' as [text()]
						from char_data_mv ss1 (nolock)
						inner join characteristics css (nolock) on ss1.char_id = css.char_id and css.char_name = 'SAP Project System Status' and css.object_type = 9
						where ss1.object_id = ss2.object_id
						for XML PATH ('')
					))) SAPSystemStatuses
				from char_data_mv ss2 (nolock)
			) ss
		) sapsysstat on p.project_id = sapsysstat.object_id

	-- Join User Statuses, concatenated
	left join (
			select us.object_id, us.SAPUserStatuses
			from (
				select distinct us2.object_id,
					LTRIM(RTRIM((
						select LTRIM(RTRIM(SUBSTRING(us1.char_value,1, CHARINDEX(' - ', us1.char_value)))) + ' ' as [text()]
						from char_data_mv us1 (nolock)
						inner join characteristics cus (nolock) on us1.char_id = cus.char_id and cus.char_name = 'SAP Project User Status' and cus.object_type = 9
						where us1.object_id = us2.object_id
						for XML PATH ('')
					))) SAPUserStatuses
				from char_data_mv us2 (nolock)
			) us
		) sapuserstat on p.project_id = sapuserstat.object_id

	where WBSTechnicalIdentifier is not null
	


GO


/****** Object:  View [dbo].[SUN_PROJ_Validation_Comparison]    Script Date: 11/17/2015 12:26:17 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SUN_PROJ_Validation_Comparison]'))
DROP VIEW [dbo].[SUN_PROJ_Validation_Comparison]
GO

/****** Object:  View [dbo].[SUN_PROJ_Validation_Comparison]    Script Date: 11/17/2015 12:26:17 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE VIEW [dbo].[SUN_PROJ_Validation_Comparison]
AS 
-- SQL to compare SAP and eB Project data.
-- Requires table SUN_PROJ_Validation_SAP_Stage and view SUN_PROJ_Validation_eB

select 

	-- identify if Project is found in one system and not the other
	-- IGNORE MISSING IN EB. This is not a data integrity issue, as the business may not have selected this WBS on an eB project yet.
	-- case when (s.ProjDefStruc is not null) and (e.ProjectCode is null) then 1 else 0 end as missing,
	case when (s.ProjDefStruc is null) and (e.ProjectCode is not null) then 1 else 0 end as extra

	-- identify differences in attribute values
	, dbo.sun_compare_compounds(s.WBSElementStruc, s.WBSElementDesc, e.WBSElement) as wrong_wbselement
	, dbo.sun_compare_compounds(s.WBSProjManager, s.WBSProjManagerName, e.WBSManager) as wrong_wbsmanager
	, dbo.sun_compare_compounds(s.WBSApplicant, s.WBSApplicantName, e.WBSApplicant) as wrong_wbsapplicant
	, case when Cast(ISNULL(s.WBSBasicStart, '1900')as datetime) <> ISNULL(e.WBSPlannedStartDate,'1900') then 1 else 0 end as wrong_wbsplannedstartdate
	, case when Cast(ISNULL(s.WBSBasicFinish, '1900')as datetime) <> ISNULL(e.WBSPlannedEndDate,'1900') then 1 else 0 end as wrong_wbsplannedenddate
	, case when s.WBSSystStatus <> ISNULL(e.WBSSystemStatusMerged,'') then 1 else 0 end as wrong_wbssystemstatusmerged
	, case when s.WBSUserStatus <> ISNULL(e.WBSUserStatusMerged,'') then 1 else 0 end as wrong_wbsuserstatusmerged
	, dbo.sun_compare_compounds(s.WBSProfitCent, s.WBSProfCenterDesc, e.WBSProfitCenter) as wrong_wbsprofitcenter
	, case when s.WBSProfCenterDept <> ISNULL(e.WBSProfitCenterDepartment,'') then 1 else 0 end as wrong_wbsprofitcenterdepartment
	, dbo.sun_compare_compounds(s.WBSCostCenter, s.WBSCostCenterDesc, e.WBSRequestingCostCenter) as wrong_wbsrequestingcostcenter
	, case when s.WBSCostCenterDept <> ISNULL(e.WBSCostCenterDepartment,'') then 1 else 0 end as wrong_wbscostcenterdepartment
	, case when s.ProjectType <> ISNULL(e.WBSProjectType,'') then 1 else 0 end as wrong_wbsprojecttype
	, case when s.ProjHierLev <> ISNULL(e.WBSLevelinProjectHierarchy, 0 /* eb numeric */) then 1 else 0 end as wrong_wbslevelinprojecthierarchy
	, case when s.WBSPlant <> ISNULL(e.WBSPlant,'') then 1 else 0 end as wrong_wbsplant
	, case when s.ProjDefinition <> ISNULL(e.SAPProjectIdentifier,'') then 1 else 0 end as wrong_sapprojectidentifier
	, dbo.sun_compare_compounds(s.ProjDefStruc, s.ProjDefDesc, e.SAPProjectName) as wrong_sapprojectname
	, dbo.sun_compare_compounds(s.PROJProjManager, s.PROJProjMgrName, e.SAPProjectManager) as wrong_sapprojectmanager
	, dbo.sun_compare_compounds(s.PROJWBSApplicant, s.PROJWBSApplicantName, e.SAPProjectApplicant) as wrong_sapprojectapplicant
	, case when Cast(ISNULL(s.PROJStartDate, '1900')as datetime) <> ISNULL(e.SAPProjectStartDate,'1900') then 1 else 0 end as wrong_sapprojectstartdate
	, case when Cast(ISNULL(s.PROJFinishDate, '1900')as datetime) <> ISNULL(e.SAPProjectEndDate,'1900') then 1 else 0 end as wrong_sapprojectenddate
	, case when s.PROJSystStatus <> ISNULL(e.SAPProjectSystemStatusMerged,'') then 1 else 0 end as wrong_sapprojectsystemstatusmerged
	, case when s.PROJUserStatus <> ISNULL(e.SAPProjectUserStatusMerged,'') then 1 else 0 end as wrong_sapprojectuserstatusmerged
	, dbo.sun_compare_compounds(s.PROJProfitCenter, s.PROJProfCtrDesc, e.SAPProjectProfitCenter) as wrong_sapprojectprofitcenter
	, case when s.PROJProfCtrDept <> ISNULL(e.SAPProjectProfitCenterDepartment,'') then 1 else 0 end as wrong_sapprojectprofitcenterdepartment
	, case when s.PROJPlant <> ISNULL(e.SAPProjectPlant,'') then 1 else 0 end as wrong_sapprojectplant
	
	, case when dbo.SUN_split_sort_merge_string(s.WBSSystStatus) <> dbo.SUN_split_sort_merge_string(ISNULL(e.WBSSystemStatuses,'')) then 1 else 0 end as wrong_wbssystemstatus
	, case when dbo.SUN_split_sort_merge_string(s.WBSUserStatus) <> dbo.SUN_split_sort_merge_string(ISNULL(e.WBSUserStatuses,'')) then 1 else 0 end as wrong_wbsuserstatus
	, case when dbo.SUN_split_sort_merge_string(s.PROJSystStatus) <> dbo.SUN_split_sort_merge_string(ISNULL(e.SAPSystemStatuses,'')) then 1 else 0 end as wrong_sapsystemstatus
	, case when dbo.SUN_split_sort_merge_string(s.PROJUserStatus) <> dbo.SUN_split_sort_merge_string(ISNULL(e.SAPUserStatuses,'')) then 1 else 0 end as wrong_sapuserstatus
	
	, case when cast(ISNULL(s.LastChgedDte, '1900')as datetime) <> ISNULL(e.SAPObjectChangedOn,'1900') then 1 else 0 end as wrong_changedon


	-- SAP staging table columns
	, s.LoadDateTime as SAP_LoadDateTime
	, s.WBSElement as SAP_WBSElement
	, s.WBSElementStruc as SAP_WBSElementStruc
	, s.WBSElementDesc as SAP_WBSElementDesc
	, s.WBSProjManager as SAP_WBSProjManager
	, s.WBSProjManagerName as SAP_WBSProjManagerName
	, s.WBSApplicant as SAP_WBSApplicant
	, s.WBSApplicantName as SAP_WBSApplicantName
	, s.WBSBasicStart as SAP_WBSBasicStart
	, s.WBSBasicFinish as SAP_WBSBasicFinish
	, s.WBSSystStatus as SAP_WBSSystStatus
	, s.WBSUserStatus as SAP_WBSUserStatus
	, s.WBSProfitCent as SAP_WBSProfitCent
	, s.WBSProfCenterDesc as SAP_WBSProfCenterDesc
	, s.WBSProfCenterDept as SAP_WBSProfCenterDept
	, s.WBSCostCenter as SAP_WBSCostCenter
	, s.WBSCostCenterDesc as SAP_WBSCostCenterDesc
	, s.WBSCostCenterDept as SAP_WBSCostCenterDept
	, s.ProjectType as SAP_ProjectType
	, s.ProjHierLev as SAP_ProjHierLev
	, s.WBSPlant as SAP_WBSPlant
	, s.ProjDefinition as SAP_ProjDefinition
	, s.ProjDefStruc as SAP_ProjDefStruc
	, s.ProjDefDesc as SAP_ProjDefDesc
	, s.PROJProjManager as SAP_PROJProjManager
	, s.PROJProjMgrName as SAP_PROJProjMgrName
	, s.PROJWBSApplicant as SAP_PROJWBSApplicant
	, s.PROJWBSApplicantName as SAP_PROJWBSApplicantName
	, s.PROJStartDate as SAP_PROJStartDate
	, s.PROJFinishDate as SAP_PROJFinishDate
	, s.PROJSystStatus as SAP_PROJSystStatus
	, s.PROJUserStatus as SAP_PROJUserStatus
	, s.PROJProfitCenter as SAP_PROJProfitCenter
	, s.PROJProfCtrDesc as SAP_PROJProfCtrDesc
	, s.PROJProfCtrDept as SAP_PROJProfCtrDept
	, s.PROJPlant as SAP_PROJPlant
	, s.LastChgedDte as SAP_LastChgedDte
	-- eB view columns
	, e.project_id as EB_project_id
	, e.ProjectCode as EB_ProjectCode
	, e.Description as EB_Description
	, e.WBSElement as EB_WBSElement
	, e.WBSManager as EB_WBSManager
	, e.WBSApplicant as EB_WBSApplicant
	, e.WBSPlannedStartDate as EB_WBSPlannedStartDate
	, e.WBSPlannedEndDate as EB_WBSPlannedEndDate
	, e.WBSSystemStatusMerged as EB_WBSSystemStatusMerged
	, e.WBSUserStatusMerged as EB_WBSUserStatusMerged
	, e.WBSProfitCenter as EB_WBSProfitCenter
	, e.WBSProfitCenterDepartment as EB_WBSProfitCenterDepartment
	, e.WBSRequestingCostCenter as EB_WBSRequestingCostCenter
	, e.WBSCostCenterDepartment as EB_WBSCostCenterDepartment
	, e.WBSProjectType as EB_WBSProjectType
	, e.WBSLevelinProjectHierarchy as EB_WBSLevelinProjectHierarchy
	, e.WBSPlant as EB_WBSPlant
	, e.SAPProjectIdentifier as EB_SAPProjectIdentifier
	, e.SAPProjectName as EB_SAPProjectName
	, e.SAPProjectManager as EB_SAPProjectManager
	, e.SAPProjectApplicant as EB_SAPProjectApplicant
	, e.SAPProjectStartDate as EB_SAPProjectStartDate
	, e.SAPProjectEndDate as EB_SAPProjectEndDate
	, e.SAPProjectSystemStatusMerged as EB_SAPProjectSystemStatusMerged
	, e.SAPProjectUserStatusMerged as EB_SAPProjectUserStatusMerged
	, e.SAPProjectProfitCenter as EB_SAPProjectProfitCenter
	, e.SAPProjectProfitCenterDepartment as EB_SAPProjectProfitCenterDepartment
	, e.SAPProjectPlant as EB_SAPProjectPlant

	, e.WBSSystemStatuses as EB_WBSSystemStatuses
	, e.WBSUserStatuses as EB_WBSUserStatuses
	, e.SAPSystemStatuses as EB_SAPSystemStatuses
	, e.SAPUserStatuses as EB_SAPUserStatuses

	, e.SAPObjectChangedOn as EB_SAPObjectChangedOn
	
from SUN_PROJ_Validation_SAP_Stage s
-- Right join to get ALL eB projects, but ony the matching rows in the SAP Stage table.
--Unused entries in the SAP stage table can be ignored as not used by the busienss yet.
right join SUN_PROJ_Validation_eB e on s.WBSElement = e.WBSTechnicalIdentifier



GO


/****** Object:  View [dbo].[SUN_PROJ_Validation_Differences]    Script Date: 11/17/2015 12:26:28 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SUN_PROJ_Validation_Differences]'))
DROP VIEW [dbo].[SUN_PROJ_Validation_Differences]
GO

/****** Object:  View [dbo].[SUN_PROJ_Validation_Differences]    Script Date: 11/17/2015 12:26:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO






CREATE VIEW [dbo].[SUN_PROJ_Validation_Differences]
AS 

select *

from SUN_PROJ_Validation_Comparison c
where 
   c.extra = 1
or c.wrong_wbselement = 1
or c.wrong_wbsmanager = 1
or c.wrong_wbsapplicant = 1
or c.wrong_wbsplannedstartdate = 1
or c.wrong_wbsplannedenddate = 1
or c.wrong_wbssystemstatusmerged = 1
or c.wrong_wbsuserstatusmerged = 1
or c.wrong_wbsprofitcenter = 1
or c.wrong_wbsprofitcenterdepartment = 1
or c.wrong_wbsrequestingcostcenter = 1
or c.wrong_wbscostcenterdepartment = 1
or c.wrong_wbsprojecttype = 1
or c.wrong_wbslevelinprojecthierarchy = 1
or c.wrong_wbsplant = 1
or c.wrong_sapprojectidentifier = 1
or c.wrong_sapprojectname = 1
or c.wrong_sapprojectmanager = 1
or c.wrong_sapprojectapplicant = 1
or c.wrong_sapprojectstartdate = 1
or c.wrong_sapprojectenddate = 1
or c.wrong_sapprojectsystemstatusmerged = 1
or c.wrong_sapprojectuserstatusmerged = 1
or c.wrong_sapprojectprofitcenter = 1
or c.wrong_sapprojectprofitcenterdepartment = 1
or c.wrong_sapprojectplant = 1
or c.wrong_wbssystemstatus = 1
or c.wrong_wbsuserstatus = 1
or c.wrong_sapsystemstatus = 1
or c.wrong_sapuserstatus = 1
or c.wrong_changedon = 1




GO

