======================
Subversion Repository:
----------------------
http://sunsvn.network.lan/svn/ADLP/trunk/SSIS


======================
Bentley Repository:
----------------------
TBD (may be something like: $\Customers\Suncor\Firebag\DQS\...) 
Contact Michael Smith or Dave Frehulfer at Bentley
Or a local Suncor Bentley resource like Chris Davies, Craig Henderson, or Dieter Dorin.

======================
Shared eB DQS Development Server source code location:
----------------------
Server: BDQSDEVCGY001
Path:   C:\DQS2\Source - Team B
