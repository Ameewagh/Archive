--
-- SAP Equipment Validation - Deployment Script v1.sql
--

/****** Object:  Table [dbo].[SUN_EQPT_Validation_SAP_Stage]    Script Date: 11/17/2015 12:23:49 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SUN_EQPT_Validation_SAP_Stage]') AND type in (N'U'))
DROP TABLE [dbo].[SUN_EQPT_Validation_SAP_Stage]
GO

/****** Object:  Table [dbo].[SUN_EQPT_Validation_SAP_Stage]    Script Date: 11/17/2015 12:23:49 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SUN_EQPT_Validation_SAP_Stage](
	[LoadDateTime] [datetime] NULL,
	[rownum] [int] NULL,
	[Equipment] [nvarchar](255) NULL,
	[EquipDesc] [nvarchar](255) NULL,
	[EquipCat] [nvarchar](255) NULL,
	[ABCInd] [nvarchar](255) NULL,
	[ObjectType] [nvarchar](255) NULL,
	[Class] [nvarchar](255) NULL,
	[SysStatus] [nvarchar](255) NULL,
	[UserStatus] [nvarchar](255) NULL,
	[SortField] [nvarchar](255) NULL,
	[MaintPlant] [nvarchar](255) NULL,
	[FunctLoc] [nvarchar](255) NULL,
	[FunctLocLabel] [nvarchar](255) NULL,
	[Manufacturer] [nvarchar](255) NULL,
	[ModelNo] [nvarchar](255) NULL,
	[ManufPartNo] [nvarchar](255) NULL,
	[ManufSerialNo] [nvarchar](255) NULL,
	[AuthGrp] [nvarchar](255) NULL,
	[Location] [nvarchar](255) NULL,
	[LocDesc] [nvarchar](255) NULL,
	[Room] [nvarchar](255) NULL,
	[PlSectn] [nvarchar](255) NULL,
	[PersResp] [nvarchar](255) NULL,
	[WorkCtr] [nvarchar](255) NULL,
	[WorkCtrDesc] [nvarchar](255) NULL,
	[WorkCtrPlant] [nvarchar](255) NULL,
	[CostCtr] [nvarchar](255) NULL,
	[CostCtrDesc] [nvarchar](255) NULL,
	[PlannerGrp] [nvarchar](255) NULL,
	[PlannerGrpName] [nvarchar](255) NULL,
	[CatProf] [nvarchar](255) NULL,
	[RelPlnGrp] [nvarchar](255) NULL,
	[RelPlnGrpName] [nvarchar](255) NULL,
	[PlngPlant] [nvarchar](255) NULL,
	[Material] [nvarchar](255) NULL,
	[MatDesc] [nvarchar](255) NULL,
	[SerialNo] [nvarchar](255) NULL,
	[LastSerialNo] [nvarchar](255) NULL,
	[SuperordEquip] [nvarchar](255) NULL,
	[ChangedDte] [nvarchar](255) NULL
) ON [PRIMARY]

GO


/****** Object:  View [dbo].[SUN_EQPT_Validation_eB]    Script Date: 11/17/2015 12:24:09 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SUN_EQPT_Validation_eB]'))
DROP VIEW [dbo].[SUN_EQPT_Validation_eB]
GO

/****** Object:  View [dbo].[SUN_EQPT_Validation_eB]    Script Date: 11/17/2015 12:24:09 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[SUN_EQPT_Validation_eB]
AS 

select 

-- Keys
  i.item_id

-- EQPT attributes
, i.item_number as ItemNumber
, i.description as Description
, LTRIM(RTRIM(SUBSTRING(attribs.ABCIndicator,1, CHARINDEX(' - ', attribs.ABCIndicator)))) as ABCIndicator
, LTRIM(RTRIM(SUBSTRING(attribs.AuthorizationGroup,1, CHARINDEX(' - ', attribs.AuthorizationGroup)))) as AuthorizationGroup
, LTRIM(RTRIM(SUBSTRING(attribs.CatalogProfile,1, CHARINDEX(' - ', attribs.CatalogProfile)))) as CatalogProfile
, LTRIM(RTRIM(SUBSTRING(attribs.Category,1, CHARINDEX(' - ', attribs.Category)))) as Category
, attribs.ChangedOn
, LTRIM(RTRIM(SUBSTRING(attribs.Class,1, CHARINDEX(' - ', attribs.Class)))) as Class
, attribs.CostCenter
, attribs.FunctLocObjectNumber
, attribs.FunctLoc
, attribs.LastSerialNo
, attribs.Location
, attribs.MainWorkCenter
, attribs.MainWorkCenterPlant
, LTRIM(RTRIM(SUBSTRING(attribs.MaintenancePlant,1, CHARINDEX(' - ', attribs.MaintenancePlant)))) as MaintenancePlant
, attribs.Manufacturer
, attribs.ManufPartNo
, attribs.ManufSerialNo
, attribs.Material
, attribs.MaterialSerialNo
, attribs.ModelNo
, LTRIM(RTRIM(SUBSTRING(attribs.ObjType,1, CHARINDEX(' - ', attribs.ObjType)))) as ObjType
, attribs.PlannerGroup
, LTRIM(RTRIM(SUBSTRING(attribs.PlanningPlant,1, CHARINDEX(' - ', attribs.PlanningPlant)))) as PlanningPlant
, attribs.PlantSection
, attribs.RelPlnGrpName
, attribs.Room
, attribs.SortField
, attribs.SuperordEquip
, sysstat.SystemStatuses
, attribs.SystemStatusMerged
, userstat.UserStatuses
, attribs.UserStatusMerged

-- Related objects - FLOC, Tag, Equipment
, vi.vitem_code as Related_FLOC_Code
, t.code as Related_Tag_Code
, si.item_number as Related_Equipment_Number

from items i (nolock)

-- Join to a super fast PIVOT of all (single-value) attributes in the char_data table.
left join (
		select 
			  object_id
			, MAX(case char_name when 'ABC Indicator' then char_value end) ABCIndicator
			, MAX(case char_name when 'Authorization Group' then char_value end) AuthorizationGroup
			, MAX(case char_name when 'Catalog Profile' then char_value end) CatalogProfile
			, MAX(case char_name when 'Category' then char_value end) Category
			, MAX(case char_name when 'Changed On' then date_value end) ChangedOn
			, MAX(case char_name when 'Class' then char_value end) Class
			, MAX(case char_name when 'Cost Center' then char_value end) CostCenter	
			, MAX(case char_name when 'FLOC Object Number' then char_value end) FunctLocObjectNumber
			, MAX(case char_name when 'Functional Location' then char_value end) FunctLoc
			, MAX(case char_name when 'Last Serial Number' then char_value end) LastSerialNo
			, MAX(case char_name when 'Location' then char_value end) Location
			, MAX(case char_name when 'Main Work Center' then char_value end) MainWorkCenter
			, MAX(case char_name when 'Main Work Center Plant' then char_value end) MainWorkCenterPlant
			, MAX(case char_name when 'Maintenance Plant' then char_value end) MaintenancePlant
			, MAX(case char_name when 'Manufacturer' then char_value end) Manufacturer
			, MAX(case char_name when 'Manufacturer Part Number' then char_value end) ManufPartNo 
			, MAX(case char_name when 'Manufacturer Serial Number' then char_value end) ManufSerialNo 
			, MAX(case char_name when 'Material' then char_value end) Material
			, MAX(case char_name when 'Material Serial Number' then char_value end) MaterialSerialNo 
			, MAX(case char_name when 'Model Number ' then char_value end) ModelNo 
			, MAX(case char_name when 'Obj Type' then char_value end) ObjType
			, MAX(case char_name when 'Planning Plant' then char_value end) PlanningPlant
			, MAX(case char_name when 'Planner Group' then char_value end) PlannerGroup
			, MAX(case char_name when 'Plant Section' then char_value end) PlantSection
			, MAX(case char_name when 'Reliability Planner Group' then char_value end) RelPlnGrpName
			, MAX(case char_name when 'Room' then char_value end) Room
			, MAX(case char_name when 'Sort Field' then char_value end) SortField
			, MAX(case char_name when 'Superordinate Equipment' then char_value end) SuperordEquip
			, MAX(case char_name when 'System Status Merged' then char_value end) SystemStatusMerged
			, MAX(case char_name when 'User Status Merged' then char_value end) UserStatusMerged

		from (
			select 
			  cd.object_id 
			 ,c.char_name
			 ,cd.char_value
			 ,cd.date_value	-- for ChangedOn date
			from char_data cd (nolock)
			inner join characteristics c (nolock) on cd.char_id = c.char_id
			where c.object_type = 1
			) raw_attribs
		group by object_id
	) attribs on i.item_id = attribs.object_id

	-- Join System Statuses, concatenated
	left join (
			select ss.object_id, ss.SystemStatuses
			from (
				select distinct ss2.object_id,
					LTRIM(RTRIM((
						select LTRIM(RTRIM(SUBSTRING(ss1.char_value,1, CHARINDEX(' - ', ss1.char_value)))) + ' ' as [text()]
						from char_data_mv ss1 (nolock)
						inner join characteristics css (nolock) on ss1.char_id = css.char_id and css.char_name = 'System Status' and css.object_type = 1
						where ss1.object_id = ss2.object_id
						for XML PATH ('')
					))) SystemStatuses
				from char_data_mv ss2 (nolock)
			) ss
		) sysstat on i.item_id = sysstat.object_id

	-- Join User Statuses, concatenated
	left join (
			select us.object_id, us.UserStatuses
			from (
				select distinct us2.object_id,
					LTRIM(RTRIM((
						select LTRIM(RTRIM(SUBSTRING(us1.char_value,1, CHARINDEX(' - ', us1.char_value)))) + ' ' as [text()]
						from char_data_mv us1 (nolock)
						inner join characteristics cus (nolock) on us1.char_id = cus.char_id and cus.char_name = 'User Status' and cus.object_type = 1
						where us1.object_id = us2.object_id
						for XML PATH ('')
					))) UserStatuses
				from char_data_mv us2 (nolock)
			) us
		) userstat on i.item_id = userstat.object_id

	-- Join related FLOC
	
	left join relationships rf on 
		i.item_id = rf.right_object_id
		and rf.rel_type_id = 85	-- FLOC to Equipment relationships only. Can be only one Equipment per FLOC so this join should not generate additonal rows.
		and rf.template = 'N' -- not a template
		
	left join vitem_grp_members vgm on
		rf.left_object_id = vgm.gvitem_id
		and vgm.control_id = 40 -- FLOC  Get just Grouped Virtual Items in the FLOC group
		-- and vgm.template = 'N'
	
	left join vitems vi on
		vgm.vitem_id = vi.vitem_id

	-- Join related Tag
	left join relationships rt on 
		i.item_id = rt.left_object_id
		and rt.rel_type_id = 86	-- Tag to Equipment relationships only. Can be only one Equipment per Tag so this join should not generate additonal rows.
		and rt.template = 'N' -- not a template
		
	left join tags t on
		rt.right_object_id = t.tag_id
		and t.template = 'N'
	
	-- Join related (superordinate) Equipment
	left join relationships re on 
		i.item_id = re.right_object_id
		and re.rel_type_id = 87	-- Equipment to Equipment relationships only. Can be only one Equipment parent per Eqiupment so this join should not generate additonal rows.
		and re.template = 'N' -- not a template
		
	left join items si on
		re.left_object_id = si.item_id
		and si.template = 'N'

where 
	-- exclude templates, include only SAP-EQUIP class items (using 182 to avoid join to class_objects table)
	i.template = 'N' and i.class_id = 182
	


GO


/****** Object:  View [dbo].[SUN_EQPT_Validation_Comparison]    Script Date: 11/17/2015 12:24:23 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SUN_EQPT_Validation_Comparison]'))
DROP VIEW [dbo].[SUN_EQPT_Validation_Comparison]
GO

/****** Object:  View [dbo].[SUN_EQPT_Validation_Comparison]    Script Date: 11/17/2015 12:24:23 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE VIEW [dbo].[SUN_EQPT_Validation_Comparison]
AS 
-- SQL to compare SAP and eB Equipment data.
-- Requires table SUN_EQPT_Validation_SAP_Stage and view SUN_EQPT_Validation_eB

select 
	-- 1. COMPARISON FLAG COLUMNS

	-- identify if Equipment is found in one system and not the other
	case when (s.Equipment is not null) and (e.ItemNumber is null) then 1 else 0 end as missing
	, case when (s.Equipment is null) and (e.ItemNumber is not null) then 1 else 0 end as extra
	-- identify differences in attribute values
	-- handle NULLs using ISNULL() to substitute a reasonable value in place of any NULLs.
	--		using an empty stirng '' for NULL char values
	--		using a fixed date value of '1900-01-01 00:00:00.000' for NULL date values
	, case when s.Equipment <> ISNULL(e.ItemNumber,'') then 1 else 0 end as wrong_itemnumber
	, case when s.EquipDesc <> ISNULL(e.Description,'') then 1 else 0 end as wrong_description
	, case when s.ABCInd <> ISNULL(e.ABCIndicator,'') then 1 else 0 end as wrong_abcindicator
	, case when s.AuthGrp <> ISNULL(e.AuthorizationGroup,'') then 1 else 0 end as wrong_authgroup
	, case when s.CatProf <> ISNULL(e.CatalogProfile,'') then 1 else 0 end as wrong_catalogprofile
	, case when s.EquipCat <> ISNULL(e.Category,'') then 1 else 0 end as wrong_category
	, case when ISNULL(Cast(s.ChangedDte as datetime),'1900-01-01 00:00:00.000') <> ISNULL(e.ChangedOn,'1900-01-01 00:00:00.000') then 1 else 0 end as wrong_changedon
	, case when s.Class <> ISNULL(e.Class,'') then 1 else 0 end as wrong_class
	, dbo.sun_compare_compounds(s.CostCtr, s.CostCtrDesc, e.CostCenter) as wrong_costcenter
	, case when s.FunctLoc <> ISNULL(e.FunctLocObjectNumber,'') then 1 else 0 end as wrong_functlocno
	, case when LTRIM(RTRIM(s.FunctLocLabel)) <> LTRIM(RTRIM(ISNULL(e.FunctLoc,''))) then 1 else 0 end as wrong_functloc
	, case when LTRIM(RTRIM(s.LastSerialNo)) <> LTRIM(RTRIM(ISNULL(e.LastSerialNo,''))) then 1 else 0 end as wrong_lastserialno
	, dbo.sun_compare_compounds(s.Location, s.LocDesc, e.Location) as wrong_location
	, dbo.sun_compare_compounds(s.WorkCtr, s.WorkCtrDesc, e.MainWorkCenter) as wrong_workcenter
	, case when LTRIM(RTRIM(s.WorkCtrPlant)) <> LTRIM(RTRIM(ISNULL(e.MainWorkCenterPlant,''))) then 1 else 0 end as wrong_workcenterplant
	, case when s.MaintPlant <> ISNULL(e.MaintenancePlant,'') then 1 else 0 end as wrong_maintplant
	, case when LTRIM(RTRIM(s.Manufacturer)) <> LTRIM(RTRIM(ISNULL(e.Manufacturer,''))) then 1 else 0 end as wrong_manufacturer
	, case when LTRIM(RTRIM(s.ManufPartNo)) <> LTRIM(RTRIM(ISNULL(e.ManufPartNo,''))) then 1 else 0 end as wrong_manufpartno
	, case when LTRIM(RTRIM(s.ManufSerialNo)) <> LTRIM(RTRIM(ISNULL(e.ManufSerialNo,''))) then 1 else 0 end as wrong_manufserialno
	, dbo.sun_compare_compounds(s.Material, s.MatDesc, e.Material) as wrong_material
	, case when LTRIM(RTRIM(s.SerialNo)) <> LTRIM(RTRIM(ISNULL(e.MaterialSerialNo,''))) then 1 else 0 end as wrong_serialno
	, case when LTRIM(RTRIM(s.ModelNo)) <> LTRIM(RTRIM(ISNULL(e.ModelNo,''))) then 1 else 0 end as wrong_modelno
	, case when s.ObjectType <> ISNULL(e.ObjType,'') then 1 else 0 end as wrong_objecttype
	, dbo.sun_compare_compounds(s.PlannerGrp, s.PlannerGrpName, e.PlannerGroup) as wrong_plannergroup
	, case when s.PlngPlant <> ISNULL(e.PlanningPlant,'') then 1 else 0 end as wrong_planningplant
	, dbo.sun_compare_compounds(s.PlSectn, s.PersResp, e.PlantSection) as wrong_plantsection
	, dbo.sun_compare_compounds(s.RelPlnGrp, s.RelPlnGrpName, e.RelPlnGrpName) as wrong_relplangroupname
	, case when LTRIM(RTRIM(s.Room)) <> LTRIM(RTRIM(ISNULL(e.Room,''))) then 1 else 0 end as wrong_room
	, case when LTRIM(RTRIM(s.SortField)) <> LTRIM(RTRIM(ISNULL(e.SortField,''))) then 1 else 0 end as wrong_sortfield
	, case when s.SuperordEquip <> ISNULL(e.SuperordEquip,'') then 1 else 0 end as wrong_superordequip
	, case when dbo.SUN_split_sort_merge_string(s.SysStatus) <> dbo.SUN_split_sort_merge_string(ISNULL(e.SystemStatuses,'')) then 1 else 0 end as wrong_systemstatus
	, case when s.SysStatus <> ISNULL(e.SystemStatusMerged,'') then 1 else 0 end as wrong_systemstatusmerged	
	, case when dbo.SUN_split_sort_merge_string(s.UserStatus) <> dbo.SUN_split_sort_merge_string(ISNULL(e.UserStatuses,'')) then 1 else 0 end as wrong_userstatus
	, case when s.UserStatus <> ISNULL(e.UserStatusMerged,'') then 1 else 0 end as wrong_userstatusmerged
	-- Only flag an error if there is a related Tag. If Tag object was not in eB then no error.
	-- This is because the SAP sort field sometimes contains a non-Tag number, so it's normal to see many cases where no tag is found matching the sort field.
	, case when (e.Related_Tag_Code is not NULL) and (s.SortField <> ISNULL(e.Related_Tag_Code,'')) then 1 else 0 end as wrong_related_tag
	-- Flag an error if the related FLOC or Equipment was not found - these should always be there.
	-- This would indicate a data integrity error with the foreign keys between these SAP objects.
	, case when s.FunctLocLabel <> ISNULL(e.Related_FLOC_Code,'') then 1 else 0 end as wrong_related_floc
	, case when s.SuperordEquip <> ISNULL(e.Related_Equipment_Number,'') then 1 else 0 end as wrong_related_equipment
	
	-- 2. SAP STAGING TABLE COLUMNS
	
	, s.LoadDateTime as SAP_LoadDateTime
	, s.Equipment as SAP_Equipment
	, s.EquipDesc as SAP_EquipDesc
	, s.EquipCat as SAP_EquipCat
	, s.ABCInd as SAP_ABCInd
	, s.ObjectType as SAP_ObjectType
	, s.Class as SAP_Class
	, s.SysStatus as SAP_SysStatus
	, s.UserStatus as SAP_UserStatus
	, s.SortField as SAP_SortField
	, s.MaintPlant as SAP_MaintPlant
	, s.FunctLoc as SAP_FunctLoc
	, s.FunctLocLabel as SAP_FunctLocLabel
	, s.Manufacturer as SAP_Manufacturer
	, s.ModelNo as SAP_ModelNo
	, s.ManufPartNo as SAP_ManufPartNo
	, s.ManufSerialNo as SAP_ManufSerialNo
	, s.AuthGrp as SAP_AuthGrp
	, s.Location as SAP_Location
	, s.LocDesc as SAP_LocDesc
	, s.Room as SAP_Room
	, s.PlSectn as SAP_PlSectn
	, s.PersResp as SAP_PersResp
	, s.WorkCtr as SAP_WorkCtr
	, s.WorkCtrDesc as SAP_WorkCtrDesc
	, s.WorkCtrPlant as SAP_WorkCtrPlant
	, s.CostCtr as SAP_CostCtr
	, s.CostCtrDesc as SAP_CostCtrDesc
	, s.PlannerGrp as SAP_PlannerGrp
	, s.PlannerGrpName as SAP_PlannerGrpName
	, s.CatProf as SAP_CatProf
	, s.RelPlnGrp as SAP_RelPlnGrp
	, s.RelPlnGrpName as SAP_RelPlnGrpName
	, s.PlngPlant as SAP_PlngPlant
	, s.Material as SAP_Material
	, s.MatDesc as SAP_MatDesc
	, s.SerialNo as SAP_SerialNo
	, s.LastSerialNo as SAP_LastSerialNo
	, s.SuperordEquip as SAP_SuperordEquip
	, s.ChangedDte as SAP_ChangedDte
	
	-- 3. EB FLATTENED VIEW COLUMNS
	
	, e.item_id as EB_item_id
	, e.ItemNumber as EB_ItemNumber
	, e.Description as EB_Description
	, e.ABCIndicator as EB_ABCIndicator
	, e.AuthorizationGroup as EB_AuthorizationGroup
	, e.CatalogProfile as EB_CatalogProfile
	, e.Category as EB_Category
	, e.ChangedOn as EB_ChangedOn
	, e.Class as EB_Class
	, e.CostCenter as EB_CostCenter
	, e.FunctLocObjectNumber as EB_FuncLocObjectNumber
	, e.FunctLoc as EB_FuncLoc
	, e.LastSerialNo as EB_LastSerialNo
	, e.Location as EB_Location
	, e.MainWorkCenter as EB_MainWorkCenter
	, e.MainWorkCenterPlant as EB_MainWorkCenterPlant
	, e.MaintenancePlant as EB_MaintenancePlant
	, e.Manufacturer as EB_Manufacturer
	, e.ManufPartNo as EB_ManufPartNo
	, e.ManufSerialNo as EB_ManufSerialNo
	, e.Material as EB_Material
	, e.MaterialSerialNo as EB_MaterialSerialNo
	, e.ModelNo as EB_ModelNo
	, e.ObjType as EB_ObjType
	, e.PlannerGroup as EB_PlannerGroup
	, e.PlanningPlant as EB_PlanningPlant
	, e.PlantSection as EB_PlantSection
	, e.RelPlnGrpName as EB_ReliabilityPlannerGroup
	, e.Room as EB_Room
	, e.SortField as EB_SortField
	, e.SuperordEquip as EB_SuperordEquip
	, e.SystemStatuses as EB_SystemStatuses
	, e.SystemStatusMerged as EB_SystemStatusMerged
	, e.UserStatuses as EB_UserStatuses
	, e.UserStatusMerged as EB_UserStatusMerged
	, e.Related_Tag_Code as EB_Related_Tag_Code
	, e.Related_FLOC_Code as EB_Related_FLOC_Code
	, e.Related_Equipment_Number as EB_Related_Equipment_Number
	
from SUN_EQPT_Validation_SAP_Stage s
-- Outer join the two sides so we find SAP rows with no eB row, and vice versa:
full join SUN_EQPT_Validation_eB e on s.Equipment = e.ItemNumber





GO


/****** Object:  View [dbo].[SUN_EQPT_Validation_Differences]    Script Date: 11/17/2015 12:24:34 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SUN_EQPT_Validation_Differences]'))
DROP VIEW [dbo].[SUN_EQPT_Validation_Differences]
GO

/****** Object:  View [dbo].[SUN_EQPT_Validation_Differences]    Script Date: 11/17/2015 12:24:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [dbo].[SUN_EQPT_Validation_Differences]
AS 

select *

from SUN_EQPT_Validation_Comparison c
where 
   c.missing = 1
or c.extra = 1
or c.wrong_itemnumber = 1
or c.wrong_description = 1
or c.wrong_category = 1
or c.wrong_abcindicator = 1
or c.wrong_objecttype = 1
or c.wrong_class = 1
or c.wrong_systemstatus = 1
or c.wrong_systemstatusmerged = 1
or c.wrong_userstatus = 1
or c.wrong_userstatusmerged = 1
or c.wrong_sortfield = 1
or c.wrong_maintplant = 1
or c.wrong_functloc = 1
or c.wrong_functlocno = 1
or c.wrong_manufacturer = 1
or c.wrong_modelno = 1
or c.wrong_manufpartno = 1
or c.wrong_manufserialno = 1
or c.wrong_authgroup = 1
or c.wrong_location = 1
or c.wrong_room = 1
or c.wrong_plantsection = 1
or c.wrong_workcenter = 1
or c.wrong_workcenterplant = 1
or c.wrong_costcenter = 1
or c.wrong_plannergroup = 1
or c.wrong_catalogprofile = 1
or c.wrong_relplangroupname = 1
or c.wrong_planningplant = 1
or c.wrong_material = 1
or c.wrong_serialno = 1
or c.wrong_lastserialno = 1
or c.wrong_superordequip = 1
or c.wrong_changedon = 1
or c.wrong_related_tag = 1
or c.wrong_related_floc = 1
or c.wrong_related_equipment = 1



GO

