select v.vitem_id, v.vitem_code, 'System Status' as char_name, 
	convert(nvarchar(255),(select LTRIM(RTRIM(
	SUBSTRING(char_value, 1, CHARINDEX(' - ', char_value))
	)) as [data()]
	from char_data_mv 
	where OBJECT_ID = v.vitem_id
	and char_id = (select char_id 
	from characteristics c 
	where char_name = 'System Status' and object_type = 123) 
	for xml path ('') )) as existing_values
from vitems v
join vitem_grp_members m on v.vitem_id = m.vitem_id 
where m.control_id = 40 -- FLOC ROOT
UNION ALL
select v.vitem_id, v.vitem_code, 'User Status' as char_name, 
	convert(nvarchar(255),(select LTRIM(RTRIM(
	SUBSTRING(char_value, 1, CHARINDEX(' - ', char_value))
	)) as [data()]
	from char_data_mv 
	where OBJECT_ID = v.vitem_id
	and char_id = (select char_id 
	from characteristics c 
	where char_name = 'User Status' and object_type = 123) 
	for xml path ('') )) as existing_values
from vitems v
join vitem_grp_members m on v.vitem_id = m.vitem_id 
where m.control_id = 40 -- FLOC ROOT