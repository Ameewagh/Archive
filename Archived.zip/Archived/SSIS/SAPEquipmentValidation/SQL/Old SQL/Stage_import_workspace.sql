select * from stage_load_status_arc where context_id = (select context_id from staged_import_jobs where started_date =( select MAX(started_date) from staged_import_jobs))
and stage_object_id = '?0100000000000007397'
select * from stage_char_data_arc where context_id = (select context_id from staged_import_jobs where started_date =( select MAX(started_date) from staged_import_jobs))
and stage_object_id = '?0100000000000007397'
select * from stage_relationships_arc where context_id = (select context_id from staged_import_jobs where started_date =( select MAX(started_date) from staged_import_jobs))
and right_stage_object_id = '?0100000000000007397'
select * from stage_items_arc where context_id = (select context_id from staged_import_jobs where started_date =( select MAX(started_date) from staged_import_jobs))
and stage_object_id = '?0100000000000007397'
select * from stage_grouped_vitems_arc where context_id = (select context_id from staged_import_jobs where started_date =( select MAX(started_date) from staged_import_jobs))
and stage_object_id = '?0100000000000007397'

sp_who

delete from stage_char_data
delete from stage_char_data_arc
delete from stage_grouped_vitems_arc
delete from stage_relationships_arc
delete from stage_load_status
delete from stage_load_status_arc

select m.sap_obj_type obj_type, m.eb_tag_class_name class_name
from SUN_sapobjtype_tagclass_map(nolock) m
order by obj_type

select * from SUN_sapobjtype_tagclass_map


select s.name as scope, t.code, c.code as class,  t.tag_id
from tags(nolock) t 
inner join class_objects(nolock) c on t.class_id = c.class_id 
inner join objects(nolock) o on t.tag_id = o.object_id and o.object_type = 212
inner join scopes(nolock) s on o.scope_id = s.scope_id
where t.template = 'N' and c.group_id = 17 


select case when CAST('2015-01-01' as datetime) = CAST('2015-01-01' as datetime) then 't' else 'f' end


select vitem_code, c.date_value, m.vitem_id
from vitems v
join vitem_grp_members m on m.vitem_id = v.vitem_id 
join char_data c on c.object_id = m.vitem_id 
and char_id = (select char_id from characteristics where char_name = 'Changed On' and object_type = 123)
and m.control_id = 40 -- FLOC ROOT

delete from stage_load_status_arc

select stage_object_id objectId, status_code, status_msg ErrorMsg 
from stage_load_status_arc 
where context_id like '%101015%'
and status_code not in (5151,5109) and status_code > 5096
and status_msg is not null
group by stage_object_id, status_code, status_msg
order by status_msg

exec ebpsi_del_archive_data '%', 'E'

select s.name as scope, t.code, c.name as class_name,  t.tag_id
from tags(nolock) t 
inner join class_objects(nolock) c on t.class_id = c.class_id 
inner join objects(nolock) o on t.tag_id = o.object_id and o.object_type = 212
inner join scopes(nolock) s on o.scope_id = s.scope_id
where t.template = 'N' and c.group_id = 17
and c.name = 'Instrumentation Loop'
and t.code = '99A-40002'
and s.name = 'Firebag (FB)'


select m.sap_obj_type obj_type, m.eb_tag_class_name class_name
from SUN_sapobjtype_tagclass_map(nolock) m
-- where sap_obj_type = 'ESILL'
order by obj_type


select v.vitem_id, v.vitem_code, m.gvitem_id, t.code, t.tag_id 
from vitems v
join vitem_grp_members m on v.vitem_id = m.vitem_id and m.control_id = 40 -- FLOC ROOT
join relationships r on r.right_object_id = m.gvitem_id and left_object_type = 212 and right_object_type = 123
join tags t on r.left_object_id = t.tag_id
where vitem_code = 'FB1-P091'


select rel_id, left_object_id, right_object_id from relationships 
where rel_type_id = (
	select rel_type_id from relationship_types where class_id = (
		select class_id from class_objects where code = 'ARE010'))
and template = 'N'

select * from

select vitem_code, c.date_value as changed_on, m.vitem_id, m.gvitem_id
from vitems v
join vitem_grp_members m on m.vitem_id = v.vitem_id 
join char_data c on c.object_id = m.vitem_id 
and char_id = (select char_id from characteristics where char_name = 'Changed On' and object_type = 123)
and m.control_id = 40 -- FLOC ROOT

select v.vitem_id, v.vitem_code, 'System Status' as char_name, 
	convert(nvarchar(255),(select LTRIM(RTRIM(
	SUBSTRING(char_value, 1, CHARINDEX(' - ', char_value))
	)) as [data()]
	from char_data_mv 
	where OBJECT_ID = v.vitem_id
	and char_id = (select char_id 
	from characteristics c 
	where char_name = 'System Status' and object_type = 123) 
	for xml path ('') )) as existing_values
from vitems v
join vitem_grp_members m on v.vitem_id = m.vitem_id 
where m.control_id = 40 -- FLOC ROOT
UNION ALL
select v.vitem_id, v.vitem_code, 'User Status' as char_name, 
	convert(nvarchar(255),(select LTRIM(RTRIM(
	SUBSTRING(char_value, 1, CHARINDEX(' - ', char_value))
	)) as [data()]
	from char_data_mv 
	where OBJECT_ID = v.vitem_id
	and char_id = (select char_id 
	from characteristics c 
	where char_name = 'User Status' and object_type = 123) 
	for xml path ('') )) as existing_values
from vitems v
join vitem_grp_members m on v.vitem_id = m.vitem_id 
where m.control_id = 40 -- FLOC ROOT


select v.vitem_id, v.vitem_code, m.gvitem_id, N'System Status' as char_name,
	convert(nvarchar(255),(select LTRIM(RTRIM(
	SUBSTRING(char_value, 1, CHARINDEX(' - ', char_value))
	)) as [data()]
	from char_data_mv 
	where OBJECT_ID = v.vitem_id
	and char_id = (select char_id 
	from characteristics c 
	where char_name = 'System Status' and object_type = 123) 
	for xml path ('') )) as existing_values
from vitems v
join vitem_grp_members m on v.vitem_id = m.vitem_id 
where m.control_id = 40 -- FLOC ROOT
and v.vitem_code like '%REPLICA%'


select * from char_data_mv where object_id in ( 74813, 74812, 74814)
select * from objects where  object_id = 74815

select * from vitem_grp_members where gvitem_id = 74814
select * from vitems where vitem_id = 74815


select * from base_types

UNION ALL
select v.vitem_id, v.vitem_code, N'User Status' as char_name, 
	convert(nvarchar(255),(select LTRIM(RTRIM(
	SUBSTRING(char_value, 1, CHARINDEX(' - ', char_value))
	)) as [data()]
	from char_data_mv 
	where OBJECT_ID = v.vitem_id
	and char_id = (select char_id 
	from characteristics c 
	where char_name = 'User Status' and object_type = 123) 
	for xml path ('') )) as existing_values
from vitems v
join vitem_grp_members m on v.vitem_id = m.vitem_id 
where m.control_id = 40 -- FLOC ROOT

select i.item_number, i.item_id, s.name as scope_name, c.date_value as changed_on
from items i
join objects o on o.object_id = i.item_id and o.object_type = 1
join scopes s on s.scope_id = o.scope_id
join char_data c on c.object_id = i.item_id 
and char_id = (select char_id from characteristics where char_name = 'Changed On' and object_type = 1)

select vitem_code, c.date_value as changed_on, m.vitem_id, m.gvitem_id
from vitems v
join vitem_grp_members m on m.vitem_id = v.vitem_id 
join char_data c on c.object_id = m.vitem_id 
and char_id = (select char_id from characteristics where char_name = 'Changed On' and object_type = 123)
and m.control_id = 40 -- FLOC ROOT



select s.name as scope, i.item_id, i.item_number, N'System Status' as char_name, 
	convert(nvarchar(255),(select LTRIM(RTRIM(
	SUBSTRING(char_value, 1, CHARINDEX(' - ', char_value))
	)) as [data()]
	from char_data_mv 
	where OBJECT_ID = i.item_id
	and char_id = (select char_id 
	from characteristics c 
	where char_name = 'System Status' and object_type = 1) 
	for xml path ('') )) as existing_values
from items i
join objects o on o.object_id = i.item_id and o.object_type = 1
join scopes s on s.scope_id = o.scope_id
where template = 'N'
UNION ALL
select s.name as scope, i.item_id, i.item_number, N'User Status' as char_name, 
	convert(nvarchar(255),(select LTRIM(RTRIM(
	SUBSTRING(char_value, 1, CHARINDEX(' - ', char_value))
	)) as [data()]
	from char_data_mv 
	where OBJECT_ID = i.item_id
	and char_id = (select char_id 
	from characteristics c 
	where char_name = 'User Status' and object_type = 1) 
	for xml path ('') )) as existing_values
from items i
join objects o on o.object_id = i.item_id and o.object_type = 1
join scopes s on s.scope_id = o.scope_id
where template = 'N'


select s.name as scope, t.code, c.name as class_name,  t.tag_id
from tags(nolock) t 
inner join class_objects(nolock) c on t.class_id = c.class_id 
inner join objects(nolock) o on t.tag_id = o.object_id and o.object_type = 212
inner join scopes(nolock) s on o.scope_id = s.scope_id
where t.template = 'N' and c.group_id = 17


select rel_id, left_object_id, right_object_id from relationships 
where rel_type_id = (
	select rel_type_id from relationship_types where class_id = (
		select class_id from class_objects where code = 'ARE051'))
and template = 'N'


select rel_id, left_object_id, right_object_id from relationships 
where rel_type_id = (
	select rel_type_id from relationship_types where class_id = (
		select class_id from class_objects where code = 'ARE051'))
and template = 'N'

select rel_id, left_object_id, right_object_id from relationships 
where rel_type_id = (
	select rel_type_id from relationship_types where class_id = (
		select class_id from class_objects where code = 'ARE050'))
and template = 'N'


select s.name as scope, t.code, c.name as class_name,  t.tag_id
from tags(nolock) t 
inner join class_objects(nolock) c on t.class_id = c.class_id 
inner join objects(nolock) o on t.tag_id = o.object_id and o.object_type = 212
inner join scopes(nolock) s on o.scope_id = s.scope_id
where t.template = 'N' and c.group_id = 17

select v.vitem_code, m.gvitem_id
from vitem_grp_members m
join vitems v on v.vitem_id = m.vitem_id and m.control_id = 40 -- FLOC ROOT

select rel_id, left_object_id, right_object_id from relationships 
where rel_type_id = (
	select rel_type_id from relationship_types where class_id = (
		select class_id from class_objects where code = 'ARE052'))
and template = 'N'


select v.vitem_code, m.gvitem_id
from vitem_grp_members m
join vitems v on v.vitem_id = m.vitem_id and m.control_id = 40 -- FLOC ROOT

select s.name as scope_name, i.item_number, i.item_id
from items i
join objects o on o.object_id = i.item_id and o.object_type = 1
join scopes s on s.scope_id = o.scope_id
where template = 'N'