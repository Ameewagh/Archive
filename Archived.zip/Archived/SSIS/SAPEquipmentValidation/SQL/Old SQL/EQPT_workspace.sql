select * from SUN_EQPT_Validation_SAP_Stage 
where equipment = '000000000020307037'
order by Equipment

select * from SUN_EQPT_Validation_eB 
where ItemNumber = '000000000020307037' order by ItemNumber

select * from SUN_EQPT_Validation_Comparison order by EB_ItemNumber

select * from SUN_EQPT_Validation_Differences order by EB_ItemNumber


-- nulll in ChangedOn means the brand new record

select * from characteristics where char_name = 'Manufacturer Serial Number'
select * from char_data

select * from stage_load_status_arc where context_id like '%091015%' and status_code > 5000




select * from vitem_grp_members where gvitem_id = 74790
	select * from vitems where vitem_code = 'FB1-P099-4000-SEH-PH4334' --vitem_id 74791 FB1-P099-4000-SEH-PH4336
	select * from vitems where vitem_id = 74792
	
	select * from vitems where vitem_code = 'FB1-P109-BESF-SMP-G8110' --vitem_id 74791 FB1-P099-4000-SEH-PH4336
	
	select * from relationships r where rel_type_id = 85 and right_object_id = '92'
	select * from items where item_number = '000000000020307037'
	select * from base_types where object_type = 123
	select * from vitem_grp_members where gvitem_id = 74790
	select * from vitems where vitem_id = 74791
	
	select * from class_groups

select v.vitem_id, v.vitem_code, sysstat.SystemStatuses, userstat.UserStatuses
from vitem_grp_members vgm 
join vitems v on v.vitem_id = vgm.vitem_id and vgm.control_id = 40
left join (
			select ss.object_id, ss.SystemStatuses
			from (
				select distinct ss2.object_id,
					LTRIM(RTRIM((
						select LTRIM(RTRIM(SUBSTRING(ss1.char_value,1, CHARINDEX(' - ', ss1.char_value)))) + ' ' as [text()]
						from char_data_mv ss1 (nolock)
						inner join characteristics css (nolock) on ss1.char_id = css.char_id and css.char_name = 'System Status' and css.object_type = 123
						where ss1.object_id = ss2.object_id
						for XML PATH ('')
					))) SystemStatuses
				from char_data_mv ss2 (nolock)
			) ss
		) sysstat on v.vitem_id = sysstat.object_id

	-- Join User Statuses, concatenated
	left join (
			select us.object_id, us.UserStatuses
			from (
				select distinct us2.object_id,
					LTRIM(RTRIM((
						select LTRIM(RTRIM(SUBSTRING(us1.char_value,1, CHARINDEX(' - ', us1.char_value)))) + ' ' as [text()]
						from char_data_mv us1 (nolock)
						inner join characteristics cus (nolock) on us1.char_id = cus.char_id and cus.char_name = 'User Status' and cus.object_type = 123
						where us1.object_id = us2.object_id
						for XML PATH ('')
					))) UserStatuses
				from char_data_mv us2 (nolock)
			) us
		) userstat on v.vitem_id = userstat.object_id




	
		left join relationships r on 
		i.item_id = r.right_object_id
		and r.rel_type_id = 85	-- FLOC to Equipment relationships only. Can be only one Equipment per FLOC so this join should not generate additonal rows.
		and r.template = 'N' -- not a template
		
	left join vitem_grp_members vgm on
		r.left_object_id = vgm.vitem_id
		and vgm.control_id = 40 -- FLOC  Get just Grouped Virtual Items in the FLOC group
		-- and vgm.template = 'N'
	
	left join vitems vi on
		vgm.vitem_id = vi.vitem_id