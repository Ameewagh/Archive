IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SUN_EQPT_Validation_Differences]'))
DROP VIEW [dbo].[SUN_EQPT_Validation_Differences]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[SUN_EQPT_Validation_Differences]
AS 

select *

from SUN_EQPT_Validation_Comparison c
where 
   c.missing = 1
or c.extra = 1
or c.wrong_itemnumber = 1
or c.wrong_description = 1
or c.wrong_category = 1
or c.wrong_abcindicator = 1
or c.wrong_objecttype = 1
or c.wrong_class = 1
or c.wrong_systemstatus = 1
or c.wrong_systemstatusmerged = 1
or c.wrong_userstatus = 1
or c.wrong_userstatusmerged = 1
or c.wrong_sortfield = 1
or c.wrong_maintplant = 1
or c.wrong_functloc = 1
or c.wrong_functlocno = 1
or c.wrong_manufacturer = 1
or c.wrong_modelno = 1
or c.wrong_manufpartno = 1
or c.wrong_manufserialno = 1
or c.wrong_authgroup = 1
or c.wrong_location = 1
or c.wrong_room = 1
or c.wrong_plantsection = 1
or c.wrong_workcenter = 1
or c.wrong_workcenterplant = 1
or c.wrong_costcenter = 1
or c.wrong_plannergroup = 1
or c.wrong_catalogprofile = 1
or c.wrong_relplangroupname = 1
or c.wrong_planningplant = 1
or c.wrong_material = 1
or c.wrong_serialno = 1
or c.wrong_lastserialno = 1
or c.wrong_superordequip = 1
or c.wrong_changedon = 1
or c.wrong_related_tag = 1
or c.wrong_related_floc = 1
or c.wrong_related_equipment = 1

GO
