/****** Object:  View [dbo].[SUN_EQPT_Validation_Comparison]    Script Date: 11/17/2015 09:14:21 ******/
IF  EXISTS (SELECT * FROM sys.views WHERE object_id = OBJECT_ID(N'[dbo].[SUN_EQPT_Validation_Comparison]'))
DROP VIEW [dbo].[SUN_EQPT_Validation_Comparison]
GO

/****** Object:  View [dbo].[SUN_EQPT_Validation_Comparison]    Script Date: 11/17/2015 09:14:21 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[SUN_EQPT_Validation_Comparison]
AS 
-- SQL to compare SAP and eB Equipment data.
-- Requires table SUN_EQPT_Validation_SAP_Stage and view SUN_EQPT_Validation_eB

select 
	-- 1. COMPARISON FLAG COLUMNS

	-- identify if Equipment is found in one system and not the other
	case when (s.Equipment is not null) and (e.ItemNumber is null) then 1 else 0 end as missing
	, case when (s.Equipment is null) and (e.ItemNumber is not null) then 1 else 0 end as extra
	-- identify differences in attribute values
	-- handle NULLs using ISNULL() to substitute a reasonable value in place of any NULLs.
	--		using an empty stirng '' for NULL char values
	--		using a fixed date value of '1900-01-01 00:00:00.000' for NULL date values
	, case when s.Equipment <> ISNULL(e.ItemNumber,'') then 1 else 0 end as wrong_itemnumber
	, case when s.EquipDesc <> ISNULL(e.Description,'') then 1 else 0 end as wrong_description
	, case when s.ABCInd <> ISNULL(e.ABCIndicator,'') then 1 else 0 end as wrong_abcindicator
	, case when s.AuthGrp <> ISNULL(e.AuthorizationGroup,'') then 1 else 0 end as wrong_authgroup
	, case when s.CatProf <> ISNULL(e.CatalogProfile,'') then 1 else 0 end as wrong_catalogprofile
	, case when s.EquipCat <> ISNULL(e.Category,'') then 1 else 0 end as wrong_category
	, case when ISNULL(Cast(s.ChangedDte as datetime),'1900-01-01 00:00:00.000') <> ISNULL(e.ChangedOn,'1900-01-01 00:00:00.000') then 1 else 0 end as wrong_changedon
	, case when s.Class <> ISNULL(e.Class,'') then 1 else 0 end as wrong_class
	, dbo.sun_compare_compounds(s.CostCtr, s.CostCtrDesc, e.CostCenter) as wrong_costcenter
	, case when s.FunctLoc <> ISNULL(e.FunctLocObjectNumber,'') then 1 else 0 end as wrong_functlocno
	, case when LTRIM(RTRIM(s.FunctLocLabel)) <> LTRIM(RTRIM(ISNULL(e.FunctLoc,''))) then 1 else 0 end as wrong_functloc
	, case when LTRIM(RTRIM(s.LastSerialNo)) <> LTRIM(RTRIM(ISNULL(e.LastSerialNo,''))) then 1 else 0 end as wrong_lastserialno
	, dbo.sun_compare_compounds(s.Location, s.LocDesc, e.Location) as wrong_location
	, dbo.sun_compare_compounds(s.WorkCtr, s.WorkCtrDesc, e.MainWorkCenter) as wrong_workcenter
	, case when LTRIM(RTRIM(s.WorkCtrPlant)) <> LTRIM(RTRIM(ISNULL(e.MainWorkCenterPlant,''))) then 1 else 0 end as wrong_workcenterplant
	, case when s.MaintPlant <> ISNULL(e.MaintenancePlant,'') then 1 else 0 end as wrong_maintplant
	, case when LTRIM(RTRIM(s.Manufacturer)) <> LTRIM(RTRIM(ISNULL(e.Manufacturer,''))) then 1 else 0 end as wrong_manufacturer
	, case when LTRIM(RTRIM(s.ManufPartNo)) <> LTRIM(RTRIM(ISNULL(e.ManufPartNo,''))) then 1 else 0 end as wrong_manufpartno
	, case when LTRIM(RTRIM(s.ManufSerialNo)) <> LTRIM(RTRIM(ISNULL(e.ManufSerialNo,''))) then 1 else 0 end as wrong_manufserialno
	, dbo.sun_compare_compounds(s.Material, s.MatDesc, e.Material) as wrong_material
	, case when LTRIM(RTRIM(s.SerialNo)) <> LTRIM(RTRIM(ISNULL(e.MaterialSerialNo,''))) then 1 else 0 end as wrong_serialno
	, case when LTRIM(RTRIM(s.ModelNo)) <> LTRIM(RTRIM(ISNULL(e.ModelNo,''))) then 1 else 0 end as wrong_modelno
	, case when s.ObjectType <> ISNULL(e.ObjType,'') then 1 else 0 end as wrong_objecttype
	, dbo.sun_compare_compounds(s.PlannerGrp, s.PlannerGrpName, e.PlannerGroup) as wrong_plannergroup
	, case when s.PlngPlant <> ISNULL(e.PlanningPlant,'') then 1 else 0 end as wrong_planningplant
	, dbo.sun_compare_compounds(s.PlSectn, s.PersResp, e.PlantSection) as wrong_plantsection
	, dbo.sun_compare_compounds(s.RelPlnGrp, s.RelPlnGrpName, e.RelPlnGrpName) as wrong_relplangroupname
	, case when LTRIM(RTRIM(s.Room)) <> LTRIM(RTRIM(ISNULL(e.Room,''))) then 1 else 0 end as wrong_room
	, case when LTRIM(RTRIM(s.SortField)) <> LTRIM(RTRIM(ISNULL(e.SortField,''))) then 1 else 0 end as wrong_sortfield
	, case when s.SuperordEquip <> ISNULL(e.SuperordEquip,'') then 1 else 0 end as wrong_superordequip
	, case when dbo.split_sort_merge_string(s.SysStatus) <> dbo.split_sort_merge_string(ISNULL(e.SystemStatuses,'')) then 1 else 0 end as wrong_systemstatus
	, case when s.SysStatus <> ISNULL(e.SystemStatusMerged,'') then 1 else 0 end as wrong_systemstatusmerged	
	, case when dbo.split_sort_merge_string(s.UserStatus) <> dbo.split_sort_merge_string(ISNULL(e.UserStatuses,'')) then 1 else 0 end as wrong_userstatus
	, case when s.UserStatus <> ISNULL(e.UserStatusMerged,'') then 1 else 0 end as wrong_userstatusmerged
	-- Only flag an error if there is a related Tag. If Tag object was not in eB then no error.
	-- This is because the SAP sort field sometimes contains a non-Tag number, so it's normal to see many cases where no tag is found matching the sort field.
	, case when (e.Related_Tag_Code is not NULL) and (s.SortField <> ISNULL(e.Related_Tag_Code,'')) then 1 else 0 end as wrong_related_tag
	-- Flag an error if the related FLOC or Equipment was not found - these should always be there.
	-- This would indicate a data integrity error with the foreign keys between these SAP objects.
	, case when s.FunctLocLabel <> ISNULL(e.Related_FLOC_Code,'') then 1 else 0 end as wrong_related_floc
	, case when s.SuperordEquip <> ISNULL(e.Related_Equipment_Number,'') then 1 else 0 end as wrong_related_equipment
	
	-- 2. SAP STAGING TABLE COLUMNS
	
	, s.LoadDateTime as SAP_LoadDateTime
	, s.Equipment as SAP_Equipment
	, s.EquipDesc as SAP_EquipDesc
	, s.EquipCat as SAP_EquipCat
	, s.ABCInd as SAP_ABCInd
	, s.ObjectType as SAP_ObjectType
	, s.Class as SAP_Class
	, s.SysStatus as SAP_SysStatus
	, s.UserStatus as SAP_UserStatus
	, s.SortField as SAP_SortField
	, s.MaintPlant as SAP_MaintPlant
	, s.FunctLoc as SAP_FunctLoc
	, s.FunctLocLabel as SAP_FunctLocLabel
	, s.Manufacturer as SAP_Manufacturer
	, s.ModelNo as SAP_ModelNo
	, s.ManufPartNo as SAP_ManufPartNo
	, s.ManufSerialNo as SAP_ManufSerialNo
	, s.AuthGrp as SAP_AuthGrp
	, s.Location as SAP_Location
	, s.LocDesc as SAP_LocDesc
	, s.Room as SAP_Room
	, s.PlSectn as SAP_PlSectn
	, s.PersResp as SAP_PersResp
	, s.WorkCtr as SAP_WorkCtr
	, s.WorkCtrDesc as SAP_WorkCtrDesc
	, s.WorkCtrPlant as SAP_WorkCtrPlant
	, s.CostCtr as SAP_CostCtr
	, s.CostCtrDesc as SAP_CostCtrDesc
	, s.PlannerGrp as SAP_PlannerGrp
	, s.PlannerGrpName as SAP_PlannerGrpName
	, s.CatProf as SAP_CatProf
	, s.RelPlnGrp as SAP_RelPlnGrp
	, s.RelPlnGrpName as SAP_RelPlnGrpName
	, s.PlngPlant as SAP_PlngPlant
	, s.Material as SAP_Material
	, s.MatDesc as SAP_MatDesc
	, s.SerialNo as SAP_SerialNo
	, s.LastSerialNo as SAP_LastSerialNo
	, s.SuperordEquip as SAP_SuperordEquip
	, s.ChangedDte as SAP_ChangedDte
	
	-- 3. EB FLATTENED VIEW COLUMNS
	
	, e.item_id as EB_item_id
	, e.ItemNumber as EB_ItemNumber
	, e.Description as EB_Description
	, e.ABCIndicator as EB_ABCIndicator
	, e.AuthorizationGroup as EB_AuthorizationGroup
	, e.CatalogProfile as EB_CatalogProfile
	, e.Category as EB_Category
	, e.ChangedOn as EB_ChangedOn
	, e.Class as EB_Class
	, e.CostCenter as EB_CostCenter
	, e.FunctLocObjectNumber as EB_FuncLocObjectNumber
	, e.FunctLoc as EB_FuncLoc
	, e.LastSerialNo as EB_LastSerialNo
	, e.Location as EB_Location
	, e.MainWorkCenter as EB_MainWorkCenter
	, e.MainWorkCenterPlant as EB_MainWorkCenterPlant
	, e.MaintenancePlant as EB_MaintenancePlant
	, e.Manufacturer as EB_Manufacturer
	, e.ManufPartNo as EB_ManufPartNo
	, e.ManufSerialNo as EB_ManufSerialNo
	, e.Material as EB_Material
	, e.MaterialSerialNo as EB_MaterialSerialNo
	, e.ModelNo as EB_ModelNo
	, e.ObjType as EB_ObjType
	, e.PlannerGroup as EB_PlannerGroup
	, e.PlanningPlant as EB_PlanningPlant
	, e.PlantSection as EB_PlantSection
	, e.RelPlnGrpName as EB_ReliabilityPlannerGroup
	, e.Room as EB_Room
	, e.SortField as EB_SortField
	, e.SuperordEquip as EB_SuperordEquip
	, e.SystemStatuses as EB_SystemStatuses
	, e.SystemStatusMerged as EB_SystemStatusMerged
	, e.UserStatuses as EB_UserStatuses
	, e.UserStatusMerged as EB_UserStatusMerged
	, e.Related_Tag_Code as EB_Related_Tag_Code
	, e.Related_FLOC_Code as EB_Related_FLOC_Code
	, e.Related_Equipment_Number as EB_Related_Equipment_Number
	
from SUN_EQPT_Validation_SAP_Stage s
-- Outer join the two sides so we find SAP rows with no eB row, and vice versa:
full join SUN_EQPT_Validation_eB e on s.Equipment = e.ItemNumber



GO


