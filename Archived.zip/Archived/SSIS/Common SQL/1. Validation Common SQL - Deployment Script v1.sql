--
-- 1. Validation Common SQL - Deployment Script v1.sql
--

/****** Object:  UserDefinedFunction [dbo].[SUN_split_sort_merge_string]    Script Date: 11/17/2015 12:14:37 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SUN_split_sort_merge_string]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[SUN_split_sort_merge_string]
GO

/****** Object:  UserDefinedFunction [dbo].[SUN_split_sort_merge_string]    Script Date: 11/17/2015 12:14:37 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




CREATE FUNCTION [dbo].[SUN_split_sort_merge_string] ( @stringToSplit NVARCHAR(MAX) )
RETURNS
 NVARCHAR(MAX)
AS
BEGIN

-- This function takes an input string like 'XXX AAA YYYY BBB' and sorts the values between the spaces,
-- returning a string like 'AAA BBB XXX YYYY'.
-- It strips off extra whitespace.

 DECLARE @tempList TABLE ([Name] [nvarchar] (500))
 DECLARE @returnValue NVARCHAR(MAX)
 DECLARE @name NVARCHAR(255)
 DECLARE @pos INT
 
 -- remove extra whitepspace to prevent FOR XML from generating XML entity codes
 set @stringToSplit = LTRIM(RTRIM(replace(replace(replace(@stringToSplit,' ','<>'),'><',''),'<>',' ')))
 
 WHILE CHARINDEX(' ', @stringToSplit) > 0
 BEGIN
  SELECT @pos  = CHARINDEX(' ', @stringToSplit)  
  SELECT @name = SUBSTRING(@stringToSplit, 1, @pos-1)

  INSERT INTO @tempList
  SELECT @name

  SELECT @stringToSplit = SUBSTRING(@stringToSplit, @pos+1, LEN(@stringToSplit)-@pos)
 END

 INSERT INTO @tempList
 SELECT @stringToSplit

 set @returnValue = (	
	Select t.Name + ' ' AS [text()]
	From @tempList t
	ORDER BY t.Name
	For XML PATH (''))

 RETURN @returnValue
END


GO


/****** Object:  UserDefinedFunction [dbo].[SUN_compare_compounds]    Script Date: 11/17/2015 12:14:46 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[SUN_compare_compounds]') AND type in (N'FN', N'IF', N'TF', N'FS', N'FT'))
DROP FUNCTION [dbo].[SUN_compare_compounds]
GO

/****** Object:  UserDefinedFunction [dbo].[SUN_compare_compounds]    Script Date: 11/17/2015 12:14:46 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

create function [dbo].[SUN_compare_compounds](
	@first nvarchar(max), 
	@second nvarchar(max), 
	-- @delim nvarchar(max), 
	@compound nvarchar(max)
) returns int
-- This function takes three parameters: Code, Description, and Merged
-- it returns 0 if the first two parameters concatenated e.g. "Code - Description"
-- are equivalent to the third (Merged) parameter, which is already in the format "Code - Description".
-- It returns a 1 if they are NOT equivalent.
begin
	set @first = isnull(@first, '')
	set @second = isnull(@second, '')
	set @compound = isnull(@compound, '')
	if @first = '' and @second = '' and @compound = '' return 0
	if (@first + ' - ' + @second) = @compound return 0
	return 1 -- different
end
/* -- testing 
select dbo.SUN_compare_compounds('', '', '')		--0
select dbo.SUN_compare_compounds('', '', null)		--0
select dbo.SUN_compare_compounds(null, null, null)	--0	we treat null and empty string as same thing
select dbo.SUN_compare_compounds('a', 'b', 'a - b')	--0
select dbo.SUN_compare_compounds('a', 'b', 'x - y')	--1
select dbo.SUN_compare_compounds('', 'b', ' - b')	--0
select dbo.SUN_compare_compounds('', '', '    ')	--0	sql compare ignores trailing spaces
select dbo.SUN_compare_compounds('', 'b', ' - b  ')	--0	sql compare ignores trailing spaces
*/


GO


